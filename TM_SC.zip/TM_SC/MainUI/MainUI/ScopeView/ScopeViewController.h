//
//  ScopeViewController.h
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "UIController.h"

@interface ScopeViewController : UIController{
    @private
    IBOutlet NSTextView * txtScopeInfor;
}

@end
