//
//  ScopeViewController.m
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "ScopeViewController.h"
#include "UICommon.h"

@interface ScopeViewController ()

@end

@implementation ScopeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

-(void)awakeFromNib
{
    [self RegisterUINotification];
}

#pragma mark User Interface Update entry function

//User Interface
-(void)UpdateScope:(NSString *)msg
{
    [txtScopeInfor setString:msg];
}


-(void)SetScope:(NSString *)msg
{
    [txtScopeInfor performSelectorOnMainThread:@selector(setString:) withObject:msg waitUntilDone:NO];
}

-(int) OnEngineStart:(id)sender
{
    [[[txtScopeInfor textStorage] mutableString] setString:@""];
    return 0;
}

-(int) OnEngineFinish:(id)sender
{
    return 0;
}


-(int) OnTestStart:(id)sender
{
    //reinitial...
    [self SetScope:@""];
    
    //Save Start time
    return 0;
}
-(int) OnTestStop:(id)sender
{
    return 0;
}
-(int) OnTestPasue:(id)sender
{
    return 0;
}
-(int) OnTestResume:(id)sender
{
    return 0;
}

-(int) OnTestItemStart:(id)sender
{
    return [super OnTestItemStart:sender];
}
-(int) OnTestItemFinish:(id)sender
{
    return [super OnTestItemFinish:sender];
}

-(int) OnTestFinish:(id)sender
{
    return 0;
}
-(int) OnTestError:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    int iID = [[dic valueForKey:@"id"] intValue];
    NSString * strmsg = [dic valueForKey:@"error"];
    if (!strmsg) {
        return 0;
    }
    
    NSMutableString * str = [[txtScopeInfor textStorage] mutableString];
    [str appendFormat:@"[UUT%d_ERROR]:%@\r\n",iID,strmsg];
    
    return 0;
}



@end
