#!/bin/bash
export PYTHON="~/Desktop/python_sequencer":$PYTHON

echo "input parameter:"
echo $#

cd ~/Desktop/python_sequencer/x527
  for((i=1;i<=$#;i++))
  do
  	 if [[ $i = 1 ]]; then
	 	 python sdb.py -s $1 &
	 fi
	 
	 if [[ $i = 2 ]]; then
	 	 python sdb.py -s $2 &
	 fi

	 if [[ $i = 3 ]]; then
	 	 python sdb.py -s $3 &
	 fi

	 if [[ $i = 4 ]]; then
	 	 python sdb.py -s $4 &
	 fi
	 

  done
bash 