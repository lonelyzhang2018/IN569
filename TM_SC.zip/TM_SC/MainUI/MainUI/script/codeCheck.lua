local sumFile = "~/Desktop/sha1.txt" --source hash code, 
local sourceMatchPattern = "SHA1%(%.%/(.-)%)=%s*(.+)"

local diffFilename = "changedFileList.txt" -- when hash code is different, this file will generated

local destinationFileName = "codeCheck.txt" --Path will full by main function
local shellSript = "sha.sh" -- shell script to generate hash code file
local destinationMatchPattern = nil--"SHA1%(%/(.-)%)=%s*(.+)" -- match pattern for hash code

local currentDir = nil

function replace_special_char(txt)
	txt = tostring(txt)
	txt = string.gsub(txt, "%(", "%%(")
	txt = string.gsub(txt, "%)", "%%)")
	txt = string.gsub(txt, "%-", "%%-")
	txt = string.gsub(txt, "%+", "%%+")
	txt = string.gsub(txt, "%.", "%%.")
	txt = string.gsub(txt, "%[", "%%[")
	txt = string.gsub(txt, "%]", "%%]")
	return txt;
end

function replaceSpecialCharacterForPath(filename)
	filename = tostring(filename)
	filename = string.gsub(filename, " ", "\\\ ")
	filename = string.gsub(filename, "'", "\\\'")
	filename = string.gsub(filename, '"', '\\\"')
	filename = string.gsub(filename, "%(", "\\\(")
	filename = string.gsub(filename, "%)", "\\\)")
	filename = string.gsub(filename, "%{", "\\\{")
	filename = string.gsub(filename, "%}", "\\\}")
	filename = string.gsub(filename, "%#", "\\\#")
	filename = string.gsub(filename, ";", "\\\;")
	return filename
end

function deleteLastPathComponent(p)
	local t = {}
	for v in string.gmatch(p,"[^/]+")do
		t[#t+1] = v
	end
	if(#t>1) then
		table.remove(t,#t)
	end
	return "/"..table.concat(t,"/")
end

local function parsePath(file)
	local n = os.tmpname()
	local t = {}
	os.execute("echo "..file.." > "..n)
	for l in io.lines(n) do
		t[#t+1] = l
	end
	file = tostring(table.concat(t, ""))
	print("hash file >> ",file)
	return file
end

local function parseShaFile(file,matchPattern)
	local shaSumTable = {}
	local fileTable = {}
	local fileCode = {}

	local f = io.open(file)
	if f then
		f:close()
		for l in io.lines(file) do
			-- print(l, matchPattern)
			local file, shasum = string.match(l, matchPattern)--SHA1(.//LuaDriver/Driver/ArmDLTest.lua)
			print(file, shasum)
			if not string.match(tostring(file), "%/%.") then
				if file~=nil and shasum~=nil then
					-- print("file, shasum",file, shasum)
					fileTable[#fileTable+1] = file
					shaSumTable[#shaSumTable+1] = shasum
					fileCode[file] = shasum
					-- print(fileCode[file])
				end
			end
		end
	else
		print("< check sh1 > No such file or directory : "..tostring(file))
	end
	return fileTable, shaSumTable, fileCode
end

local function executeHash(sourceFolder, destinationFile)
	shellSript = sourceFolder.."/TM.app/Contents/Resources/"..shellSript
	os.execute("sh "..shellSript.." "..sourceFolder.." "..destinationFile)
end

function writeFile(filename,content)
	local file = io.open(filename, "w")
	if file then
		file:write(content)
		file:close()
		return true
	else
		return false
	end
end

function checkResult(currentPath)
	local missFile = {}
	local changedFile = {}

	currentDir = currentPath
	sumFile = parsePath(sumFile)
	local _,_,fileCode = parseShaFile(sumFile, sourceMatchPattern)
	
	destination = currentDir.."/"..destinationFileName
	print("< destination file >", destination)
	executeHash(currentDir, destination)
	
	destinationMatchPattern = replace_special_char(currentDir)
	destinationMatchPattern = "SHA1%("..destinationMatchPattern .. "(%/.-)%)=%s*(.+)"

	local _,_,resultCode = parseShaFile(destination, destinationMatchPattern)
	
	os.execute("rm "..destination)
	
	print("_----- - -  - - -")
	for i,v in pairs(fileCode) do
		print(i,v,resultCode[i])
		if resultCode[i] then
			if resultCode[i] ~= v then
				changedFile[#changedFile+1] = tostring(i)
			end
		else
			missFile[#missFile+1] = tostring(i)
		end	
	end

	local filename = currentDir.."/"..tostring(diffFilename)
	if #missFile == 0 and #changedFile == 0 then
		writeFile(filename,"Success :-)")
		return "SUCCESS"
	else
		local time = os.date("%y-%m-%d %H:%M:%S\r\n", os.time())
		local changeFlag = "* * * * * * * * * * * * * * * * * * * * * \r\n< Changed File > \r\n* * * * * * * * * * * * * * * * * * * * * \r\n"
		local missFlag =  "\r\n\r\n* * * * * * * * * * * * * * * * * * * * * \r\n< Missed File > \r\n* * * * * * * * * * * * * * * * * * * * * \r\n"

		local str = time .. changeFlag .. table.concat(changedFile,"\r\n").. missFlag .. table.concat( missFile, "\r\n")
		writeFile(filename,str)
		return str
	end
end

-- print(checkResult())


