local function killProcessByPort(port)
    if(port<=0) then 
        return 0
    end
    local n = os.tmpname()
    local ret = ""
    os.execute("lsof -i:"..tostring(port).." > "..n)
    for l in io.lines(n) do
        ret = ret .. l .. '\n'
    end
    print("lsof -i:"..tostring(port))
    print(ret)
    local killed = ""
    for pid in string.gmatch(ret, "lua%s+(%d+)") do
        if string.match(killed, tostring(pid))==nil then
            print("kill -9 pid "..tostring(pid))
            os.execute("kill -9 "..tostring(pid))
            killed = killed ..tostring(pid)..","
        end
    end
    for pid in string.gmatch(ret, "Python%s+(%d+)") do
        if string.match(killed, tostring(pid))==nil then
            print("kill -9 pid "..tostring(pid))
            os.execute("kill -9 "..tostring(pid))
            killed = killed ..tostring(pid)..","
        end
    end
end

local function killProcess(par)
    local loop = 4
    if string.match(par,"PREFCT") then
        loop = 6
    end
    print("< kill process > : ",loop)
    local json = require "dkjson"
    local path = "echo ~/testerconfig/zmqports.json"
    local ret = ""
    local n = os.tmpname()
    os.execute(path.." > "..n)
    for l in io.lines(n) do
        ret = ret .. l
    end
    print(ret)
    f = io.open(ret)
    if f then
        local str = f:read("*a")
        f:close()
        if str then
            local obj = json.decode(str)
            if obj then
                -- print(obj.SEQUENCER_PORT)
                -- print(obj.TEST_ENGINE_PORT)
                -- print(obj.SM_PORT)
                -- print(obj.FIXTURE_CTRL_PORT)
                for i=1, loop do
                    killProcessByPort(obj.TEST_ENGINE_PORT+i-1)
                    killProcessByPort(obj.SEQUENCER_PORT+i-1)
                    killProcessByPort(obj.LOG_PATH_PORT+i-1)
                end
                killProcessByPort(obj.LOGGER_PUB)
                killProcessByPort(obj.SM_PORT)
                killProcessByPort(obj.FIXTURE_CTRL_PORT)
            end
        end
    end
end

--json
function get_station()
    local f=io.open("/vault/data_collection/test_station_config/gh_station_info.json");
    if (not f) then
        return "UnKown"
    end
    local buf = f:read("*all");
    local station = tostring(buf):match("\"STATION_TYPE\"%s*:%s*\"(.-)\"")
    f:close();
    return station;
end

function get_product()
    local f=io.open("/vault/data_collection/test_station_config/gh_station_info.json");
    if (not f) then
        return "UnKown"
    end
    local buf = f:read("*all");
    local product = tostring(buf):match("\"PRODUCT\"%s*:%s*\"(.-)\"")
    f:close();
    return product;
end

function get_gh_info()--this global fucntion,dont change the function name
    local f = io.open("/Users/gdlocal/DeskTop/Restore Info.txt")
    if f then
        local str = f:read("*all")
        f:close()
        local ovl = string.match(str, "STATION_OVERLAY_VERSION=%s*(.-)%s*[\r\n]")
        local station, testplan, version = nil, nil, nil
        if ovl then
            station, testplan, version = string.match(ovl, ".-%s+(.-)_(.-)__(.-)[%s\r\n]")
            if version==nil then version = "Unknow" end
            return version
        end
    else
        return "Unknow"
    end
end

function get_fixture_type()--SIP, PAN
    print("< GUI get fixture type from translation board >")
    os.execute("ping -c 1 169.254.1.32");
    sc = require "socket.core".tcp()
    sc:settimeout(3)
    local status = sc:connect("169.254.1.32", 7600)
    print(status)
    if status==nil then 
        print("< Connect fixture TCPIP > : Fail, (Fixture Type: Unknow)")
        return "Unknow" 
    end
    print(sc:send("[123]eeprom read(translation,cat08,20,32)\r\n"))
    local ret = sc:receive()
    sc:close()
    print("< GUI Receive >",ret)
    local data = string.match(tostring(ret), "ACK%((.-);")
    local product, fixture_type, mechanical_type = "Unknow", "Unknow", "Unknow"
    if data then
        local tbl = {}
        for v in string.gmatch(data,"(%x+)") do
            -- print(v)
            tbl[#tbl+1] = string.char(tonumber(v,16))
        end
        if #tbl>0 then
             local fixture_id = table.concat(tbl)
             product, fixture_type, mechanical_type = string.match(fixture_id, "(.-)%-(.-)%-(.-)%-")
        end
    end
    print("< GUI Get Fixture Type > : ", tostring(product), tostring(fixture_type),tostring(mechanical_type))
    local fixture_module = "unknow"
    if string.match(tostring(fixture_type), "PM") then --PMF1, PMF2
        fixture_module = "PANEL"
    else
        if string.upper(tostring(mechanical_type)) == "OPTICAL" then
            fixture_module = "SIPOPICAL"
        else
            fixture_module = "SIPME"
        end
    end
    print("< Fixture Type > : ",fixture_module)
    return fixture_module
end

local pName = get_product().."_"..get_station()

local sip_fct_gui={
    name = pName,--ME
    module=1,
    slot=4,
    plugins={},--"bundleSipFixture.bundle"
    --executor="TestExecutor",
    process="sip",
    sleep = 5,
}

-- local product = tostring(get_product()):upper();
-- local station = tostring(get_station()):upper();

-- killProcess(station)

-- if station:match("PREFCT") then
--     --panel station
--     return panel_fct_gui
-- else
--     --sip station
--     if product:match("X827") then
--         return opt_fct_gui
--     else
--         return sip_fct_gui
--     end
-- end

local station = "SIP"
killProcess(station)

return sip_fct_gui
