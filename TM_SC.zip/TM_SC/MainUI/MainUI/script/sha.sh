#!/bin/sh
if [ $1 ]
	then
    printf "\n%s\n" $1
    printf "\n%s\n" $2
	find $1 -type f -print0 | xargs -0 openssl sha1 | sort > $2
else
	find ./ -type f -print0 | xargs -0 openssl sha1 | sort > ./sha1.txt
fi