#!/bin/bash
export PYTHON="~/Desktop/python_sequencer":$PYTHON

#lua ./parse.lua

#read string <temp.txt


echo '$0: '$0
echo "pwd: "`pwd`
echo "scriptPath1: "$(cd `dirname $0`; pwd)
rt=$(cd `dirname $0`; pwd)
cd ${rt}
export PYTHONPATH="${rt}/python_sequencer"
echo "PYTHONPATH: "$PYTHONPATH


#run engine
cd /Users/mac/Documents/GIT/tm_platform_v2/LuaDriver/Driver/
lua test_engine_C_Zmq.lua -u 0 &>/tmp/engine_0.txt &

#run sequencer
cd ${rt}
python python_sequencer/x527/Sequencer/Sequencer.py -s 0 &>/tmp/seq_0.txt &


cd ~/Desktop/LuaDriver/Driver
  for((i=1;i<=$#;i++))
  do
  	 if [[ $i = 1 ]]; then

  	 	lua test_engine_C_Zmq.lua -u $1  &

  	 fi
  	 if [[ $i = 2 ]]; then
  	 	 lua test_engine_C_Zmq.lua -u $2 &

  	 fi
  	 if [[ $i = 3 ]]; then
  	 	 lua test_engine_C_Zmq.lua -u $3 &

  	 fi
  	 if [[ $i = 4 ]]; then
  	 	 lua test_engine_C_Zmq.lua -u $4  &

  	 fi
 	  
 done


sleep 3

cd ~/Desktop/LuaDriver/datalog
  for((i=1;i<=$#;i++))
  do
  	  if [[ $i = 1 ]]; then 
 	  	 lua datalog.lua -i $1 &
 	  fi

 	  if [[ $i = 2 ]]; then 
 	 	 lua datalog.lua -i $2 &
 	  fi

 	  if [[ $i = 3 ]]; then 
 	  	 lua datalog.lua -i $3 &
 	  fi

 	  if [[ $i = 4 ]]; then 
 	  	 lua datalog.lua -i $4 &
 	  fi
  done

 cd ~/Desktop/python_sequencer/x527/sequencer
 	for((i=1;i<=$#;i++))
 	do
 	   if [[ $i = 1 ]]; then 
 		  python sequencer.py -s $1 &
 	   fi

 	   if [[ $i = 2 ]]; then 
 		  python sequencer.py -s $2 &
 	   fi

 	   if [[ $i = 3 ]]; then 
 		  python sequencer.py -s $3 &
 	   fi

 	   if [[ $i = 4 ]]; then 
 		  python sequencer.py -s $4 &
 	   fi
 	done 

 # rm temp.txt

bash 