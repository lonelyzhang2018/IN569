//
//  AppDelegate.m
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "AppDelegate.h"

#include "DetailViewController.h"
#include "ScopeViewController.h"
#include "InteractionViewController.h"

#include "TestItem.h"
#include "UICommon.h"

#include "RegexKitLite.h"

#include "PathManager.h"

#include "SeqController.h"
#include "SMController.h"
#include "SNManagerController.h"

#include "EngineController.h"
#include "StateMachineHeartbeat.h"
#include "DatalogHeartBeat.h"
#include "PuddingHeartbeat.h"

#define Config_File     @"UI_config.plist"

#include "Launcher.hpp"

#include "Task.h"

#include "UIContext.h"
#import "libInstantPuddingVersion.h"
#import "VersionCheck.h"
#import "fwUpload.h"

#import "UserInformation.h"
#define basicLibInstantPuddingVersion @"1.1.124"


@interface AppDelegate ()


//@property (weak) IBOutlet NSWindow *window;
@end


//Global Client
NSMutableArray * arrSequencer;
SMController * StateMachine;
NSMutableArray * arrSNManager;

StateMachineHeartbeat  * statemachinHB;

NSMutableArray * arrEngineController;

NSMutableArray * arrDatalogHB;
PuddingHeartbeat * puddingHB;

StartUpInfor * pStartUpInfor=nil;
NSMutableDictionary * m_dicConfiguration=nil;

AppDelegate * app;

Task * t;

static USER_INFOR       *pCurrUser = NULL;
USER_INFOR * defaultUser;
extern CUserInformation *m_pUserInformation;

NSMutableArray * arrUIContext;
@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    if (![VersionCheck VersionCompare:puddingVersion :basicLibInstantPuddingVersion])
    {
        
        NSAlert * alert = [NSAlert alertWithError:[NSError errorWithDomain:[NSString stringWithFormat:@"libInstantPuddingVersion.dylib\nversion : %@\nBasic Version : %@\n",puddingVersion, basicLibInstantPuddingVersion] code:-9 userInfo:nil]];
        [alert runModal];
    }
    
//    [self checkLogin:nil];
    [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
    [self menuItemAdd];
    
    [fwUpload fwUpload:nil];
    [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
    hash = [[hashCodeCheck alloc]init];
    [hash hashCodeCheck:nil];
    
    [self lauchTask];
    
    plgCenter = [[PluginCenter alloc] init];
    
    vcDetail = [[DetailViewController alloc] init];
    vcScope = [[ScopeViewController alloc] init];
    vcInteraction = [[InteractionViewController alloc] init];
    
    [self SetDetailView:vcDetail.view];
    [self SetScopeView:vcScope.view];
    [self SetInteractionView:vcInteraction.view];
    
    [self LoadPlugins];
    NSString * version = [[[NSBundle mainBundle]infoDictionary]objectForKey:@"CFBundleShortVersionString"];
    [txtSWVersion setStringValue:version];
//    if ([[pStartUpInfor.gh_version uppercaseString]containsString:@"UNKNOW"]) {
//        [txtVersion setStringValue:@"N/A"];
//    }
//    else [txtVersion setStringValue:[NSString stringWithFormat:@"%@",pStartUpInfor.gh_version]];
    [txtHashCode setHidden:hash.bHashCorrect];
    [txtPDCA setHidden:pStartUpInfor.pdcaEnable];
    
    NSDictionary * dicUser = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithUTF8String:pCurrUser->szName],kLoginUserName,[NSString stringWithUTF8String:pCurrUser->szPassword],kLoginUserPassword,[NSNumber numberWithInt:pCurrUser->Authority],kLoginUserAuthority, nil];
    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationDoChangeUser object:nil userInfo:dicUser];
    
    [winSplash orderOut:nil];
    [winMain center];
    [winMain makeKeyAndOrderFront:nil];
    [self LoadProfile:[m_dicConfiguration valueForKey:kProfilePath]];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    [pStartUpInfor release];
    [plgCenter release];
    [m_dicConfiguration release];
    [t End_Task];
    [hash release];
}

#pragma mark main window delegate
- (void)windowWillClose:(NSNotification *)notification
{
    [NSApp terminate:nil];
}

-(id)init
{
    self= [super init];
    if (self) {
        system("ulimit -n 8192");
        pStartUpInfor = [[StartUpInfor alloc] init];
        [pStartUpInfor LoadWithFile:nil];
        
        puddingVersion = [libInstantPuddingVersion getPuddingVersion];
        
        m_dicConfiguration = [[NSMutableDictionary alloc] init];
        [self LoadConfig:Config_File];
        
        int n = [[m_dicConfiguration objectForKey:kConfigFailStop]intValue];
        if(n==-1) pStartUpInfor.stopfail = false;
        else pStartUpInfor.stopfail = true;
        BOOL pdca = [[m_dicConfiguration objectForKey:kConfigPuddingPDCA]boolValue];
        pStartUpInfor.pdcaEnable = pdca;
        
        app = self;
        
        arrUIContext = [[NSMutableArray alloc] init];
        for (int i=0; i<pStartUpInfor.Slot_Number; i++) {
            [arrUIContext addObject:[[UIContext alloc] init]];
        }
        defaultUser = new USER_INFOR();
        strcpy(defaultUser->szName,"op");
        strcpy(defaultUser->szPassword, "op");
        defaultUser->Authority = AUTHORITY_OPERATOR;
        pCurrUser = defaultUser;
        
        arrEngineController = [[NSMutableArray alloc]init];
        arrSequencer = [[NSMutableArray alloc]init];
        arrDatalogHB = [[NSMutableArray alloc]init];
    }
    return self;
}

- (void)lauchTask
{
    t = [[Task alloc] init];
    [t setStopFail:pStartUpInfor.stopfail];
    [t Lanuch_Task_WithIdentifier:pStartUpInfor];
    [NSThread sleepForTimeInterval:3];
    [self InitialEngine];
    [self InitialSequencer];
//    [self InitialDatalogHB];
    [self InitialStateMachine];
    [self InitialPuddingHB];
}

- (void)menuItemAdd
{
    //Change Menu title;
    NSMenu * mainMenu = [NSApp mainMenu];
    NSMenu * appMenu = [[mainMenu itemAtIndex:0]submenu];
    //add user menu
    NSInteger count = [appMenu numberOfItems];
    //Change Menu title;
    [appMenu setTitle:[NSString stringWithFormat:@"About %@",pStartUpInfor.Name]];
    [[appMenu itemAtIndex:0] setTitle:[NSString stringWithFormat:@"%@",pStartUpInfor.Name]];
    [[appMenu itemAtIndex:0] setTarget:self];
    [[appMenu itemAtIndex:0] setAction:@selector(OnMenuAbout:)];
    //    [appMenu insertItem:menuUserManagement atIndex:count-2];
//    [appMenu insertItem:menuLogin atIndex:count-2];
//    [menuLogin setEnabled:YES];
//    [appMenu insertItem:[NSMenuItem separatorItem] atIndex:count-2];
//    [appMenu insertItem:[NSMenuItem separatorItem] atIndex:count-4];
}

-(IBAction)OnMenuAbout:(id)sender
{

}

- (BOOL)validateUserInterfaceItem:(id < NSValidatedUserInterfaceItem >)anItem
{
    if (anItem.tag == 99 || anItem.tag == 9) {//Login, scanbarcode,
        return YES;
    }
    if (pCurrUser->szName)
    {
        if (pCurrUser->Authority<AUTHORITY_OPERATOR)
        {
            return YES;
        }
    }
    return NO;
}

- (IBAction)menuLogin:(id)sender
{
    if (pCurrUser && strcmp(pCurrUser->szName,"op")!=0)
    {
        [menuLogin setTitle:@"Login"];
        pCurrUser = NULL;
        NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:@"Operator",kLoginUserName,[NSNumber numberWithInt:AUTHORITY_OPERATOR],kLoginUserAuthority, nil];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationDoChangeUser object:nil userInfo:dic];
    }
    else {
        if ([NSApp runModalForWindow:winLogin]==YES)
        {
            pCurrUser = m_pUserInformation->GetCurrentUser();
            if(strcmp(pCurrUser->szName,"op")!=0)
                [menuLogin setTitle:@"Logout"];
            USER_INFOR * pUser = m_pUserInformation->GetCurrentUser();
            NSDictionary * dicUser = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithUTF8String:pUser->szName],kLoginUserName,[NSString stringWithUTF8String:pUser->szPassword],kLoginUserPassword,[NSNumber numberWithInt:pUser->Authority],kLoginUserAuthority, nil];
            [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationDoChangeUser object:nil userInfo:dicUser];
        }
    }
}

- (void)checkLogin:(id)sender
{
    if ([NSApp runModalForWindow:winLogin]==YES)
    {
        [menuLogin setTitle:@"Logout"];
        pCurrUser = m_pUserInformation->GetCurrentUser();
    }
    else {
        [NSApp terminate:nil];
    }
}

-(void)awakeFromNib
{

}

-(void)dealloc
{
    [super dealloc];
    for (id uc in arrUIContext)
    {
        [uc release];
    }
    delete defaultUser;
    [arrUIContext release];
    if(arrDatalogHB)
    {
        for(int i=0;i<[arrDatalogHB count]; i++)
            [arrDatalogHB[i] release];
        [arrDatalogHB release];
    }
    if(puddingHB)
        [puddingHB release];
    if(statemachinHB)
        [statemachinHB release];
    if(arrSequencer)
    {
        for(int i=0; i<[arrSequencer count]; i++)
            [arrSequencer[i] release];
        [arrSequencer release];
    }
    if(arrEngineController)
    {
        for(int i=0; i<[arrEngineController count]; i++)
            [arrEngineController[i] release];
        [arrEngineController release];
    }
}

//Create Client
-(void)InitialSequencer
{
    NSLog(@"*********************Start to Create Sequencer client!********************************");
    arrSequencer = [[NSMutableArray alloc] init];
    for (int i=0;i<pStartUpInfor.Slot_Number;i++)
    {
        SeqController * proxy = [[SeqController alloc] initWithIndex:i];
        [proxy CreateRPC:nil withSubscriber:nil];
        //int ret = [m_Sequencer CreateRPC:Sequencer_IP withSubscrib:Sequencer_PUB];
        [arrSequencer addObject:proxy];
    }
    NSLog(@"*********************Create Sequencer client finished!********************************\r\n\r\n\r\n");
}

-(void)InitialStateMachine
{
    NSLog(@"*********************Start to Create StateMachine client!********************************");
    StateMachine = [[SMController alloc] init];
    [StateMachine CreateRPC:nil withSubscriber:nil];
    
    statemachinHB = [[StateMachineHeartbeat alloc] init];
    [statemachinHB CreateRPC:nil withSubscriber:nil];
    
    NSLog(@"*********************Create State Machine client finished!********************************\r\n\r\n\r\n");
}

-(void)InitialSNManager
{
    NSLog(@"*********************Start to Create SN Manager client!********************************");
    arrSNManager = [[NSMutableArray alloc] init];
    for (int i=0;i<pStartUpInfor.Slot_Number;i++)
    {
        SNManagerController * snm = [[SNManagerController alloc] initWithIndex:i];
        [snm CreateRPC:nil withSubscriber:nil];
        [arrSNManager addObject:snm];
    }
    NSLog(@"*********************Create SN Manager client finished!********************************\r\n\r\n\r\n");
}

-(void)InitialEngine
{
    NSLog(@"*********************Start to Create Test Engine Client!********************************");
    arrSNManager = [[NSMutableArray alloc] init];
    for (int i=0;i<pStartUpInfor.Slot_Number;i++)
    {
        EngineController * ec = [[EngineController alloc] initWithIndex:i];
        [ec CreateRPC:nil withSubscriber:nil];
        [arrEngineController addObject:ec];
    }
    NSLog(@"*********************Create Test Engine client finished!********************************\r\n\r\n\r\n");

}

- (void)InitialPuddingHB
{
    NSLog(@"*********************Start to Create Pudding HB client!********************************");
    puddingHB = [[PuddingHeartbeat alloc]init];
    [puddingHB CreateRPC:nil withSubscriber:nil];
    NSLog(@"*********************Create Pudding HB client finished!********************************\r\n\r\n\r\n");
}

- (void)InitialDatalogHB
{
    NSLog(@"*********************Start to Create Datalog HB client!********************************");
    for (int i=0;i<pStartUpInfor.Slot_Number;i++)
    {
        DatalogHeartBeat * db = [[DatalogHeartBeat alloc]initWithIndex:i];
        [db CreateRPC:nil withSubscriber:nil];
        [arrDatalogHB addObject:db];
    }
    NSLog(@"*********************Create Datalog HB client finished!********************************\r\n\r\n\r\n");
}

//load all plugins
-(void)LoadPlugins
{
    NSLog(@"*********************Start to load UI plugins********************************\r\n\r\n\r\n");
    //load all plugins
    NSMutableDictionary * dic = [NSMutableDictionary new];
    [dic setValue:winMain forKey:@"main"];
    //[dic setObject:viewDetail  forKey:@"detail_view"];
    //[dic setObject:viewScope forKey:@"scope_view"];
    //[dic setObject:viewInteraction forKey:@"view_interaction"];
    [dic setValue:menuInstruments forKey:@"menu_instr"];
    [dic setValue:menuTools forKey:@"menu_tools"];
    [dic setValue:[NSNumber numberWithInt:pStartUpInfor.Slot_Number] forKey:@"slots"];
    [dic setValue:[NSNumber numberWithInt:pStartUpInfor.Module_Number] forKey:@"modules"];
    [plgCenter LoadPlugins:pStartUpInfor.arrPlugins initDic:dic];
    [dic release];
    NSLog(@"*********************Load plugins finished!********************************\r\n\r\n\r\n");
}

#pragma mark Configuration
- (NSArray *)listProfile:(NSString *)folder
{
    NSString * str = [folder stringByResolvingSymlinksInPath];
    NSArray * arr = [[NSFileManager defaultManager]contentsOfDirectoryAtPath:str error:nil];
    NSMutableArray * fileList = [[NSMutableArray alloc]init];
    for(NSString * file in arr)
    {
        if([file containsString:@".csv"])
            [fileList addObject:file];
    }
    if([fileList count]>0)
    {
        NSArray * tmp = [NSArray arrayWithArray:fileList];
        [fileList release];
        return tmp;
    }
    else
        return nullptr;
}

//Load configuration from config.plist
-(void)LoadConfig:(NSString *)fileConfig
{
    [m_dicConfiguration release];
    NSString *config_dir  = [[PathManager sharedManager] configPath];
    
    m_dicConfiguration = [[NSMutableDictionary dictionaryWithContentsOfFile:[config_dir stringByAppendingPathComponent:fileConfig]] retain];
    
    NSArray * arrkey = [NSArray arrayWithObjects:
                        kEngineUUT0Enable,
                        kEngineUUT1Enable,
                        kEngineUUT2Enable,
                        kEngineUUT3Enable,
                        kEngineUUT4Enable,
                        kEngineUUT5Enable,
                        kProfilePath,
                        kConfigScanBarcode,
                        kConfigScanCFG,
                        kConfigPuddingPDCA,
                        kConfigTriggerType,
                        kConfigFailCount,
                        kConfigFailStop,
                        kConfigLogDir,
                        kConfigQueryResult,
                        kConfigQeryStationName,
                        kConfigSN1Format,
                        kConfigSN2Format,
                        kConfigSN3Format,
                        kConfigSN4Format,
                        kConfigSN5Format,
                        kConfigSN6Format,
                        kConfigTriggerString,
                        kConfigAutomationMode,
                        kConfigCheckEECode,
                        kConfigFixtureID,
                        kConfigPuddingBlob,
                        kConfigPuddingBlobUart,
                        kConfigPuddingBlobTestFlow,
                        kConfigRemoveLocalBlob,
                        kConfigRebuildCSV,
                        nil];
    
    NSArray * arrDefault = [NSArray arrayWithObjects:[NSNumber numberWithInt:1],
                            [NSNumber numberWithInt:1],
                            [NSNumber numberWithInt:1],
                            [NSNumber numberWithInt:1],
                            [NSNumber numberWithInt:1],
                            [NSNumber numberWithInt:1],
                            @"initial.lua",                 //profile
                            [NSNumber numberWithBool:YES],  //barcode
                            [NSNumber numberWithBool:YES],  //cfg
                            [NSNumber numberWithBool:YES],  //pdca
                            [NSNumber numberWithInt:2],  //trigger
                            [NSNumber numberWithInt:0],  //allowed fail count
                            [NSNumber numberWithInt:-1],  //fail continue
                            @"/vault/Intelli_log",    //log directory
                            [NSNumber numberWithBool:YES],      //Query previous station?
                            @"ICT",                         //Query stations' name
                            @".................",           //SN1 format
                            @"",                            //SN2 format
                            @"",                            //SN3 format
                            @"",                            //SN4 format
                            @"",                            //SN5 format
                            @"",                            //SN6 format
                            @"START",                       //Trigger String
                            @"0",                           //Automation Mode
                            [NSNumber numberWithBool:YES],  //EEEECode
                            @"",                           //Automation Mode
                            [NSNumber numberWithInt:1],     //Pudding Blob
                            [NSNumber numberWithInt:1],     //Pudding Uart Blob
                            [NSNumber numberWithInt:1],     //Pudding TestFlow Blob
                            [NSNumber numberWithInt:1],     //Remove Local Blob
                            [NSNumber numberWithBool:NO],  //pdca
                            nil];
    
    if (!m_dicConfiguration)  //use default value
    {
        [m_dicConfiguration release];
        m_dicConfiguration = [[NSMutableDictionary dictionaryWithObjects:arrDefault forKeys:arrkey] retain];
    }
    else {  //double check the default value
        for (int i=0; i<[arrkey count]; i++) {
            if (![m_dicConfiguration objectForKey:[arrkey objectAtIndex:i]])  //couldn't find the key then use default
            {
                [m_dicConfiguration setValue:[arrDefault objectAtIndex:i] forKey:[arrkey objectAtIndex:i]];
            }
        }
    }
    
    //reinitial enable all the dut
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT0Enable];
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT1Enable];
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT2Enable];
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT3Enable];
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT4Enable];
    [m_dicConfiguration setValue:[NSNumber numberWithInt:1] forKey:kEngineUUT5Enable];
//always load the first csv file located "Profile"
    NSString * folder = [[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"Profile"];
    
    NSArray * arr = [self listProfile:folder];
    NSString * path;
    if(arr)
        path = [arr objectAtIndex:0];
    else
        path = @"";
    [m_dicConfiguration setObject:path forKey:kProfilePath];
}

-(void)SaveConfig:(NSString *)fileConfig
{
    NSString *config_dir  = [[PathManager sharedManager] configPath];
    NSError * err;
    if (![[NSFileManager defaultManager] createDirectoryAtPath:config_dir withIntermediateDirectories:YES attributes:NULL error:&err])
    {
        NSRunAlertPanel(@"Create director failed", @"%@", @"OK", nil, nil,err);
    }
    BOOL ret = [m_dicConfiguration writeToFile:[config_dir stringByAppendingPathComponent:fileConfig] atomically:YES];
    
    //Create LogDir
    @try {
        NSString * path = [m_dicConfiguration valueForKey:kConfigLogDir];
        NSError * err;
        if (![[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:&err])
        {
            NSRunAlertPanel(@"Create Logpath failed!", @"%@", @"OK", nil, nil,[err description]);
        }
    }
    @catch (NSException *exception) {
        NSRunAlertPanel([exception name], @"%@", @"OK", nil, nil,[exception reason]);
    }
    @finally {
    }
}

-(void)ReplaceView:(NSView *)oldView with:(NSView *)newView
{
    [newView setFrame:[oldView frame]];
    [[oldView superview] addSubview:newView];
    [[oldView superview] replaceSubview:oldView with:newView];
    [oldView setHidden:YES];
}

-(void)SetDetailView:(NSView *)view
{
    [self ReplaceView:viewDetail with:view];
    viewDetail =view;
}

-(void)SetScopeView:(NSView *)view
{
    [self ReplaceView:viewScope with:view];
    viewDetail = view;
    
}

-(void)SetInteractionView:(NSView *)view
{
    [self ReplaceView:viewInteraction with:view];
    viewInteraction = view;
}


#pragma mark general
//Parse test item from the script files.
-(NSTreeNode *)ParseTestItems:(NSString *) strItems
{
    // We will use the built-in NSTreeNode with a representedObject that is our model object - the SimpleNodeData object.
    // First, create our model object.
    NSString *nodeName = @"root_item";
    KeyItem *nodeData = [KeyItem nodeDataWithName:nodeName];
    // The image for the nodeData is lazily filled in, for performance.
    NSTreeNode *result = [NSTreeNode treeNodeWithRepresentedObject:nodeData];
    
    NSArray * steps = [strItems componentsSeparatedByString:@"\n"];     //lines
    NSTreeNode * keyTreeNode=nil;
    for (NSString * item in steps){
        item = [item stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSArray * contents = [item componentsSeparatedByString:@"\t"];  //
        if ([[contents objectAtIndex:0] isEqualToString:@"key"])    //KeyItem;
        {
            KeyItem * keyNodeData = [[KeyItem alloc] initWithName:[contents objectAtIndex:1]];
            keyTreeNode = [NSTreeNode treeNodeWithRepresentedObject:keyNodeData];
            [keyNodeData release];
            [[result mutableChildNodes]addObject:keyTreeNode];      //add to the root tree
        }
        else    //test item
        {
            NSArray  *arr = [contents subarrayWithRange:NSMakeRange(1, [contents count]-1)];
            
            if ([contents count] < 2) {
                continue;
            }
            
            NSString *index       = [arr objectAtIndex:0];
            NSString *description = [arr objectAtIndex:1];
            NSString *lower       = [arr count] > 2 ? [arr objectAtIndex:2] : nil;
            NSString *upper       = [arr count] > 3 ? [arr objectAtIndex:3] : nil;
            NSString *unit        = [arr count] > 4 ? [arr objectAtIndex:4] : nil;
            NSString *testkey     = [arr count] > 6 ? [arr objectAtIndex:6] : nil;
            
            if (!testkey ||[testkey isEqualToString:@""]) {
                testkey     = [arr count] > 8 ? [arr objectAtIndex:8] : nil;
            }
            
            
            BOOL waiver = NO;
            if ([arr count] > 7)
            {
                waiver = [[arr objectAtIndex:7] isEqualToString:@"waiver"];
            }
            
            
            TestItem * itemNodeData = [[TestItem new] autorelease];
            
            itemNodeData.index       = index;
            itemNodeData.description = description;
            itemNodeData.lower       = lower;
            itemNodeData.upper       = upper;
            itemNodeData.unit        = unit;
            itemNodeData.group       = [[keyTreeNode representedObject] name];
            itemNodeData.testkey     = testkey;
            itemNodeData.waiver      = waiver;
            
            
            NSTreeNode *itemTreeNode = [NSTreeNode treeNodeWithRepresentedObject:itemNodeData];
            
            if (keyTreeNode)
            {
                [[keyTreeNode mutableChildNodes]addObject:itemTreeNode];    //add to current key item.
            }
            else {
                [[result mutableChildNodes]addObject:itemTreeNode];    //add to current key item.
            }
        }
    }
    return result;
}

-(int) OnUpdateProfile:(id)sender
{
    @try {
        NSString * szItem = [sender valueForKey:@"msg"];
        
        NSString * szModule = [sender valueForKey:@"module"];
        if (!szModule) {
            szModule = @"No module name";
        }
        NSString * szVersion = [sender valueForKey:@"version"];
        if (!szVersion) {
            szVersion = @"N/A";
        }
        NSString * szPath = [sender valueForKey:@"path"];
        if (!szPath) {
            szPath = @"Untitle";
        }
        
        NSTreeNode * items = [self ParseTestItems:szItem];
        
        [txtModule setStringValue:szModule];
//        [txtVersion setStringValue:szVersion];
        [winMain setTitle:szPath];
        
        //Post notificaiton to updata user interface.
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationLoadProfile object:self userInfo:[NSDictionary dictionaryWithObject:items forKey:@"items"]];
        
    }
    @catch (NSException *exception) {
        NSRunAlertPanel(@"UpdateProfileView Error", @"%@", @"OK", nil, nil, [exception description]);
    }
    @finally{
    }
    
    return 0;
}


-(void)Dummy_Seq
{
    NSString * str =
    @"key	Main Test Item1\r\n\
    item	000	Check Fatal Error\r\n\
    item	001	IT-Z7 get boot infor			mA\r\n\
    item	002	IT-Z8 boot infor			mA\r\n\
    item	003	Test Item 1-1	0	1	N/A\r\n\
    item	004	SetSku	1	1\r\n\
    item	005	Test Item 1-2	1	1	NDummy_Seq/A\r\n\
    item	006	Test Item 1-3	1	1\r\n\
    item	007	Test Item 1-4	0	1\r\n\
    item	008	Test Item 1-5	0	1\r\n\
    key	Insertion Loss Test\r\n\
    item	009	TestItem0	0	1000\r\n\
    item	010	TestItem1	0	1000\r\n\
    item	011	TestItem2	0	1000\r\n\
    item	012	TestItem3	0	1000\r\n\
    item	013	TestItem4	0	1000\r\n\
    item	014	TestItem5	0	1000	";
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:str,@"msg",@"x527 FCT Module",@"module",@"20151203.1",@"version",@"Debug.seq",@"path",nil];
    [self OnUpdateProfile:dic];
}

#pragma mark menu action
-(IBAction)OnScanBarcode:(id)sender
{
    int count = [snDelegate InitialCtrls:m_dicConfiguration];
    if(count ==0)
    {
    [winMain beginSheet:winSN completionHandler:^(NSModalResponse returnCode) {
        switch (returnCode) {
            case NSModalResponseOK:
            {
            }
                break;
            case  NSModalResponseCancel:
                break;
                
            default:
                break;
        }
    }];
    }
}

-(IBAction)OnPrefrence:(id)sender
{
    [preferenceDelegate InitialCtrls:m_dicConfiguration];
    [winMain beginSheet:winConfiguration completionHandler:^(NSModalResponse returnCode) {
        switch (returnCode) {
            case NSModalResponseOK:
            {
                [self SaveConfig:Config_File];
            }
                break;
            case  NSModalResponseCancel:
                break;
                
            default:
                break;
        }
    }];
}

-(IBAction)OnLoadProfile:(id)sender
{
    [profileDelegate InitialCtrls:m_dicConfiguration];
    [winMain beginSheet:winProfile completionHandler:^(NSModalResponse returnCode) {
        switch (returnCode) {
            case NSModalResponseOK:
            {
                NSString * str = [m_dicConfiguration valueForKey:@"profile"];
                [self LoadProfile:str];
                [self SaveConfig:Config_File];
                [self ReLoadLog];
            }
                break;
            case NSModalResponseCancel:
                break;
                
            default:
                break;
        }
    }];
}

-(void)ReLoadLog
{
    BOOL isRebuildCSV = [[m_dicConfiguration objectForKey:kConfigRebuildCSV]boolValue];
    
    if (isRebuildCSV)
    {
        NSLog(@"Rebuilding CSV...");
        [t Lanuch_PDCA:[[m_dicConfiguration objectForKey:kConfigPuddingPDCA]boolValue]];
    }
}

-(void)LoadProfile:(NSString *)profile
{
    if(!profile || [profile length]==0) return;
    NSString * str = [profile stringByResolvingSymlinksInPath];
    if (![profile isAbsolutePath]) {
        NSString * path = [[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"Profile"];
        str = [[path stringByAppendingPathComponent:str] stringByResolvingSymlinksInPath];
    }
    
    for (SeqController * proxy in arrSequencer)    //Load Sequencer
    {
        @try {
            [proxy LoadProfile:str];
            NSString * strItem = [proxy ListItem];
            NSDictionary * dicItems = [NSDictionary dictionaryWithObjectsAndKeys:strItem,@"msg",@"x527 FCT Module",@"module",@"20151203.1",@"version",@"Debug.seq",@"path",nil];
            [self OnUpdateProfile:dicItems];
            
            [winMain setTitle:profile];
            
            NSString * strcap = @".*/(.*)__(.*)\\..*";
            NSString * Title = [str stringByMatching:strcap capture:1];
            NSString * Version = [str stringByMatching:strcap capture:2];
            if(Version)
                [txtVersion setStringValue:Version];
            else
                [txtVersion setStringValue:@"N/A"];
            [txtModule setStringValue:Title];
        }
        @catch (NSException *exception) {
            NSAlert * alert = [[NSAlert alloc] init];
            alert.messageText = [exception name];
            alert.informativeText = [exception reason];
            [alert runModal];
        }
        @finally {
            
        }
    }
}

-(IBAction)OnMenuLoopTester:(id)sender
{
    [panelLoopTester makeKeyAndOrderFront:nil];
}

///////
NSMutableArray * arrTask = [NSMutableArray new];


@end
