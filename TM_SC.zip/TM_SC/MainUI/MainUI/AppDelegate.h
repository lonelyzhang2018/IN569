//
//  AppDelegate.h
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#include "StartUpInfor.h"
#include "PluginCenter.h"
#import "hashCodeCheck.h"

#include "mainuiProfileWndDelegate.h"
#include "uiConfigWndDelegate.h"
#include "SNDelegate.h"

@interface AppDelegate : NSObject {
    IBOutlet NSWindow * winMain;
    IBOutlet NSWindow * winProfile;
    IBOutlet NSWindow * winSN;
    IBOutlet NSWindow * winLogin;
    IBOutlet NSWindow * winSplash;
    
    IBOutlet NSWindow * panelLoopTester;
    
    IBOutlet NSView * viewDetail;
    IBOutlet NSView * viewScope;
    IBOutlet NSView * viewInteraction;
    
    IBOutlet NSTextField * txtModule;
    IBOutlet NSTextField * txtVersion;
    IBOutlet NSTextField * txtSWVersion;
    
    IBOutlet NSTextField * txtName;
    
    NSViewController * vcDetail;
    NSViewController * vcScope;
    NSViewController * vcInteraction;
    
    IBOutlet NSWindow * winConfiguration;
    IBOutlet NSWindow * winLoadProfile;
    
    IBOutlet mainuiProfileWndDelegate * profileDelegate;
    IBOutlet uiConfigWndDelegate * preferenceDelegate;
    IBOutlet SNDelegate * snDelegate;
    
    
    IBOutlet NSMenu * menuInstruments;
    IBOutlet NSMenu * menuTools;
    IBOutlet NSMenuItem * menuLogin;
    
    PluginCenter * plgCenter;
    
    hashCodeCheck * hash;
    IBOutlet NSTextField * txtHashCode;
    IBOutlet NSTextField * txtPDCA;
@private
    NSString * puddingVersion;
}

-(IBAction)OnScanBarcode:(id)sender;

@end

