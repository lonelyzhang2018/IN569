//
//  uiLooptesterWndDelegate.h
//  UI
//
//  Created by Ryan on 13-2-28.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "UIController.h"

extern BOOL bLoopTestMode;
@interface uiLooptesterWndDelegate : UIController{
    IBOutlet NSButton * btLoopTest;
    IBOutlet NSTextField * textCurrentLoop;
    IBOutlet NSTextField * textLoopCount;
    IBOutlet NSTextField * textTimeInterval;
    IBOutlet NSProgressIndicator * progressIndicator;
    
    int m_CurrentLoop,m_TotalLoop;
    NSTimer * timerLoop;
    NSThread * threadLoop;
}

@end
