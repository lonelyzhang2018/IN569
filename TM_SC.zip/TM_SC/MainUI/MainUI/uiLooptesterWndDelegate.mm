//
//  uiLooptesterWndDelegate.m
//  UI
//
//  Created by Ryan on 13-2-28.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "uiLooptesterWndDelegate.h"
#include "SMController.h"

#include "UICommon.h"

extern SMController * StateMachine;


BOOL bLoopTestMode = FALSE;
@implementation uiLooptesterWndDelegate
static BOOL bRunning = NO;
-(void)awakeFromNib
{
    m_CurrentLoop = 0;
    [self RegisterUINotification];
}

-(IBAction)btGoLoop:(id)sender
{
    if (![sender tag])
    {
//        timerLoop= [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
        [timerLoop fire];
        [textLoopCount setEnabled:NO];
        [textTimeInterval setEnabled:NO];
        m_TotalLoop = [textLoopCount intValue];
        [progressIndicator startAnimation:nil];
        bLoopTestMode = YES;
        m_CurrentLoop= 0;
        threadLoop = [[NSThread alloc] initWithTarget:self selector:@selector(threadMonitor:) object:nil];
        [threadLoop start];
    }
    else {
        bLoopTestMode = NO;
        [textTimeInterval setEnabled:YES];
        [textLoopCount setEnabled:YES];
//        [timerLoop invalidate];
        [progressIndicator stopAnimation:nil];
    }
}


-(int) OnEngineStart:(id)sender
{
    if (bLoopTestMode) {
        m_CurrentLoop++;
        [textCurrentLoop setIntValue:m_CurrentLoop];
    }
    bRunning = YES;
    NSLog(@"UIController:OnEngineStart: %@",[sender description]);
    return 0;
}
-(int) OnEngineFinish:(id)sender
{
    bRunning = NO;
    NSLog(@"UIController:OnEngineFinish: %@",[sender description]);
    return 0;
}

-(void)threadMonitor:(id)sender
{
    while (bLoopTestMode) {
        if (m_CurrentLoop>m_TotalLoop)
        {
            break;
        }
        
        if (!bRunning)  //all uut ready
        {
            [NSThread sleepForTimeInterval:[textTimeInterval intValue]];
            [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationDoTestStart object:nil]; //Go Test;
        }
        [NSThread sleepForTimeInterval:[textTimeInterval intValue]];
        [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
    }
    bLoopTestMode = NO;
    [textLoopCount setEnabled:YES];
    //        [timerLoop invalidate];
    [progressIndicator stopAnimation:nil];
}
@end
