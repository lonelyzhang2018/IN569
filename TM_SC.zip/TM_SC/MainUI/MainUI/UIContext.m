//
//  UIContext.m
//  MainUI
//
//  Created by xuqian on 29/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "UIContext.h"

static NSMutableDictionary * dicGlobal = nil;

@implementation UIContext
-(id)init
{
    self = [super init];
    if (self) {
        if (dicGlobal) {
            dicGlobal = [[NSMutableDictionary alloc] init];
        }
        m_dicContext = [[NSMutableDictionary alloc] init];
    }
    return self;
}

-(void)dealloc
{
    [super dealloc];
    if (dicGlobal) {
        [dicGlobal release];
        dicGlobal = nil;
    }
    [m_dicContext release];
}

-(id)getContext:(NSString *)key
{
    return [m_dicContext valueForKey:key];
}
-(void)setContext:(id)value forKey:(NSString *)key
{
    [m_dicContext setValue:value forKey:key];
}

+(id)getGlobal:(NSString *)key
{
    return [dicGlobal valueForKey:key];
}

+(void)setGlobal:(id)value forKey:(NSString *)key
{
    return [dicGlobal setValue:value forKey:key];
}
@end
