//
//  VersionCheck.m
//  MainUI
//
//  Created by IvanGan on 16/3/9.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "VersionCheck.h"

@implementation VersionCheck

+ (BOOL)VersionCompare:(NSString *)version :(NSString *)basicVersion
{
    NSArray * arrVersion = [version componentsSeparatedByString:@"."];
    NSArray * arrBasic = [basicVersion componentsSeparatedByString:@"."];
    for(int i=0; i<[arrVersion count]; i++)
    {
        if ([[arrVersion objectAtIndex:i]integerValue] > [[arrBasic objectAtIndex:i]integerValue]) {
            return true;
        }
        else if ([[arrVersion objectAtIndex:i]integerValue] < [[arrBasic objectAtIndex:i]integerValue]) {
            return false;
        }
    }
    return true;
}

@end
