//
//  libInstantPuddingVersion.h
//  MainUI
//
//  Created by IvanGan on 16/3/8.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface libInstantPuddingVersion : NSObject
+ (NSString *)getPuddingVersion;
@end
