//
//  VersionCheck.h
//  MainUI
//
//  Created by IvanGan on 16/3/9.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VersionCheck : NSObject

+ (BOOL)VersionCompare:(NSString *)version :(NSString *)basicVersion;

@end
