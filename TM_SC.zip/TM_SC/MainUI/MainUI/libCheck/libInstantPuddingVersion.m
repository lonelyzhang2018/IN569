//
//  libInstantPuddingVersion.m
//  MainUI
//
//  Created by IvanGan on 16/3/8.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "libInstantPuddingVersion.h"
#import "InstantPudding_API.h"

@implementation libInstantPuddingVersion

+ (NSString *)getPuddingVersion
{
    NSString * version = [NSString stringWithUTF8String:IP_getVersion()];
    NSLog(@" < Get libInstantPudding Version> : %@",version);
    return version;
}

@end
