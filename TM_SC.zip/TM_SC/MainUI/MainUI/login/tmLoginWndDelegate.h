//
//  tmLoginWndDelegate.h
//  TestManager
//
//  Created by Ryan on 13-3-15.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

#include "UserInformation.h"

#define  SECRITY_FILE       @"login.pwd"

@interface tmLoginWndDelegate : NSObject{
    NSMutableArray * m_arrRegistedUser;
    
    IBOutlet NSTextField * textUserName;
    IBOutlet NSTextField * textPassword;
    
    IBOutlet NSWindow * winMain;
    IBOutlet NSWindow * winLogin;
    
    IBOutlet NSWindow * panelLogin;
    
    USER_INFOR * m_pCurrUser;
}

- (IBAction)btOK:(id)sender;
- (IBAction)btCancel:(id)sender;
@end
