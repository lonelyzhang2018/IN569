//
//  UIContext.h
//  MainUI
//
//  Created by xuqian on 29/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma once

#define kContextStationName     @"StationName"
#define kContextStationID       @"StationID"
#define kContextStationType     @"StationType"
#define kContextLineName        @"LineName"
#define kContextLineNumber      @"LineNumber"
#define kContextStationNumber   @"StationNumber"
#define kContextVaultPath       @"VaultPath"
#define kContextCsvPath         @"CsvLogPath"
#define kContextUartPath        @"UartLogPath"
#define kContextTestFlow        @"TestFlowPath"
#define kContextPdcaServer      @"PDCA_Server"
#define kContextSfcServer       @"SFC_server"
#define kContextSfcURL          @"SFC_URL"
#define kContextAppDir          @"Application_Dir"
#define kContextTMVersion       @"TM_Version"

#define kContextID              @"uid"
#define kContextUsbLocation     @"USBlocation"
#define kContextMLBSN           @"MLB_SN"
#define kContextCFG             @"CFG"
#define kContextStartTime       @"StartTime"
#define kContextStopTime        @"StopTime"
#define kContextTotalTime       @"TotalTime"
#define kContextEnableTest      @"IsEnableTest"


#define kContextPanelSN         @"kContextPanelSN"
#define kContextBuildEvent      @"kContextBuildEvent"
#define kContextSBuild          @"kContextSBuil"


#define kContextFixtureID       @"FixtureID"

#define kContextCBAuthStationNameToCheck    @"CBAuthStationNameToCheck"
#define kContextCBAuthNumberToCheck         @"CBAuthNumberToCheck"
#define kContextCBAuthMaxFailForStation     @"CBAuthMaxFailForStation"
#define kContextCBAuthToClearOnPass         @"CBAuthToClearOnPass"
#define kContextCBAuthToClearOnFail         @"CBAuthToClearOnFail"
#define kContextCBAuthStationSetControlBit  @"CBAuthStationSetControlBit"

@interface UIContext : NSObject{
    NSMutableDictionary * m_dicContext;
}
+(id)getGlobal:(NSString *)key;
+(void)setGlobal:(id)value forKey:(NSString *)key;
-(id)getContext:(NSString *)key;
-(void)setContext:(id)value forKey:(NSString *)key;
@end
