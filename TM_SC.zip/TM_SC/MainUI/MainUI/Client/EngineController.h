//
//  EngineController.h
//  MainUI
//
//  Created by xuqian on 22/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Client.h"

@interface EngineController : Client{
        int m_Index;
}
-(id)initWithIndex:(int)index;

@end
