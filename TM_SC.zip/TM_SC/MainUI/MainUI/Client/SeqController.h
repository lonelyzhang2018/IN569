//
//  SeqController.h
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Client.h"


/*
typedef enum __SEQUENCER_EVENT{
    SEQUENCE_START = 0,
    SEQUENCE_END = 1,
    ITEM_START = 2,
    ITEM_FINISH = 3,
    ATTRIBUTE_FOUND = 4,
}SEQ_EVENT;
 */

@interface SeqController : Client{
    int m_Index;
    
    NSMutableArray * arrZmqMsg;
    NSLock * m_lock;
}
-(id)initWithIndex:(int)index;
-(int)LoadProfile:(NSString *)profile;
-(NSString *)ListItem;

//debugger
-(void)AddBreak:(int)index;
-(NSArray *)ListBreak;
-(int)Step;
-(int)Continue;
-(NSString *)PrintVariable:(NSString *)key;
@end
