//
//  StateMachineHeartbeat.h
//  MainUI
//
//  Created by xuqian on 23/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Client.h"

@interface StateMachineHeartbeat : Client

@end
