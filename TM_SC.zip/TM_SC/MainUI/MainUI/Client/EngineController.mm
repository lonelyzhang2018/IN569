//
//  EngineController.m
//  MainUI
//
//  Created by xuqian on 22/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "EngineController.h"
#include "WatchDog.h"

#define ENGINE_PORT             @"TEST_ENGINE_PORT"
#define ENGINE_PUB              @"TEST_ENGINE_PUB"
#define ENGINE_ADDRESS          @"tcp://127.0.0.1"

extern WatchDog * watchDog;
@implementation EngineController
-(id)init
{
    self = [super init];
    if (self) {
        m_Index = 0;
    }
    return  self;
}

-(id)initWithIndex:(int)index
{
    self =[super init];
    if (self) {
        m_Index = index;
    }
    return self;
}

-(void)OnSubscriberData:(NSString *)msg
{
    //    NSLog(@"%s",p);
    NSArray * arrContext = [msg componentsSeparatedByString:@"!@#"];
    id d = [arrContext objectAtIndex:2];
    if (!d) {
        return;
    }
    int level = [d intValue];
    if (level == 3 ) {
        id msg = [arrContext objectAtIndex:4];
        if (!msg) {
            return;
        }
        if ([msg rangeOfString:@"HEARTBEAT"].location != NSNotFound) { //Heart Beat
            [watchDog feedEngineWatchDog:m_Index];
        }
    }
    if (level>0)    //not data message
    {
        return ;
    }
    
    return;
    
}

-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if (!ipRequest) {
        ipRequest = [Client GetZmqPort:ENGINE_PORT];
        ipRequest = [NSString stringWithFormat:@"%@:%d",ENGINE_ADDRESS,[ipRequest intValue]+m_Index];
    }
    
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:ENGINE_PUB];
        ipSubscriber = [NSString stringWithFormat:@"%@:%d",ENGINE_ADDRESS,[ipSubscriber intValue]+m_Index];
    }
    
    [super SetFilter:@"101"];
    [super CreateRPC:nil withSubscriber:ipSubscriber];  //no need request
    
    return 0;
}

@end
