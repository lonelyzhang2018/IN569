//
//  Client.h
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Requester.hpp"
#include "Subscriber.hpp"

#pragma once

#define JSON_RPC        @"1.0"

#define kFunction        @"function"
#define kParams          @"params"
#define kId              @"id"
#define kJsonrpc         @"jsonrpc"
#define kResult          @"result"
#define kError           @"error"

@interface Client : NSObject{
    @private
    CRequester * pRequester;
    CSubscriber * pSubscriber;
}


-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber;
-(int)SendCmd:(NSString *)cmd;
-(NSString *)RecvRquest;

-(void)OnSubscriberData:(NSString *)msg;
-(void)SetFilter:(NSString *)filter;
+(NSString *)CreateRequestString:(NSDictionary *)dic;
+(NSString *)GetZmqPort:(NSString *)name;


@end
