//
//  SNManagerController.h
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma once
#include "Client.h"
@interface SNManagerController : Client{
    int m_Index;
}

-(id)initWithIndex:(int)index;

-(void)SetSn:(NSString *)sn;
-(NSString *)GetSn;
-(void)Clear;

@end
