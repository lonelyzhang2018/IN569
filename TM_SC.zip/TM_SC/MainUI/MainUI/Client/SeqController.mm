//
//  SeqController.m
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "SeqController.h"
#include "RegexKitLite.h"

#include "UICommon.h"

#include "WatchDog.h"

#define SEQUENCER_PORT      @"SEQUENCER_PORT"
#define SEQUENCER_PUB       @"SEQUENCER_PUB"

#define SEQUENCER_ADDRESS   @"tcp://127.0.0.1"


extern WatchDog * watchDog;

@implementation SeqController
-(id)init
{
    self = [super init];
    if (self) {
        m_Index = 0;
        arrZmqMsg = [[NSMutableArray alloc]init];
        m_lock = [[NSLock alloc]init];
        [NSThread detachNewThreadSelector:@selector(msgThread) toTarget:self withObject:nil];
    }
    return  self;
}

- (void)dealloc
{
    [arrZmqMsg release];
    [m_lock release];
    [super dealloc];
}

-(id)initWithIndex:(int)index
{
    self =[super init];
    if (self) {
        m_Index = index;
        arrZmqMsg = [[NSMutableArray alloc]init];
        m_lock = [[NSLock alloc]init];
        [NSThread detachNewThreadSelector:@selector(msgThread) toTarget:self withObject:nil];
    }
    return self;
}

-(void)OnSubscriberData:(NSString *)msg
{
    NSLog(@" > > > %@ < < < ",msg);
    [m_lock lock];
    [arrZmqMsg addObject:msg];
    [m_lock unlock];
}

- (void)msgThread
{
    NSMutableArray * tmp = [[NSMutableArray alloc]init];
    while(1)
    {
        if([arrZmqMsg count]==0)
        {
            [NSThread sleepForTimeInterval:0.1];
            [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            continue;
        }
        [m_lock lock];
        [tmp addObjectsFromArray: arrZmqMsg];
        [arrZmqMsg removeAllObjects];
        [m_lock unlock];
    
        NSInteger len = [tmp count];
        NSLog(@" > > > %ld < < <",len);
        for(NSInteger i=0; i<len; i++)
        {
            NSString * msg = [tmp objectAtIndex:i];
            NSArray * arrContext = [msg componentsSeparatedByString:@"!@#"];
            id d = [arrContext objectAtIndex:2];
            if (!d) {
                continue;
            }
            int level = [d intValue];
            if (level == 3 ) {
                id msg = [arrContext objectAtIndex:4];
                if (!msg) {
                    continue;
                }
                if ([msg isEqualToString:@"FCT_HEARTBEAT"]) { //Heart Beat
                    [watchDog feedSequencerWatchDog:m_Index];
                }
            }
            if (level>0)    //not data message
            {
                continue ;
            }
            NSString * message = [arrContext objectAtIndex:4];
    
            NSData * data = [message dataUsingEncoding:NSUTF8StringEncoding];
            NSError * err;
            id object =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
            if (!object) {
                NSLog(@"Error,Covnert JSON String failed,Invalide data format:%@",[err description]);
                NSLog(@"JSon string is : %@",message);
            }
    
            id event = [object valueForKey:@"event"];
            if (!event) {
                NSLog(@"Error,Invalide data format!Couldn't found 'event' key in :%@",[object description]);
            }
    
//    NSLog(@"Sequencer_%d Event : %@",m_Index,[object description]);
    
            int evt = [event intValue];
            if (evt == 4) {
//        return ;//skip attribute event.
            }

            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            [dic setValue:[NSNumber numberWithInt:m_Index] forKey:@"id"];
            [dic setValuesForKeysWithDictionary:[object valueForKey:@"data"]];
    

    //NSLog(@"%@",object);
            NSString * strNotification[] = {kNotificationOnTestStart,kNotificationOnTestFinish,kNotificationOnTestItemStart,kNotificationOnTestItemFinish,kNotificationOnAttribute};
    
            if ((evt == 1) || (evt == 6))   //SEQ_END or UOP
            {
                int state = [[dic valueForKey:@"result"] intValue];
                if (state<0) {  //get some error
            
                    [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationOnTestError object:nil userInfo:dic];
                    continue;
                }
            }

//            [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
//            [NSThread sleepForTimeInterval:0.01];
                [[NSNotificationCenter defaultCenter] postNotificationName:strNotification[evt] object:nil userInfo:dic];
        }
        [tmp removeAllObjects];
    }
    return;
}

-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if (!ipRequest) {
        ipRequest = [Client GetZmqPort:SEQUENCER_PORT];
        ipRequest = [NSString stringWithFormat:@"%@:%d",SEQUENCER_ADDRESS,[ipRequest intValue]+m_Index];
    }
    
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:SEQUENCER_PUB];
        ipSubscriber = [NSString stringWithFormat:@"%@:%d",SEQUENCER_ADDRESS,[ipSubscriber intValue]+m_Index];
    }
    
    
    
    [super SetFilter:@"101"];
    [super CreateRPC:ipRequest withSubscriber:ipSubscriber];
    
    return 0;
}

-(int)LoadProfile:(NSString *)profile
{
    profile = [profile stringByResolvingSymlinksInPath];
    if (![profile isAbsolutePath]) {
        NSString * path = [[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"Profile"];
        profile = [[path stringByAppendingPathComponent:profile] stringByResolvingSymlinksInPath];
    }
    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"load" forKey:kFunction];
    [dic setValue:[NSArray arrayWithObject:profile] forKey:kParams];
    [dic setValue:JSON_RPC forKey:kJsonrpc];
    
    uuid_t uuid;
    char str[36];
    uuid_generate(uuid);
    uuid_unparse(uuid, str);
    [dic setValue:[NSString stringWithFormat:@"%ld",random()] forKey:kId];
    
    
    //Convert dic to JSON string
    NSString * cmd = [Client CreateRequestString:dic];
    if (!cmd) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d",m_Index] reason:[NSString stringWithFormat:@"Create Json string failed, with profile:%@",profile]  userInfo:nil];
    }
    
    //Send to sequencer
    int ret = [self SendCmd:cmd];
    if  (ret<0)
    {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d",m_Index] reason:[NSString stringWithFormat:@"Send cmd to sequencer server failed,please check it's running, with cmd:%@",cmd]  userInfo:nil];
    }
    
    //send scuccessful
    if (ret>0) {
        //Read response
        NSString * response = [self RecvRquest];
        
        if (!response) {    //Not response
            @throw [NSException exceptionWithName:@"Sequencer Error" reason:@"Sequencer not response,pleaase check sequencer is running." userInfo:nil];
        }
        
        //Parse response
        NSData * data = [response dataUsingEncoding:NSUTF8StringEncoding];
        NSError * err;
        id object =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
        if (!object) {
            @throw [NSException exceptionWithName:@"Sequencer Error" reason:[err description] userInfo:nil];
        }
        
        
        NSDictionary * dic = (NSDictionary *)object;
        NSString * error = [dic valueForKey:kError];
        //get some error
        if (error) {
            @throw [NSException exceptionWithName:@"Sequencer Error" reason:error userInfo:nil];
        }
        
        NSString * result = [dic valueForKey:kResult];
        NSLog(@"%@",result);
        
        return 0;
    }
    
    return -1;
}

-(NSString *)captureJson:(NSString *)buffer withKey:(NSString *)key writeToDic:(NSMutableDictionary *)dic
{
    NSString * cap = [NSString stringWithFormat:@"\"%@\"\\s*:\\s*\"(.*?)\"[,}]",key];
    NSString * strret = [buffer stringByMatching:cap capture:1];
    if (strret) {
        [dic setValue:strret forKey:key];
    }
    return strret;
}

-(NSDictionary *)ParserItem:(NSString *)item
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [self captureJson:item withKey:@"GROUP" writeToDic:dic];
    [self captureJson:item withKey:@"DESCRIPTION" writeToDic:dic];
    [self captureJson:item withKey:@"LOW" writeToDic:dic];
    [self captureJson:item withKey:@"HIGH" writeToDic:dic];
    [self captureJson:item withKey:@"UNIT" writeToDic:dic];
    [self captureJson:item withKey:@"TID" writeToDic:dic];
    
    return dic;
}

//Check Items
-(bool)CheckItem:(NSArray * )arrItems
{
    for (int i=1; i<[arrItems count]; i++) {
        NSArray * arrItem = [arrItems objectAtIndex:i];
        NSString * item = [arrItem objectAtIndex:1];
        
        NSDictionary *dicItem = [self ParserItem:item];
        NSString * group = [dicItem valueForKey:@"GROUP"];
        NSString * tid = [dicItem valueForKey:@"TID"];
        
        for (int j=i+1; j<[arrItems count]; j++) {
            NSArray * arrItem = [arrItems objectAtIndex:j];
            NSString * item = [arrItem objectAtIndex:1];
            
            NSDictionary *dicItem = [self ParserItem:item];
            NSString * group2 = [dicItem valueForKey:@"GROUP"];
            NSString * tid2 = [dicItem valueForKey:@"TID"];
            
            if ([group isEqualToString:group2] && [tid isEqualToString:tid2]) {
                @throw [NSException exceptionWithName:@"Duplicate Item Name" reason:[NSString stringWithFormat:@"Duplication item group name and TID,with item: %@",[dicItem description]] userInfo:nil];
                return NO;
            }
        }
    }
    return YES;
}


//Build array items to string
-(NSString *)ParseProfile:(NSArray * )arrItems
{
    NSString * curr_group = @"";
    NSMutableString * strItems = [NSMutableString stringWithString:@""];
    for (int i=0; i<[arrItems count]; i++) {
        if (i) {//skip first one
            NSArray * arrItem = [arrItems objectAtIndex:i];
            NSString * item = [arrItem objectAtIndex:1];
            
            NSDictionary *dicItem = [self ParserItem:item];
            
            //NSDictionary * dicItem = [m_Sequencer ParseRespone:item];
            
            NSString * group = [dicItem valueForKey:@"GROUP"];
            if (![group isEqualToString:curr_group ]) {
                //Create new group
                [strItems appendFormat:@"key\t%@\r\n",group];
                curr_group = group;
            }
            
            //add sub item
            //item tid name lower upper unit
            /*
             NSString *index       = [arr objectAtIndex:0];
             NSString *description = [arr objectAtIndex:1];
             NSString *lower       = [arr count] > 2 ? [arr objectAtIndex:2] : nil;
             NSString *upper       = [arr count] > 3 ? [arr objectAtIndex:3] : nil;
             NSString *unit        = [arr count] > 4 ? [arr objectAtIndex:4] : nil;
             NSString *testkey     = [arr count] > 6 ? [arr objectAtIndex:6] : nil;
             */
            [strItems appendFormat:@"item\t%d\t%@\t%@\t%@\t%@\t\t%@\r\n",i,[dicItem valueForKey:@"DESCRIPTION"],[dicItem valueForKey:@"LOW"],[dicItem valueForKey:@"HIGH"],[dicItem valueForKey:@"UNIT"],[dicItem valueForKey:@"TID"]];
        }
        // NSLog(@"%@",[arrItems objectAtIndex:i]);
    }
    
    return strItems;
}

//decode a JSON string to dictinoary
-(NSDictionary *)ParseRespone:(NSString *)response
{
    id object=nil;
    if (!response) {
        return nil;
    }
    
    response = [response stringByReplacingOccurrencesOfString:@"'" withString:@"\\\""];
    
    NSData * data = [response dataUsingEncoding:NSUTF8StringEncoding];
    NSError * err;
    object =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    
    return object;
}

-(NSString *)ListItem
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"list" forKey:kFunction];
    
    uuid_t uuid;
    char str[36];
    uuid_generate(uuid);
    uuid_unparse(uuid, str);
    [dic setValue:[NSString stringWithFormat:@"%ld",random()] forKey:kId];
    [dic setValue:JSON_RPC forKey:kJsonrpc];
    [dic setValue:[NSArray arrayWithObject:@"all"] forKey:kParams];
    
    NSString * cmd = [Client CreateRequestString:dic];
    
    //Send to sequencer
    int ret = [self SendCmd:cmd];
    if  (ret<0)
    {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d Error",m_Index] reason:[NSString stringWithFormat:@"Send cmd to sequencer server failed,please check it's running, with cmd:%@",cmd]  userInfo:nil];
    }
    
    if (ret<0) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d Error",m_Index] reason:@"Send cmd to sequencer failed!" userInfo:nil];
    }
    //send scuccessful
    if (ret>0) {
        //Read response
        NSString * response = [self RecvRquest];
        
        if (!response) {    //Not response
            @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d Error",m_Index] reason:@"Sequencer not response,pleaase check sequencer is running." userInfo:nil];
        }
        
        //Parse response
        NSDictionary * dic_response = [self ParseRespone:response];
        if (!dic_response) {
            @throw [NSException exceptionWithName:[NSString stringWithFormat:@"Sequencer_%d Error",m_Index] reason:[NSString stringWithFormat:@"decode response from sequencer failed,response:\r\n%@",response] userInfo:nil];
        }
        
        NSArray * arrItems = [dic_response valueForKey:kResult];
        
        //[self CheckItem:arrItems];//Check duplcate item;
        
        NSString * strItem = [self ParseProfile:arrItems];
        //NSLog(@"%@",[dic description]);
        return strItem;
    }

    return nil;
}


@end
