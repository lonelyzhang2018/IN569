//
//  PuddingHeartbeat.h
//  MainUI
//
//  Created by IvanGan on 25/3/16.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Client.h"

@interface PuddingHeartbeat : Client

@end
