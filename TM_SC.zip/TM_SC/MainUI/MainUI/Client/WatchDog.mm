//
//  WatchDog.m
//  MainUI
//
//  Created by Ryan on 12/13/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "WatchDog.h"

#include "StartUpInfor.h"

extern StartUpInfor * pStartUpInfor;

#define WATCH_TIMES                         3

#define SEQUENCER_WATCHDOG_INTERVAL         5.0 * WATCH_TIMES
#define DATALOG_WATCHDOG_INTERVAL           5.0 * WATCH_TIMES
#define ENGINE_WATCHDOG_INTERVAL            5.0 * WATCH_TIMES

#define STATEMACHINE_WATCHDOG_INTERVAL      5.0 * WATCH_TIMES
#define PUDDING_WATCHDOG_INTERVAL      10.0 * WATCH_TIMES

typedef enum {
    CTRL_ID_SEQUENCER=0,
    CTRL_ID_ENGINE,
    CTRL_ID_STATEMACHINE,
    CTRL_ID_PUDDING,
}WATCHDOG_CTRL_ID;

WatchDog * watchDog = nil;

@implementation WatchDog
-(void)awakeFromNib
{
    watchDog = self;
    m_SlotNumber = pStartUpInfor.Slot_Number;
    pSequencerWatchDog = new NSTimeInterval[m_SlotNumber];
    pEngneWatchDog = new NSTimeInterval[m_SlotNumber];
//    pDataLogWatchDog = new NSTimeInterval[m_SlotNumber];
    
    [self feedStatemachineWatchDog];
    [self feedPuddingWatchDog];
    for (int i=0;i<m_SlotNumber;i++)
    {
        [self feedSequencerWatchDog:i];
        [self feedEngineWatchDog:i];
//        [self feedDataLogWatchDog:i];
    }
    
    NSTextField * txtEngine[] = {txtEngine0,txtEngine1,txtEngine2,txtEngine3,txtEngine4,txtEngine5};
    NSTextField * txtSequencer[] = {txtSequencer0,txtSequencer1,txtSequencer2,txtSequencer3,txtSequencer4,txtSequencer5};
//    NSTextField * txtDatalog[] = {txtDatalog0,txtDatalog1,txtDatalog2,txtDatalog3,txtDatalog4,txtDatalog5};
    
    for (int i=m_SlotNumber;i<6;i++)
    {
        [txtEngine[i] setHidden:YES];
        [txtSequencer[i] setHidden:YES];
//        [txtDatalog[i] setHidden:YES];
    }
    
    timerWatchDog = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(OnWatchTimer:) userInfo:nil repeats:YES];
    [timerWatchDog fire];
    
    //[NSThread detachNewThreadSelector:@selector(threadWatchDog) toTarget:self withObject:nil];
}

-(void)threadWatchDog
{
    while(true)
    {
        [NSThread sleepForTimeInterval:5.0];
        [self OnWatchTimer:nil];
    }
}

-(void)feedSequencerWatchDog:(int)index
{
    pSequencerWatchDog[index] = [NSDate timeIntervalSinceReferenceDate];    //reset time statmp
}

-(void)feedStatemachineWatchDog
{
    StatemachineWatchDog = [NSDate timeIntervalSinceReferenceDate]; //reset time stamp
}

-(void)feedEngineWatchDog:(int)index
{
    pEngneWatchDog[index] = [NSDate timeIntervalSinceReferenceDate]; //reset time stamp
}

-(void)feedDataLogWatchDog:(int)index
{
//    pDataLogWatchDog[index] = [NSDate timeIntervalSinceReferenceDate]; //reset time stamp
}

-(void)feedPuddingWatchDog
{
    PuddingWatchDog = [NSDate timeIntervalSinceReferenceDate]; //reset time stamp
}

-(void)UpdataControl:(id)sender
{
    int ctrl_id = [[sender valueForKey:@"ctrl_id"] intValue];
    int index = [[sender valueForKey:@"object"] intValue];
    int state = [[sender valueForKey:@"state"] intValue];
    
    
    NSTextField * txtSequencer[]={txtSequencer0,txtSequencer1,txtSequencer2,txtSequencer3,txtSequencer4,txtSequencer5};
    NSTextField * txtEngine[]={txtEngine0,txtEngine1,txtEngine2,txtEngine3,txtEngine4,txtEngine5};
//    NSTextField * txtDatalog[]={txtDatalog0,txtDatalog1,txtDatalog2,txtDatalog3,txtDatalog4,txtDatalog5};
    
    NSTextField * txtCtrl = nil;
    switch (ctrl_id) {
        case CTRL_ID_SEQUENCER:
            txtCtrl = txtSequencer[index];
            break;
        case CTRL_ID_ENGINE:
            txtCtrl = txtEngine[index];
            break;
        case CTRL_ID_STATEMACHINE:
            txtCtrl = txtStateMachine;
            break;
        case CTRL_ID_PUDDING:
            txtCtrl = txtPudding;
            break;
        default:
            break;
    }
    
    if (state) {    //still alive,flash
        long tag = [txtCtrl tag];
        [txtCtrl setHidden:tag];
        [txtCtrl setTag:!tag];
        if (!tag)
        {
            int x= 0;
        }
    }
    else
    {
        [txtCtrl setHidden:NO];
    }
    
    [txtCtrl setBackgroundColor:state?[NSColor greenColor]:[NSColor redColor]];
}


-(void)OnWatchTimer:(id)sender
{
    //WatchDog timer
    
    //Sequencer Watch Dog
    NSTimeInterval d = [NSDate timeIntervalSinceReferenceDate];
    //state machine
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:[NSNumber numberWithInt:CTRL_ID_STATEMACHINE] forKey:@"ctrl_id"];
    [dic setValue:@"0" forKey:@"object"];   //no use
    NSTimeInterval LastWatch =StatemachineWatchDog;
    [dic setValue:[NSNumber numberWithInt:(d-LastWatch)<=STATEMACHINE_WATCHDOG_INTERVAL] forKey:@"state"];
    [self performSelectorOnMainThread:@selector(UpdataControl:) withObject:dic waitUntilDone:NO];
    NSMutableDictionary * dic1 = [NSMutableDictionary dictionary];
    [dic1 setValue:[NSNumber numberWithInt:CTRL_ID_PUDDING] forKey:@"ctrl_id"];
    NSTimeInterval pudLastWatch =PuddingWatchDog;
    [dic1 setValue:[NSNumber numberWithInt:(d-pudLastWatch)<=PUDDING_WATCHDOG_INTERVAL] forKey:@"state"];
    [self performSelectorOnMainThread:@selector(UpdataControl:) withObject:dic1 waitUntilDone:NO];
    
    for (int i=0; i<m_SlotNumber; i++) {
        
        NSTimeInterval * pLastWatchTime[] = {pSequencerWatchDog,pEngneWatchDog};
        NSTimeInterval pINTERVAL[] = {SEQUENCER_WATCHDOG_INTERVAL,ENGINE_WATCHDOG_INTERVAL};
        WATCHDOG_CTRL_ID pCTRL_ID[]= {CTRL_ID_SEQUENCER,CTRL_ID_ENGINE};
        
        
        for (int j=0; j<2; j++) {
            
            NSMutableDictionary * dic = [NSMutableDictionary dictionary];
            [dic setValue:[NSNumber numberWithInt:pCTRL_ID[j]] forKey:@"ctrl_id"];
            [dic setValue:[NSNumber numberWithInt:i] forKey:@"object"];
            NSTimeInterval LastWatch =pLastWatchTime[j][i];
            [dic setValue:[NSNumber numberWithInt:(d-LastWatch)<=pINTERVAL[j]] forKey:@"state"];
            [self performSelectorOnMainThread:@selector(UpdataControl:) withObject:dic waitUntilDone:NO];
            
        }
    }
}

@end
