//
//  StateMachineHeartbeat.m
//  MainUI
//
//  Created by xuqian on 23/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "StateMachineHeartbeat.h"

#include "WatchDog.h"


#define STATE_MACHINE_ADDRESS   @"tcp://127.0.0.1"
#define SM_PORT                 @"SM_PORT"
#define SM_HEARTBEAT            @"SM_HEARTBEAT"


extern WatchDog * watchDog;
@implementation StateMachineHeartbeat
-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if  (!ipRequest)
    {
        ipRequest = [Client GetZmqPort:SM_PORT];
        if (!ipRequest) {
            return -1;
        }
    }
    
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:SM_HEARTBEAT];
        if (!ipSubscriber) {
            return -2;
        }
    }
    
    
    NSString * address = [NSString stringWithFormat:@"%@:%d",STATE_MACHINE_ADDRESS,[ipRequest intValue]];
    
    //Subscriber
    NSString * address2 = [NSString stringWithFormat:@"%@:%d",STATE_MACHINE_ADDRESS,[ipSubscriber intValue]];
    [super SetFilter:@"101"];
    [super CreateRPC:nil withSubscriber:address2];  //no need request
    
    return 0;
}

-(void)OnSubscriberData:(NSString *)msg
{
    //    NSLog(@"%s",p);
    NSArray * arrContext = [msg componentsSeparatedByString:@"!@#"];
    id d = [arrContext objectAtIndex:2];
    if (!d) {
        return;
    }
    int level = [d intValue];
    if (level == 3 ) {
        id msg = [arrContext objectAtIndex:4];
        if (!msg) {
            return;
        }
        if ([msg rangeOfString:@"HEARTBEAT"].location != NSNotFound) { //Heart Beat
            NSLog(@"State Machine HeartBeat!");
            [watchDog feedStatemachineWatchDog];
        }
    }
    if (level>0)    //not data message
    {
        return ;
    }
    return;
    
}

@end
