//
//  SMController.m
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "SMController.h"

#include "UICommon.h"
#define SM_PORT     @"SM_PORT"
#define SM_PUB     @"SM_PUB"

#define STATE_MACHINE_ADDRESS   @"tcp://127.0.0.1"

@implementation SMController


-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if  (!ipRequest)
    {
        ipRequest = [Client GetZmqPort:SM_PORT];
        if (!ipRequest) {
            return -1;
        }
    }
    
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:SM_PUB];
        if (!ipSubscriber) {
            return -2;
        }
    }
    
    
    NSString * address = [NSString stringWithFormat:@"%@:%d",STATE_MACHINE_ADDRESS,[ipRequest intValue]];
    
    //Subscriber
    NSString * address2 = [NSString stringWithFormat:@"%@:%d",STATE_MACHINE_ADDRESS,[ipSubscriber intValue]];

    [super CreateRPC:address withSubscriber:address2];
    
    return 0;
}

-(void)OnSubscriberData:(NSString *)msg
{
    //    NSLog(@"%s",p);
    NSData * data = [msg dataUsingEncoding:NSUTF8StringEncoding];
    NSError * err;
    id object =  [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
    if (!object) {
        NSLog(@"Error,Convert JSON String failed,Invalide data format:%@",[err description]);
        NSLog(@"JSON string is : %@",msg);
    }
    
    NSString * fun = [object valueForKey:@"function"];
    if (!fun) {
        return;
    }
    
    NSLog(@"StateMachine Message : %@",msg);
    
    if ([fun isEqualToString:@"SM_TESTING"]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationOnEngineStart object:nil];
    }
    else if ([fun isEqualToString:@"SM_TESTING_DONE"])
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationOnEngineFinish object:nil];
    }
    return;
    
}

-(int)SendCmd:(NSString *)cmd
{
    [self CreateRPC:nil withSubscriber:nil];
    return [super SendCmd:cmd];
}

-(BOOL)SetUutState:(int)state atSlot:(int)slot
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"UUTENABLE" forKey:@"function"];
    [dic setValue:[NSNumber numberWithInt:slot] forKey:@"uut"];
    [dic setValue:[NSNumber numberWithInt:state] forKey:@"enable"];
    
    
    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:[NSString stringWithFormat:@"Send to state machine failed,with cmd:%@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:@"State Machine not response,please check state machine" userInfo:nil];
    }
    
    NSLog(@"set uut%d state:%d %@",slot,state,response);
    return  YES;
}

-(BOOL)SetUutState_WithSN:(int)state atSlot:(int)slot withSN:(NSString *)sn
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"UUTENABLE" forKey:@"function"];
    [dic setValue:[NSNumber numberWithInt:slot] forKey:@"uut"];
    [dic setValue:[NSNumber numberWithInt:state] forKey:@"enable"];
    [dic setValue:sn forKey:@"sn"];
    
    
    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:[NSString stringWithFormat:@"Send to state machine failed,with cmd:%@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:@"State Machine not response,please check state machine" userInfo:nil];
    }
    
    NSLog(@"set uut%d state:%d %@",slot,state,response);
    return  YES;
}

-(BOOL)SetUutSn:(NSString *)sn atSlot:(int)slot
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"SETUUTSN" forKey:@"function"];
    [dic setValue:[NSNumber numberWithInt:slot] forKey:@"uut"];
    [dic setValue:sn forKey:@"sn"];
    
    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:[NSString stringWithFormat:@"Send to state machine failed,with cmd:%@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:@"State Machine Error" reason:@"State Machine not response,please check state machine" userInfo:nil];
    }
    
    NSLog(@"set uut%d sn:%@ %@",slot,sn,response);
    return  YES;
}

-(BOOL)Run
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"START" forKey:@"function"];
    //[dic setValue:[NSArray array] forKey:@"times"];
    
    
    NSString * cmd = [Client CreateRequestString:dic];
    [self SendCmd:cmd];
    //[self SendCmd:@"START"];
    return YES;
}

-(BOOL)Stop
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"ABORT" forKey:@"function"];

    NSString * cmd = [Client CreateRequestString:dic];
    [self SendCmd:cmd];
    return YES;
}

@end
