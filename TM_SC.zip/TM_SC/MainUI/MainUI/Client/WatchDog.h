//
//  WatchDog.h
//  MainUI
//
//  Created by Ryan on 12/13/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "Subscriber.hpp"
#pragma once

@interface WatchDog : NSObject{
    IBOutlet NSTextField * txtSequencer0;
    IBOutlet NSTextField * txtSequencer1;
    IBOutlet NSTextField * txtSequencer2;
    IBOutlet NSTextField * txtSequencer3;
    IBOutlet NSTextField * txtSequencer4;
    IBOutlet NSTextField * txtSequencer5;
    
    IBOutlet NSTextField * txtStateMachine;
    
    IBOutlet NSTextField * txtEngine0;
    IBOutlet NSTextField * txtEngine1;
    IBOutlet NSTextField * txtEngine2;
    IBOutlet NSTextField * txtEngine3;
    IBOutlet NSTextField * txtEngine4;
    IBOutlet NSTextField * txtEngine5;
    
    IBOutlet NSTextField * txtDatalog0;
    IBOutlet NSTextField * txtDatalog1;
    IBOutlet NSTextField * txtDatalog2;
    IBOutlet NSTextField * txtDatalog3;
    IBOutlet NSTextField * txtDatalog4;
    IBOutlet NSTextField * txtDatalog5;
    
    IBOutlet NSTextField * txtPudding;
    
    NSTimer * timerWatchDog;
    
    NSTimeInterval * pSequencerWatchDog;
    NSTimeInterval * pEngneWatchDog;
    
//    NSTimeInterval * pDataLogWatchDog;
    NSTimeInterval StatemachineWatchDog;
    
    NSTimeInterval PuddingWatchDog;
    
    int m_SlotNumber;
}


-(void)feedSequencerWatchDog:(int)index;
-(void)feedStatemachineWatchDog;

-(void)feedEngineWatchDog:(int)index;
-(void)feedDataLogWatchDog:(int)index;

-(void)feedPuddingWatchDog;

@end
