//
//  SNManagerController.m
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "SNManagerController.h"

#define SN_MANAGER_PORT      @"SN_PORT"
#define SN_MANAGER_PUB       @"SN_PUB"

#define SN_MANAGER_ADDRESS   @"tcp://127.0.0.1"

@implementation SNManagerController
-(id)initWithIndex:(int)index
{
    self = [super init];
    if (self) {
        m_Index = index;
    }
    return self;
}

-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if (!ipRequest) {
        ipRequest = [Client GetZmqPort:SN_MANAGER_PORT];
        ipRequest = [NSString stringWithFormat:@"%@:%d",SN_MANAGER_ADDRESS,[ipRequest intValue]+m_Index];
    }
    
    /*
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:SN_MANAGER_PUB];
        ipSubscriber = [NSString stringWithFormat:@"%@:%d",SN_MANAGER_ADDRESS,[ipSubscriber intValue]+m_Index];
    }
     */
    
    [super CreateRPC:ipRequest withSubscriber:ipSubscriber];
    return 0;
}

-(void)SetSn:(NSString *)sn
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"set" forKey:kFunction];
    [dic setValue:sn forKey:@"sn"];

    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"Send to SN Manager failed! with cmd: %@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"SN Manager not response,please check that"] userInfo:nil];
    }
    
    NSLog(@"SN Manager%d response :%@",m_Index,response);
}

-(NSString *)GetSn
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"get" forKey:kFunction];
    
    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"Send to SN Manager failed! with cmd: %@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"SN Manager not response,please check that"] userInfo:nil];
    }
    
    NSLog(@"SN Manager%d response :%@",m_Index,response);
    return response;
}

-(void)Clear
{
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setValue:@"clear" forKey:kFunction];
    
    NSString * cmd = [Client CreateRequestString:dic];
    int ret = [self SendCmd:cmd];
    if (ret<0) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"Send to SN Manager failed! with cmd: %@",cmd] userInfo:nil];
    }
    
    NSString * response = [self RecvRquest];
    if (!response) {
        @throw [NSException exceptionWithName:[NSString stringWithFormat:@"SN Manager%d",m_Index] reason:[NSString stringWithFormat:@"SN Manager not response,please check that"] userInfo:nil];
    }
    
    NSLog(@"SN Manager%d response :%@",m_Index,response);
}
@end
