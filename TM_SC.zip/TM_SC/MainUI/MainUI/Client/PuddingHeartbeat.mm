//
//  PuddingHeartbeat.m
//  MainUI
//
//  Created by IvanGan on 25/3/16.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "PuddingHeartbeat.h"

#include "WatchDog.h"


#define PUDDING_ADDRESS     @"tcp://127.0.0.1"
#define PUDDING_HEARTBEAT   @"LOGGER_PUB"


extern WatchDog * watchDog;
@implementation PuddingHeartbeat
-(int)CreateRPC:(NSString *)ipRequest withSubscriber:(NSString *)ipSubscriber
{
    if (!ipSubscriber) {
        ipSubscriber = [Client GetZmqPort:PUDDING_HEARTBEAT];
        if (!ipSubscriber) {
            return -2;
        }
    }
    //Subscriber
    NSString * address2 = [NSString stringWithFormat:@"%@:%d",PUDDING_ADDRESS,[ipSubscriber intValue]];
    [super SetFilter:@"101"];
    [super CreateRPC:nil withSubscriber:address2];  //no need request
    
    return 0;
}

-(void)OnSubscriberData:(NSString *)msg
{
//        NSLog(@"%@",msg);
//    NSArray * arrContext = [msg componentsSeparatedByString:@"!@#"];
//    id d = [arrContext objectAtIndex:2];
//    if (!d) {
//        return;
//    }
//    int level = [d intValue];
//    if (level == 3 ) {
//        id msg = [arrContext objectAtIndex:4];
//        if (!msg) {
//            return;
//        }
        if ([msg rangeOfString:@"HEARTBEAT"].location != NSNotFound) { //Heart Beat
            NSLog(@"Pudding HeartBeat!");
            [watchDog feedPuddingWatchDog];
        }
//    }
//    if (level>0)    //not data message
//    {
//        return ;
//    }
    return;
    
}

@end
