//
//  SMController.h
//  MainUI
//
//  Created by xuqian on 15/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Client.h"

#pragma once
@interface SMController : Client

-(BOOL)SetUutState:(int)state atSlot:(int)slot;
-(BOOL)SetUutState_WithSN:(int)state atSlot:(int)slot withSN:(NSString *)sn;
-(BOOL)SetUutSn:(NSString *)sn atSlot:(int)slot;
-(BOOL)Run;
-(BOOL)Stop;
@end
