//
//  MyTableHeaderView.h
//  UI
//
//  Created by Ryan on 13-3-1.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MyTableHeaderView : NSTableHeaderView{
    IBOutlet NSMenu * popupMenu;
}

@end
