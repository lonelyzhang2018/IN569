//
//  DetailViewController.m
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "DetailViewController.h"
#include "UICommon.h"
#include "TestItem.h"

#include "uiOutlineViewDataSource.h"

#include "StartUpInfor.h"

extern StartUpInfor * pStartUpInfor;
@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    return;
    // Do view setup here.
}
-(void)awakeFromNib
{
    viewCurrent = viewBase;
    [scMode setSelectedSegment:0];
    [self btSegmentdControl:scMode];
    //[scMode sendAction:@selector(btSegmentdControl:) to:self];
    
    [self RegisterUINotification];
}

-(void)LoadSubView:(NSView *)view
{
    [[viewCurrent superview] replaceSubview:viewCurrent with:view];
    [view setFrame:[viewCurrent frame]];
    viewCurrent = view;
    //[self loadView];
}

-(IBAction)btSegmentdControl:(id)sender
{
    NSSegmentedControl  * control = (NSSegmentedControl *)sender;
    NSView * viewNew=nil;
    switch ([control selectedSegment]) {
        case 0:
        {
            uiOutlineViewDataSource * ov = [outlineView dataSource];
            [ov ShowFailOnly:NO :NO];
            viewNew = viewDetail;
            [self redisplayOutlineView:nil];
        }
            break;
        case 1:
            viewNew = viewProgress;
            break;
        case 2:
        {
            uiOutlineViewDataSource * ov = [outlineView dataSource];
            [ov ShowFailOnly:YES :NO];
            viewNew = viewDetail;
            [self redisplayOutlineView:nil];
        }
            break;
        case 3:
        {
            uiOutlineViewDataSource * ov = [outlineView dataSource];
            [ov ShowFailOnly:NO :YES];
            viewNew = viewDetail;
            [self redisplayOutlineView:nil];
        }
            break;
            
        default:
            break;
    }
    
    [self LoadSubView:viewNew];
}


#pragma mark User Interface Update entry function

#pragma mark User Interface Update entry function

//User Interface
-(int) OnEngineStart:(id)sender
{
    //Intial UI to prepare test...
    long index = 0;
    TestItem * pItem= nil;
    @synchronized(outlineView) {
        while (1) {
            id item = [[outlineView itemAtRow:index++]representedObject];
            if (!item) break;
            if ([item isKindOfClass:[KeyItem class]]) continue;
            pItem =(TestItem *)item;
            pItem.uut1_value=pItem.uut2_value=pItem.uut3_value=pItem.uut4_value=pItem.uut5_value=pItem.uut6_value=pItem.uut7_value=pItem.uut8_value=@"";
            pItem.state1=pItem.state2=pItem.state3=pItem.state4=pItem.state5=pItem.state6=pItem.state7=pItem.state8=-2; //idle
            pItem.time=@"";
        }
        [outlineView setNeedsDisplay];
        
        NSProgressIndicator * progress[] = {progressUnit0,progressUnit1,progressUnit2,progressUnit3,progressUnit4,progressUnit4,progressUnit5};
        
        for (int i=0; i<6; i++) {
            [progress[i] setDoubleValue:0];
        }
    }
    
    return 0;
}

-(int) OnEngineFinish:(id)sender
{
    return 0;
}


-(int) OnTestStart:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    int iID = [[dic valueForKey:@"id"] intValue];
    
    //Intial UI to prepare test...
    long index = 0;
    TestItem * pItem= nil;
    @synchronized(outlineView) {
        while (1) {
            id item = [[outlineView itemAtRow:index++]representedObject];
            if (!item) break;
            if ([item isKindOfClass:[KeyItem class]]) continue;
            pItem =(TestItem *)item;
            switch (iID) {
                case 0:
                    pItem.uut1_value = @"";
                    pItem.state1 = -2;
                    break;
                case 1:
                    pItem.uut2_value = @"";
                    pItem.state2 = -2;
                    break;
                case 2:
                    pItem.uut3_value = @"";
                    pItem.state3 = -2;
                    break;
                case 3:
                    pItem.uut4_value = @"";
                    pItem.state4 = -2;
                    break;
                case 4:
                    pItem.uut5_value = @"";
                    pItem.state5 = -2;
                    break;
                case 5:
                    pItem.uut6_value = @"";
                    pItem.state6 = -2;
                    break;
                case 6:
                    pItem.uut7_value = @"";
                    pItem.state7 = -2;
                    break;
                case 7:
                    pItem.uut8_value = @"";
                    pItem.state8 = -2;
                    break;
                default:
                    break;
            }
            pItem.time=@"";
        }
        [outlineView setNeedsDisplay];
        
        NSProgressIndicator * progress[] = {progressUnit0,progressUnit1,progressUnit2,progressUnit3,progressUnit4,progressUnit4,progressUnit5};
        
        for (int i=0; i<6; i++) {
            [progress[i] setDoubleValue:0];
        }
    }
    
    //progress view
    [[self ProgressBar:iID] setDoubleValue:0];
    
    return 0;
}
-(int) OnTestStop:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    return 0;
}
-(int) OnTestPasue:(id)sender
{
    return 0;
}
-(int) OnTestResume:(id)sender
{
    return 0;
}

-(id)FindItem:(NSString *)group withTID:(NSString *)tid atIndex:(long *)pIndex
{
    *pIndex=-1;
    id item = [[outlineView itemAtRow:0] parentNode];   //get root node
    for (NSTreeNode * node in [item childNodes])
    {
        if ([[node representedObject] isKindOfClass:[KeyItem class]]) {
            KeyItem * item = (KeyItem *)[node representedObject];
            if (![item.name isEqualToString:group]) {
                continue;   //not this group
            }
            for (NSTreeNode * sub in [node childNodes])
            {
                if ([[sub representedObject] isKindOfClass:[TestItem class]]) {
                    //check tid
                    TestItem * item = [sub representedObject];
                    if ([item.testkey isEqualToString:tid]) {
                        *pIndex = [outlineView rowForItem:sub];
                        return item;
                    }
                }
            }
        }
    }
    return nil;
}
NSString * current_group[8];
-(int) OnTestItemStart:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    int iID = [[dic valueForKey:@"id"] intValue];
    NSString * group = [dic valueForKey:@"group"];
    current_group[iID] = group;//save group name
    NSString * tid = [dic valueForKey:@"tid"];
    return 0;
    long index=-1;
    id item = [self FindItem:group withTID:tid atIndex:&index];
    if (!item) {
        NSLog(@"error, not match item!");
    }
    
    //int index = [[dic valueForKey:@"index"] intValue];
    //id item = [[outlineView itemAtRow:index] representedObject];
    if ([item isKindOfClass:[TestItem class]]) {
        TestItem * t = (TestItem *)item;
        switch (iID) {
            case 0:
                t.uut1_value = @"Testing...";
                break;
            case 1:
                t.uut2_value = @"Testing...";
                break;
            case 2:
                t.uut3_value = @"Testing...";
                break;
            case 3:
                t.uut4_value = @"Testing...";
                break;
            case 4:
                t.uut5_value = @"Testing...";
                break ;
            case 5:
                t.uut6_value = @"Testing...";
                break ;
            case 6:
                t.uut7_value = @"Testing...";
                break ;
            case 7:
                t.uut8_value = @"Testing...";
                break ;
            default:
                break;
        }
    }
    
    //
    //if ([btnShowTests state] == NSOnState)
    
    
    return 0;
}
-(int) OnTestItemFinish:(id)sender
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        [pool release];
        return 0;
    }
    
    //int index = [[dic valueForKey:@"index"] intValue];
    NSString * value = [dic valueForKey:@"value"];
    int state = [[dic valueForKey:@"result"] intValue];
    //NSString * strRemark = [dic valueForKey:@"remark"];
    int iID = [[dic valueForKey:@"id"] intValue];
    
    if (state<0) {
        value = [dic valueForKey:@"error"];
        if (!value) {
            value = @"UnKown Error Message";
        }
    }
    

    //NSString * group = [dic valueForKey:@"group"];
    NSString * tid = [dic valueForKey:@"tid"];
    long index=-1;
    id item = [self FindItem:current_group[iID] withTID:tid atIndex:&index];
    if (!item) {
        NSLog(@"error, not match item!");
    }
    
    NSLog(@"index : %ld value : %@ state : %d",index,value,state);
    
    //int index = [outlineView rowForItem:item];
    //id item = [[outlineView itemAtRow:index] representedObject];
    
    
    if ([item isKindOfClass:[TestItem class]]) {
        TestItem * t = (TestItem *)item;
        switch (iID) {
            case 0:
                t.uut1_value = value;
                t.state1 = state;
                break;
            case 1:
                t.uut2_value = value;
                t.state2 = state;
                break;
            case 2:
                t.uut3_value = value;
                t.state3 = state;
                break;
            case 3:
                t.uut4_value = value;
                t.state4 = state;
                break;
            case 4:
                t.uut5_value = value;
                t.state5 = state;
                break;
            case 5:
                t.uut6_value = value;
                t.state6 = state;
                break;
            case 6:
                t.uut7_value = value;
                t.state7 = state;
                break;
            case 7:
                t.uut8_value = value;
                t.state8 = state;
                break;
            default:
                break;
        }
    }
    //[outlineView scrollRowToVisible:index+1];
    //[outlineView reloadItem:item];
    //[outlineView setNeedsDisplay];
    
    if ([segShowType selectedSegment]==0)
    {
        @synchronized(outlineView)
        {
            scrollIndex = index;
            if (!scrollOutlineViewTaskTimer)
            {
                scrollOutlineViewTaskTimer = [NSTimer scheduledTimerWithTimeInterval:2
                                                                              target:self
                                                                            selector:@selector(scrollOutlineViewTimer:)
                                                                            userInfo:nil
                                                                             repeats:YES];
            }
        }
        //            [outlineView scrollRowToVisible:index+1];
        //            [outlineView setNeedsDisplay];
    }
    
    //progress view
    NSProgressIndicator * pbar = [self ProgressBar:iID];
    [pbar setDoubleValue:[pbar doubleValue]+1];
    return 0;
}
-(int) OnTestFinish:(id)sender
{
    
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    int iID = [[dic valueForKey:@"id"] intValue];
    
    //progress view
    NSProgressIndicator * pbar = [self ProgressBar:iID];
    [pbar setDoubleValue:[pbar maxValue]];
    
    return 0;
}
-(int) OnTestError:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    if (dic == nil) {
        return 0;
    }
    
    int iID = [[dic valueForKey:@"id"] intValue];
    NSString * strmsg = [dic valueForKey:@"error"];
    
    NSLog(@"[UUT%d ERROR]:%@",iID,strmsg);

    NSAlert * alert = [[NSAlert alloc] init];
    alert.messageText = [NSString stringWithFormat:@"UUT%d",iID+1];
    alert.informativeText = strmsg;
    [alert runModal];
    [alert release];
    
    //progress view
    NSProgressIndicator * pbar = [self ProgressBar:iID];
    [pbar setDoubleValue:[pbar maxValue]];
    return 0;
}

#pragma mark timer
-(void)UpdateElapsedTime:(id)arg
{

}
- (void)timerFireMethod:(NSTimer*)theTimer
{
}

- (void) scrollOutlineViewTimer:(NSTimer*) timer
{
    static long lastScrollIndex = -1;
    @synchronized(outlineView)
    {
        if (lastScrollIndex != scrollIndex)
        {
            [outlineView scrollRowToVisible:scrollIndex+1];
            [outlineView setNeedsDisplay];
        }
        lastScrollIndex = scrollIndex;
    }
}


-(void) redisplayOutlineView:(id)sender
{
    [outlineView reloadData];
    [outlineView expandItem:nil expandChildren:YES];
    [outlineView setNeedsDisplay];
}
-(NSProgressIndicator *)ProgressBar:(int)index
{
    NSArray * arrProgress = [NSArray arrayWithObjects:progressUnit0,progressUnit1,progressUnit2,progressUnit3,progressUnit4,progressUnit5, nil];
    return [arrProgress objectAtIndex:index];
}
-(int)OnLoadProfile:(id)sender
{
    NSTreeNode * items = [sender valueForKey:@"items"];
    NSArray * arr = [items childNodes]; //所有的测试项
    int count=0;
    for (NSTreeNode * item in arr)
    {
        count+=[[item childNodes] count];
    }
    
    NSArray * arrProgress = [NSArray arrayWithObjects:progressUnit0,progressUnit1,progressUnit2,progressUnit3,progressUnit4,progressUnit5, nil];
    for (NSProgressIndicator * progress in arrProgress) {
        [progress setMaxValue:count];
        [progress setMinValue:0];
        [progress setDoubleValue:0];
    }
    return 0;
}

-(IBAction)OnPopupMenu:(id)sender
{
    [sender setState:![sender state]];
    BOOL bState = [sender state];
    NSString * title = [sender title];
    NSTableColumn * col=nil;
    if ([title isEqualToString:@"Show Limited"])
    {
        col = [outlineView tableColumnWithIdentifier:@"lower"];
        [col setHidden:!bState];
        col = [outlineView tableColumnWithIdentifier:@"upper"];
        [col setHidden:!bState];
    }
    else if ([title isEqualToString:@"Show Time"])
    {
        col = [outlineView tableColumnWithIdentifier:@"time"];
        [col setHidden:!bState];
    }
    else if ([title isEqualToString:@"Show Description"])
    {
        col = [outlineView tableColumnWithIdentifier:@"description"];
        [col setHidden:!bState];
    }
//    else if ([title isEqualToString:@"Show Remark"])
//    {
//        col = [outlineView tableColumnWithIdentifier:@"remark"];
//        [col setHidden:!bState];
//    }
}

@end
