//
//  MyTableHeaderView.m
//  UI
//
//  Created by Ryan on 13-3-1.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MyTableHeaderView.h"

@implementation MyTableHeaderView
-(void)rightMouseUp:(NSEvent *)theEvent
{
    [NSMenu popUpContextMenu:popupMenu withEvent:theEvent forView:nil];
}
@end
