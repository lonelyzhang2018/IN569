//
//  DetailViewController.h
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "UIController.h"

@interface DetailViewController : UIController{
    IBOutlet NSView * viewProgress;
    IBOutlet NSView * viewDetail;
    IBOutlet NSView * viewBase;
    
    IBOutlet NSOutlineView *outlineView;
    IBOutlet NSSegmentedControl * scMode;
    
    IBOutlet NSProgressIndicator * progressUnit0;
    IBOutlet NSProgressIndicator * progressUnit1;
    IBOutlet NSProgressIndicator * progressUnit2;
    IBOutlet NSProgressIndicator * progressUnit3;
    IBOutlet NSProgressIndicator * progressUnit4;
    IBOutlet NSProgressIndicator * progressUnit5;
    
    IBOutlet NSSegmentedControl * segShowType;
    
    NSView * viewCurrent;
    
    NSTimer * scrollOutlineViewTaskTimer;
    long scrollIndex;
}

@end
