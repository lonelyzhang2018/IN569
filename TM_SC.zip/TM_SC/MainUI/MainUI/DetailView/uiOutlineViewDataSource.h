//
//  uiOutlineViewDataSource.h
//  UI
//
//  Created by Ryan on 12-11-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSTreeNode * items;

@interface uiOutlineViewDataSource : NSObject{
@private
    IBOutlet NSOutlineView * outlineView;
    IBOutlet NSButton * btnShowFailOnly;
    
    bool m_bShowFailOnly;
    bool m_bDiscardSkip;
}

-(id)ItemAtIndex:(NSInteger)index;
-(void)ShowFailOnly:(bool)bShowFailOnly :(bool)bDiscardSkip;
@end
