//
//  Task.m
//  MainUI
//
//  Created by xuqian on 16/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import "Task.h"
#include "StartUpInfor.h"
#import "UICommon.h"
extern StartUpInfor * pStartUpInfor;

@implementation Task
-(id)init
{
    self = [super init];
    if (self) {
        arrTask = [NSMutableArray new];
        pathMain = [[NSString alloc] initWithString:[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent]];
    }
    return self;
}

-(void)End_Task
{
    for (NSTask * t  in arrTask)
    {
        [t terminate];
    }
}

-(void)setStopFail:(bool)flag
{
    bStopFail = flag;
}

-(void)Lanuch_Task_WithIdentifier:(StartUpInfor *)pIdentifier
{
    NSString * identifier = [pIdentifier.Processes uppercaseString];
    if ([identifier isEqualToString:@""])
    {
        return; //no need lanuch
    }
//    if ([identifier isEqualToString:@"SIP"]) {
//        [self Lanuch_Task_SIP];
//    }
//    else
//    {
//        [self Lanuch_Task_PANEL];
//    }
    [self Lanuch_Task:pIdentifier];
}

-(void)Lanuch_Task:(StartUpInfor*)pIdentifier
{
    NSMutableDictionary * dic = [[NSMutableDictionary alloc]init];
    [dic setObject:[NSNumber numberWithInt:MSG_LEVEL_NORMAL] forKey:kStartupLevel];
    int slot = pIdentifier.Slot_Number;
    for (int i=0; i<slot; i++) {
        [dic setObject:[NSString stringWithFormat:@"Lanuch Engine < %d > ...",i] forKey:kStartupMsg];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
        [self Lanuch_Engine:i];
//        [self Lanuch_DataLog:i];
    }
    
    [NSThread sleepForTimeInterval:pIdentifier.sleep_time];
    
    for (int i=0; i<slot; i++) {
        [dic setObject:[NSString stringWithFormat:@"Lanuch Sequencer < %d > ...",i] forKey:kStartupMsg];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
        [self Lanuch_Sequencer:i];
    }
    
    NSString * identifier = [pIdentifier.Processes uppercaseString];
    if ([identifier isEqualToString:@"SIP"])
    {
        [dic setObject:@"Lanuch SipFixture  ..." forKey:kStartupMsg];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
        [self Lanuch_SipFixture];
    }
    
    [dic setObject:@"Lanuch StateMachine  ..." forKey:kStartupMsg];
    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
    [self Lanuch_StateMachine];
    if(pStartUpInfor.pdcaEnable == true)
    {
        [dic setObject:@"Lanuch PDCA  ..." forKey:kStartupMsg];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
        [self Lanuch_PDCA : YES];
    }
    else
    {
        [dic setObject:@"Lanuch Log(Without PDCA)  ..." forKey:kStartupMsg];
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:self userInfo:dic];
        [self Lanuch_PDCA : NO];
    }
    [dic release];
}

-(void)Lanuch_Task_SIP
{
    for (int i=0; i<=3; i++) {
        [self Lanuch_Engine:i];
        [self Lanuch_DataLog:i];
        //[self Lanuch_SNManager:i];
    }
    
    [NSThread sleepForTimeInterval:15.0];
    for (int i=0; i<=3; i++) {
        [self Lanuch_Sequencer:i];
    }
    [self Lanuch_SipFixture];
    [self Lanuch_StateMachine];
    
    [self Lanuch_PDCA :YES];
}

-(void)Lanuch_Task_PANEL
{
    for (int i=0; i<=5; i++) {
        [self Lanuch_Engine:i];
        [self Lanuch_DataLog:i];
        //[self Lanuch_SNManager:i];
    }
    
    [NSThread sleepForTimeInterval:15.0];
    for (int i=0; i<=5; i++) {
        [self Lanuch_Sequencer:i];
    }
    [self Lanuch_StateMachine];
    
    [self Lanuch_PDCA : YES];
}

-(int)CreateProcess:(NSString *)cmd atDirectory:(NSString *)dir withEnv:(NSDictionary *)dic
{
    //Change work directory
    chdir([dir UTF8String]);
    for (NSString * key in [dic keyEnumerator])
    {
        setenv([key UTF8String], [[dic valueForKey:key] UTF8String], 0);
    }
    [self Execute_withTask:[cmd UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_Sequencer:(int)index
{
    
    //NSString * cmd = [NSString stringWithFormat:@"/usr/bin/python x527/sequencer/sequencer.py -c -s %d",index];
    //NSString * workdir = [NSString stringWithFormat:@"%@/python-sequencer",pathMain];
    //[self CreateProcess:cmd atDirectory:workdir withEnv:[NSDictionary dictionaryWithObjectsAndKeys:workdir,@"PYTHONPATH", nil]];
    
    NSString * cmd = @"/usr/bin/python";
    //NSString * arg = [NSString stringWithFormat:@"x527/sequencer/sequencer.py -c -s %d",index];
    NSString * arg;
    if(bStopFail)
        arg = [NSString stringWithFormat:@"x527/sequencer/sequencer.py -s %d",index];
    else
        arg = [NSString stringWithFormat:@"x527/sequencer/sequencer.py -s %d -c",index];
    NSLog(@"Sequencer: %@",arg);
    NSString * workdir = [NSString stringWithFormat:@"%@/python-sequencer",pathMain];
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    setenv("PYTHONPATH", [workdir UTF8String], 0);
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_PDCA:(BOOL)pdca
{
    NSString * cmd = @"/usr/bin/python";
    NSString * arg;
    if(pdca==YES)
        arg = [NSString stringWithFormat:@"x527/Loggers/Logger.py pvcfsdaue -d /vault/Intelli_log"];
    else
        arg = [NSString stringWithFormat:@"x527/Loggers/Logger.py c -d /vault/Intelli_log"];
 //       arg = [NSString stringWithFormat:@"x527/Loggers/Logger.py vcfsdaue -d /vault/Intelli_log"];
    
    // Add for kill log process if exist
    NSString *logCmd = @"ps -ef |grep -i python |grep -i Logger.py |awk '{print $2}' |xargs kill -9";
    system([logCmd UTF8String]);
    
    NSString * workdir = [NSString stringWithFormat:@"%@/python-sequencer",pathMain];
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    setenv("PYTHONPATH", [workdir UTF8String], 0);
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_Engine:(int)index
{
    NSString * cmd = @"/usr/local/bin/lua";
    NSString * arg = [NSString stringWithFormat:@"test_engine_C_Zmq.lua -u %d",index];
    NSString * workdir = [NSString stringWithFormat:@"%@/LuaDriver/Driver",pathMain];
    
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_StateMachine
{
    NSString * cmd = @"/usr/local/bin/lua";
    //NSString * arg = [NSString stringWithFormat:@"StateMachine.lua -s %d",pStartUpInfor.Slot_Number];
    NSString * arg = [NSString stringWithFormat:@"StateMachine.lua"];
    NSString * workdir = [NSString stringWithFormat:@"%@/LuaDriver/StateMachine",pathMain];
    
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_DataLog:(int)index
{
    NSString * cmd = @"/usr/local/bin/lua";
    NSString * arg = [NSString stringWithFormat:@"DataLog.lua -i %d",index];
    NSString * workdir = [NSString stringWithFormat:@"%@/LuaDriver/DataLog",pathMain];
    
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_SNManager:(int)index
{
    NSString * cmd = @"/usr/local/bin/lua";
    NSString * arg = [NSString stringWithFormat:@"SNManager.lua -u %d",index];
    NSString * workdir = [NSString stringWithFormat:@"%@/LuaDriver/SNManager",pathMain];
    
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}

-(int)Lanuch_SipFixture
{
    NSString * cmd = @"/usr/local/bin/lua";
    NSString * arg = [NSString stringWithFormat:@"SipFixture.lua"];
    NSString * workdir = [NSString stringWithFormat:@"%@/LuaDriver",pathMain];
    
    chdir([workdir UTF8String]);
    system([[NSString stringWithFormat:@"cd %@",workdir] UTF8String]);
    
    
    NSString * str = [NSString stringWithFormat:@"%@ %@",cmd,arg];
    [self Execute_withTask:[str UTF8String] OutputTo:nil wait:0 TimeOut:0];
    return 0;
}


//static int Execute_withTask(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
-(int)Execute_withTask:(const char *) szcmd OutputTo:(const char *)poutput wait:(int)waituntilreturn TimeOut:(int)itimeout
{
    //   return system(szcmd);
    if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    //NSLog(@"arguments : %@",[argus description]);
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    
    //NSTask * task = [NSTask launchedTaskWithLaunchPath:[arg objectAtIndex:0] arguments:arguments];
    
    NSTask * task = [[NSTask alloc] init];
    if (poutput)
    {
        NSString * str = [NSString stringWithUTF8String:poutput];
        str = [str stringByResolvingSymlinksInPath];
        [[NSFileManager defaultManager] createFileAtPath:str contents:nil attributes:nil];
        id handle =[NSFileHandle fileHandleForWritingAtPath:str];
        //[task setStandardOutput:[NSFileHandle fileHandleForWritingAtPath:str]];
        [task setStandardOutput:handle];
        [task setStandardError:handle];
    }
    
    [task setLaunchPath:[arg objectAtIndex:0]];
    
    [task setArguments:arguments];
    
    [task launch];
    
    [arrTask addObject:task];
    
    if (waituntilreturn)
    {
        NSLog(@"Executing... %s",szcmd);
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1) {
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            //if ((now-start)>itimeout/1000)
            if ((now-start)>50)
            {
                [task terminate];
                [task release];
                NSString * str = [NSString stringWithFormat:@"%s\r\nTask time out in %d millionseconds.",szcmd,itimeout];
                NSLog(@"%@", str);
                [task release];
                return -1;
                @throw [NSException exceptionWithName:@"NSTask" reason:str userInfo:nil];
            }
            
            if ([[NSThread currentThread] isCancelled])
            {
                NSLog(@"Thread cancelled!");
                [task release];
                return -2;  //cancel
            }
            
            if (![task isRunning]) break;
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            [NSThread sleepForTimeInterval:0.001];
        }
        int ret = [task terminationStatus];
        [task release];
        NSLog(@"process normal finish! @ %s",szcmd);
        return ret;
    }
    //return [task processIdentifier];
    NSLog(@"process normal finish11! %s",szcmd);
    return 0;
}

@end