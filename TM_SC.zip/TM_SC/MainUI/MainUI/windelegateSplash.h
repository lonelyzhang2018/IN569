//
//  windelegateSplash.h
//  TestManager
//
//  Created by Ryan on 12-9-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@interface windelegateSplash : NSObject{
    IBOutlet NSTextView * txtStartUp;
}
@end
