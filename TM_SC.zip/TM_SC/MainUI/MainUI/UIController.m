//
//  UIController.m
//  MainUI
//
//  Created by Ryan on 12/3/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "UIController.h"
#include "UICommon.h"

@interface UIController ()

@end

@implementation UIController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

-(void)RegisterUINotification
{
    //Add notification monitor
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnEngineStart object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnEngineFinish object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnAttribute object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestStart object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestStop object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestFinish object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestPause object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestResume object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestItemStart object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestItemFinish object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiNotification:) name:kNotificationOnTestError object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(OnUiNotification:) name:kNotificationLoadProfile object:nil];
}

//User Interface
-(int) OnEngineStart:(id)sender
{
    //NSLog(@"UIController:OnEngineStart: %@",[sender description]);
    return 0;
}
-(int) OnEngineFinish:(id)sender
{
    //NSLog(@"UIController:OnEngineFinish: %@",[sender description]);
    return 0;
}
-(int) OnTestStart:(id)sender
{
    //NSLog(@"UIController:OnTestStart: %@",[sender description]);
    return 0;
}
-(int) OnTestStop:(id)sender
{
    //NSLog(@"UIController:OnTestStop: %@",[sender description]);
    return 0;
}
-(int) OnTestPasue:(id)sender
{
    //NSLog(@"UIController:OnTestPasue: %@",[sender description]);
    return 0;
}
-(int) OnTestResume:(id)sender
{
    //NSLog(@"UIController:OnTestResume: %@",[sender description]);
    return 0;
}

-(int) OnTestItemStart:(id)sender
{
    //NSLog(@"UIController:OnTestItemStart: %@",[sender description]);
    return 0;
}
-(int) OnTestItemFinish:(id)sender
{
    //NSLog(@"UIController:OnTestItemFinish: %@",[sender description]);
    return 0;
}
-(int) OnTestFinish:(id)sender
{
    //NSLog(@"UIController:OnTestFinish: %@",[sender description]);
    return 0;
}
-(int) OnTestError:(id)sender
{
    //NSLog(@"UIController:OnTestError: %@",[sender description]);
    return 0;
}

-(int)OnLoadProfile:(id)sender
{
    //NSLog(@"UIController:OnLoadProfile: %@",[sender description]);
    return 0;
}

-(int)OnAttribute:(id)sender
{
    return 0;
}

#pragma mark Notification
-(void)OnUiNotification:(NSNotification *)nf
{
    NSString * name = [nf name];
    if ([name isEqualToString:kNotificationOnTestStart])
    {
        [self performSelectorOnMainThread:@selector(OnTestStart:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestStop]) {
        [self performSelectorOnMainThread:@selector(OnTestStop:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestFinish]) {
        [self performSelectorOnMainThread:@selector(OnTestFinish:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestPause]) {
        [self performSelectorOnMainThread:@selector(OnTestPasue:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestResume]) {
        [self performSelectorOnMainThread:@selector(OnTestResume:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestItemStart]) {
        [self performSelectorOnMainThread:@selector(OnTestItemStart:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestItemFinish]) {
        [self performSelectorOnMainThread:@selector(OnTestItemFinish:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnTestError]) {
        [self performSelectorOnMainThread:@selector(OnTestError:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationLoadProfile]) {
        [self performSelectorOnMainThread:@selector(OnLoadProfile:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationLoadProfile]) {
        [self performSelectorOnMainThread:@selector(OnLoadProfile:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnEngineStart]) {
        [self performSelectorOnMainThread:@selector(OnEngineStart:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if ([name isEqualToString:kNotificationOnEngineFinish]) {
        [self performSelectorOnMainThread:@selector(OnEngineFinish:) withObject:[nf userInfo] waitUntilDone:YES];
    }
    else if([name isEqualToString:kNotificationOnAttribute])
    {
        [self performSelectorOnMainThread:@selector(OnAttribute:) withObject:[nf userInfo] waitUntilDone:YES];
    }
}
@end
