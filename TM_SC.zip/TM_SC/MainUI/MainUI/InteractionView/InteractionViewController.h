//
//  InteractionViewController.h
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "UIController.h"
//#include "StateMachineProxy.h"
#include "SMController.h"

#include "SNManagerController.h"

@interface InteractionViewController : UIController{
    IBOutlet NSTextField * textUUT1;
    IBOutlet NSTextField * textUUT2;
    IBOutlet NSTextField * textUUT3;
    IBOutlet NSTextField * textUUT4;
    IBOutlet NSTextField * textUUT5;
    IBOutlet NSTextField * textUUT6;
    
    IBOutlet NSTextField * lblUUT1;
    IBOutlet NSTextField * lblUUT2;
    IBOutlet NSTextField * lblUUT3;
    IBOutlet NSTextField * lblUUT4;
    IBOutlet NSTextField * lblUUT5;
    IBOutlet NSTextField * lblUUT6;
    
    IBOutlet NSButton * btUUT1;
    IBOutlet NSButton * btUUT2;
    IBOutlet NSButton * btUUT3;
    IBOutlet NSButton * btUUT4;
    IBOutlet NSButton * btUUT5;
    IBOutlet NSButton * btUUT6;
    
    IBOutlet NSButton * btStart;
    IBOutlet NSButton * btStop;
    IBOutlet NSButton * btSelectAll;
    
    IBOutlet NSTextField * textFail;
    IBOutlet NSTextField * textFailRate;
    IBOutlet NSTextField * textPass;
    IBOutlet NSTextField * textPassRate;
    
    IBOutlet NSTextField * textElapsedTimeUUT1;
    IBOutlet NSTextField * textElapsedTimeUUT2;
    IBOutlet NSTextField * textElapsedTimeUUT3;
    IBOutlet NSTextField * textElapsedTimeUUT4;
    IBOutlet NSTextField * textElapsedTimeUUT5;
    IBOutlet NSTextField * textElapsedTimeUUT6;
    IBOutlet NSProgressIndicator * progressUUT1;
    IBOutlet NSProgressIndicator * progressUUT2;
    IBOutlet NSProgressIndicator * progressUUT3;
    IBOutlet NSProgressIndicator * progressUUT4;
    IBOutlet NSProgressIndicator * progressUUT5;
    IBOutlet NSProgressIndicator * progressUUT6;
    
    IBOutlet NSTextField * txtSNInput;
    
    NSTimeInterval uut_startTime[6];
    
    NSTimer * testTimer;
    
    IBOutlet NSTextField * txtUserType;
    BOOL bOpeartor;
    BOOL bIsTesting;
}

-(IBAction)clearPassFail:(id)sender;
@end
