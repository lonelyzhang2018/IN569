//
//  InteractionViewController.m
//  MainUI
//
//  Created by Ryan on 12/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "InteractionViewController.h"

#include "UICommon.h"
#include "StartUpInfor.h"

#include "AppDelegate.h"
#include "SNManagerController.h"

#include "RegexKitLite.h"

#define crPASS  [NSColor greenColor]
#define crFAIL  [NSColor redColor]
#define crRUN   [NSColor blueColor]
#define crNA    [NSColor grayColor]
#define crERROR [NSColor yellowColor]
//#define crIDLE  [NSColor cyanColor]
#define crIDLE  [NSColor selectedTextBackgroundColor]


extern NSMutableDictionary * m_dicConfiguration;
extern AppDelegate * app;
extern SMController * StateMachine;

extern NSMutableArray * arrSNManager;
@interface InteractionViewController ()

@end

extern StartUpInfor * pStartUpInfor;
@implementation InteractionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

-(void)awakeFromNib
{
    //Add notification monitor
    [self RegisterUINotification];
    bOpeartor = YES;
    bIsTesting = NO;

    //create timer
    testTimer= [NSTimer scheduledTimerWithTimeInterval:0.6 target:self selector:@selector(timerFireMethod:) userInfo:nil repeats:YES];
    [testTimer fire];
    
    NSTextField * txt[]={textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    NSButton * btuut[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    
    //NSTextField * tim[]={textElapsedTimeUUT1,textElapsedTimeUUT2,textElapsedTimeUUT3,textElapsedTimeUUT4,textElapsedTimeUUT5,textElapsedTimeUUT6};
    //NSTextField * lbl[]={lblUUT1,lblUUT2,lblUUT3,lblUUT4,lblUUT5,lblUUT6};
    //NSProgressIndicator  * progress[]={progressUUT1,progressUUT2,progressUUT3,progressUUT4,progressUUT5,progressUUT6};
    
    
    for (int i=5; i>=pStartUpInfor.Slot_Number; i--) {
        //[txt[i] setHidden:YES];
        //[lbl[i] setHidden:YES];
        //[tim[i] setHidden:YES];
        //[progress[i] setHidden:YES];
        
        [txt[i] setBackgroundColor:crNA];
        [btuut[i] setState:0];
        [btuut[i] setEnabled:NO];
    }
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnUiCtrl:) name:kNotificationUiCtrl object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnEngineCtrl:) name:kNotificationDoTestStart object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnEngineCtrl:) name:kNotificationDoTestStop object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnEngineCtrl:) name:kNotificationDoChangeUser object:nil];
    
    @try {
        NSButton * bt[] = {btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
        
        for (int i=0;i<6;i++)
        {
            [bt[i] setState:(i<pStartUpInfor.Slot_Number)];
            [self btUUT:bt[i]];
        }
        [btStop setEnabled:NO];
    }
    @catch (NSException *exception) {
    }
    @finally {
    }
}

-(IBAction)btStart:(id)sender
{
#if 0
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"0"];
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"1"];
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"2"];
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"3"];
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"4"];
    [self performSelectorInBackground:@selector(dummy_message:) withObject:@"5"];
#else
    [btStart setEnabled:NO];
    bIsTesting = YES;
    [StateMachine Run];
#endif
    
}

-(IBAction)btStop:(id)sender
{
    [btStart setEnabled:NO];
    bIsTesting = NO;
    [StateMachine Stop];
}

#pragma mark User Interface Update entry function
-(int) OnEngineStart:(id)sender
{
    //Intial UI to prepare test...
    [btStart setEnabled:NO];
    bIsTesting = YES;
    [btStop setEnabled:!bOpeartor];
    return 0;
}

-(int) OnEngineFinish:(id)sender
{
    [btStart setEnabled:YES];
    [btStop setEnabled:NO];
    bIsTesting = NO;
    return 0;
}

-(int)OnAttribute:(id)sender
{
    @try {
        NSDictionary * dic = (NSDictionary *)sender;
        int iID = [[dic valueForKey:@"id"] intValue];
        NSString * name = [[dic valueForKey:@"name"] uppercaseString];
        NSString * value = [dic valueForKey:@"value"];
        
        if (!name) {
            return -1;
        }
        
        NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
        
        if (([name rangeOfString:@"MLBSN"].location!=NSNotFound)            //mlbsn_verify
            ||([name rangeOfString:@"SERIALNUMBER"].location!=NSNotFound)   //serialnunber
            ||([name rangeOfString:@"EEPROMSN"].location!=NSNotFound)       //eeprom
            ) {
            
            NSString * cap = @"(.*)[\\r\\n]+(.*)[\\r\\n]?";
            NSString * uutsn = [txt[iID] stringValue];
            
            NSError * err;
            NSString * mlb = [uutsn stringByMatching:cap options:RKLMultiline inRange:NSMakeRange(0, [uutsn length]) capture:1 error:&err];
            mlb = [mlb stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSLog(@"~~~Current mlb sn:%@,%ld",mlb,[mlb length]);
//            if ((mlb)&&([mlb length]>=5)) { //sn is set
//                return 0;
//            }
            mlb = value;

            int sn_len = [value length];
            if(sn_len!=11 && sn_len!=12 && sn_len!=13 && sn_len!=16 && sn_len!=17 )
                return 0;
            
            NSString * cfg = [uutsn stringByMatching:cap options:RKLMultiline inRange:NSMakeRange(0, [uutsn length]) capture:2 error:&err];
            if (!cfg) {
                cfg = @"";
            }
            if ([cfg isEqualToString:@"READY"]) {
                cfg = @"";
            }
            NSString * sn = [NSString stringWithFormat:@"%@\r%@",value,cfg];
            [txt[iID] setStringValue:sn];
        }
        else if (([name rangeOfString:@"CFG"].location!=NSNotFound)            //cfg
            )
        {
            NSString * cap = @"(.*)[\\r\\n]+(.*)[\\r\\n]?";
            NSString * uutsn = [txt[iID] stringValue];
            
            NSError * err;
            NSString * mlb = [uutsn stringByMatching:cap options:RKLMultiline inRange:NSMakeRange(0, [uutsn length]-1) capture:1 error:&err];
            if (!mlb) {
                mlb = [NSString stringWithFormat:@"UUT%d",iID];
            }
            NSString * cfg = [uutsn stringByMatching:cap options:RKLMultiline inRange:NSMakeRange(0, [uutsn length]-1) capture:2 error:&err];
            if ((!cfg)||([cfg length]==0)) {
                cfg = value;
            }
            NSString * sn = [NSString stringWithFormat:@"%@\r%@",value,cfg];
            [txt[iID] setStringValue:sn];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"OnAttribute Error : %@",[sender description]);
    }
    @finally {
    }

    return 0;
}


//User Interface
-(int) OnTestStart:(id)sender
{
    //reinitial...
    //IsRetest = NO;
    
    NSDictionary * dic = (NSDictionary *)sender;
    int iID = [[dic objectForKey:@"id"] intValue];
    NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    [txt[iID] setBackgroundColor:crRUN];
    //show serial numer
    
    //disable check button
    NSButton * button[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    [button[iID] setEnabled:NO];
    
    //start timer
    uut_startTime[iID] =[[NSDate date]timeIntervalSince1970];
    NSProgressIndicator * progressIndicator[]={progressUUT1,progressUUT2,progressUUT3,progressUUT4,progressUUT5,progressUUT6};
    [progressIndicator[iID] startAnimation:nil];
    
    //[btStart setEnabled:NO];
    //[txtSNInput setEnabled:NO];
    
    
    //Save Start time
    return 0;
}
-(int) OnTestStop:(id)sender
{
    NSDictionary * dic = (NSDictionary *)sender;
    int iID = [[dic objectForKey:@"id"] intValue];
    NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    [txt[iID] setBackgroundColor:crERROR];
    //[txt[iID] setStringValue:@"ABORT"];
    
    //ui update
    NSProgressIndicator * progressIndicator[]={progressUUT1,progressUUT2,progressUUT3,progressUUT4,progressUUT5,progressUUT6};
    [progressIndicator[iID] stopAnimation:nil];
    NSButton * button[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    [button[iID] setEnabled:YES];
    
    return 0;
}
-(int) OnTestPasue:(id)sender
{
    return 0;
}
-(int) OnTestResume:(id)sender
{
    return 0;
}

-(int) OnTestItemStart:(id)sender
{
    return 0;
}
-(int) OnTestItemFinish:(id)sender
{
    return 0;
}

-(int) OnTestFinish:(id)sender
{
    NSMutableDictionary * dic = (NSMutableDictionary *)sender;
    int iID = [[dic objectForKey:@"id"]intValue];
    int states = [[dic objectForKey:@"result"]intValue];
    NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    [txt[iID] setBackgroundColor:(states?crPASS:crFAIL)];
    
    //m_TestResult[iID] = states;
    
    //Stop timer...
    uut_startTime[iID] =0;
    
    
    //ui update
    NSProgressIndicator * progressIndicator[]={progressUUT1,progressUUT2,progressUUT3,progressUUT4,progressUUT5,progressUUT6};
    [progressIndicator[iID] stopAnimation:nil];
    NSButton * button[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    [button[iID] setEnabled:YES];
    
    //update test statics
    if (states<0) {
        //error
        [self OnTestError:sender];
        
    }

    int pass_count = [textPass intValue];
    int fail_count = [textFail intValue];
    if (states)
    {
        pass_count++;
    }
    else {
        fail_count++;
    }
    [textPass setIntValue:pass_count];
    [textFail setIntValue:fail_count];
    [textPassRate setStringValue:[NSString stringWithFormat:@"%.3f%%",(double)pass_count/(double)(pass_count+fail_count)*100]];
    [textFailRate setStringValue:[NSString stringWithFormat:@"%.3f%%",(double)fail_count/(double)(pass_count+fail_count)*100]];
    
    return 0;
}
-(int) OnTestError:(id)sender
{
    NSMutableDictionary * dic = (NSMutableDictionary *)sender;
    int iID = [[dic objectForKey:@"id"]intValue];
    NSString * strmsg=[dic objectForKey:@"error"];
    NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    [txt[iID] setBackgroundColor:crERROR];

    //ui update
    NSProgressIndicator * progressIndicator[]={progressUUT1,progressUUT2,progressUUT3,progressUUT4,progressUUT5,progressUUT6};
    [progressIndicator[iID] stopAnimation:nil];
    NSButton * button[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    [button[iID] setEnabled:YES];
    
    NSLog(@"[UUT%d Error]:%@",iID,strmsg);
    /*
    NSAlert * alert = [[NSAlert alloc] init];
    alert.messageText = [NSString stringWithFormat:@"UUT%d Error",iID];
    alert.informativeText = strmsg;
    [alert runModal];
    [alert release];
     */
    
    return 0;
}


//Just for test
-(void)dummy_message:(id)sender
{
    NSNumber * index = sender;
    NSNotificationCenter * df = [NSNotificationCenter defaultCenter];
    //start
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:index,@"id", nil];
    [df postNotificationName:kNotificationOnTestStart object:nil userInfo:dic];
    
    //item
    for (int i=0; i<16; i++) {
        //item start
        NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:index,@"id",[NSNumber numberWithInt:i],@"index",nil];
        [df postNotificationName:kNotificationOnTestItemStart  object:nil userInfo:dic];
        
        [NSThread sleepForTimeInterval:1.0];
        
        NSDictionary * dic2;
        if (i==2) {
            dic2 = [NSDictionary dictionaryWithObjectsAndKeys:index,@"id",[NSNumber numberWithInt:i],@"index",[NSNumber numberWithInt:i],@"value",@"0",@"state",nil];
        }
        else{
            dic2 = [NSDictionary dictionaryWithObjectsAndKeys:index,@"id",[NSNumber numberWithInt:i],@"index",[NSNumber numberWithInt:i],@"value",@"1",@"state",nil];
        }
        
        [df postNotificationName:kNotificationOnTestItemFinish  object:nil userInfo:dic2];
    }
    
    //finish
    NSDictionary * dic2 = [NSDictionary dictionaryWithObjectsAndKeys:index,@"id",@"0",@"states",nil];
    [df postNotificationName:kNotificationOnTestFinish object:nil userInfo:dic2];
}

#pragma mark timer
-(void)UpdateElapsedTime:(id)arg
{
    NSTextField * txtElapsedTime[] = {textElapsedTimeUUT1,textElapsedTimeUUT2,textElapsedTimeUUT3,textElapsedTimeUUT4,textElapsedTimeUUT5,textElapsedTimeUUT6};
    int index=[[arg objectForKey:@"index"] intValue];
    NSString * strtimes=[arg objectForKey:@"times"];
    [txtElapsedTime[index] setStringValue:strtimes];
}
- (void)timerFireMethod:(NSTimer*)theTimer
{
    NSTimeInterval now = [[NSDate date]timeIntervalSince1970];
    
    for (int i=0; i<=5; i++) {
        if (uut_startTime[i]!=0) {
            NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInt:i],@"index",[NSString stringWithFormat:@"%.03f",now-uut_startTime[i]],@"times", nil];
            [self performSelectorOnMainThread:@selector(UpdateElapsedTime:) withObject:dic waitUntilDone:NO];
        }
    }
}

#pragma mark Action
-(IBAction)btUUT:(id)sender
{
    long tag = [sender tag];
    NSTextField * uut[]={textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
    NSString * dicKey[]={kEngineUUT0Enable,kEngineUUT1Enable,kEngineUUT2Enable,kEngineUUT3Enable,kEngineUUT4Enable,kEngineUUT5Enable};
    [uut[tag] setEnabled:[sender state]];
    [uut[tag] setBackgroundColor:[sender state]?crIDLE:crNA];
 
    @try {
        [StateMachine SetUutState:[sender state] atSlot:(int)tag];
        [m_dicConfiguration setValue:[NSNumber numberWithInt:[sender state]] forKey:dicKey[tag]];
    }
    @catch (NSException *exception) {
        NSAlert * alert = [[NSAlert alloc] init];
        alert.messageText = [exception name];
        alert.informativeText = [exception reason];
        [alert runModal];
        [alert release];
    }
    @finally {
    }
}

-(IBAction)btSelectAll:(id)sender
{
    long state = long([sender state]);
    
    NSButton * bt_UUT[]={btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
    for (int i=0; i<pStartUpInfor.Slot_Number; i++) {
        [bt_UUT[i] setState:state];
        [self btUUT:bt_UUT[i]];
    }
}

-(IBAction)clearPassFail:(id)sender
{
    [textPass setIntValue:0];
    [textFail setIntValue:0];
    [textPassRate setStringValue:@"0%"];
    [textFailRate setStringValue:@"0%"];
}

- (BOOL)control: (NSControl *)control textView:(NSTextView *)textView doCommandBySelector: (SEL)commandSelector
{
    if (([NSStringFromSelector(commandSelector) isEqualToString:@"insertNewline:"])
        ||([NSStringFromSelector(commandSelector) isEqualToString:@"insertTab:"]))
    {
        if ([[[control stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]==0) {
            return YES;
        }
        
        [m_dicConfiguration setValue:[control stringValue] forKey:@"sn_initial"];
        [app OnScanBarcode:control];
        
    }
    return NO;
}

-(void)OnEngineCtrl:(NSNotification *)nf
{
    if ([[nf name] isEqualToString:kNotificationDoTestStart]) {
        [StateMachine Run];
        [btStop setEnabled:!bOpeartor];
        [btStart setEnabled:NO];
        bIsTesting = YES;
    }
    else if ([[nf name] isEqualToString:kNotificationDoTestStop])
    {
        [StateMachine Stop];
        [btStop setEnabled:NO];
        [btStart setEnabled:YES];
        bIsTesting = NO;
    }
    else if([[nf name] isEqualToString:kNotificationDoChangeUser])
    {
        NSDictionary * dic = [nf userInfo];
        id username = [dic objectForKey:kLoginUserName];
        if(username)
        {
            if ([username isEqualToString:@""] || [username isEqualToString:@"op"])
            {
                username = @"Operator";
                bOpeartor = YES;
                [btStop setEnabled:NO];
            }
            else
            {
                bOpeartor = NO;
                if (bIsTesting) {
                    [btStop setEnabled:YES];
                }
            }
            [txtUserType setStringValue:username];
        }
        else
        {
            [txtUserType setStringValue:@"None"];
            bOpeartor = YES;
            [btStop setEnabled:NO];
        }
    }
        
}

-(void)OnUiCtrl:(NSNotification *)nf
{
    @try {
        NSDictionary * dic = [nf userInfo];
        NSString * strCmd=[dic valueForKey:@"cmd"];
        NSString * strBuffer=[dic valueForKey:@"buf"];
        NSString * strIndex = [dic valueForKey:@"id"];
        
        NSTextField * txt[] = {textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
        NSButton * bt[] = {btUUT1,btUUT2,btUUT3,btUUT4,btUUT5,btUUT6};
        //[[NSNotificationCenter defaultCenter] postNotificationName:kNotificationDoUiCtrl object:nil userInfo:dic];
        NSLog(@"Request to set sn : cmd: %@, buf: %@ id:%@",strCmd,strBuffer,strIndex);
        if ([strCmd isEqualToString:@"set_sn"]) {
            [txt[[strIndex intValue]] setStringValue:[strBuffer stringByAppendingString:@"\r\n"]];
            [txt[[strIndex intValue]] setBackgroundColor:crIDLE];
            
            //SNManagerController * snm =  [arrSNManager objectAtIndex:[strIndex intValue]];
            //[snm SetSn:strBuffer];
            [StateMachine SetUutSn:strBuffer atSlot:[strIndex intValue]];
            
        }
        else if ([strCmd isEqualToString:@"set_cfg"])
        {
            NSString * str = [txt[[strIndex intValue]] stringValue];
            NSArray * arr = [str componentsSeparatedByString:@"\r\n"];
            NSString * mlb = [arr objectAtIndex:0];
            NSString * cfg = strBuffer;
            NSString * title = [NSString stringWithFormat:@"%@\r%@",mlb,cfg];
            [txt[[strIndex intValue]] setStringValue:title];
            [txt[[strIndex intValue]] setBackgroundColor:crIDLE];
            
            //SNManagerController * snm =  [arrSNManager objectAtIndex:[strIndex intValue]];
            //[snm SetSn:strBuffer];
            [StateMachine SetUutSn:strBuffer atSlot:[strIndex intValue]];
        }
        else if ([strCmd isEqualToString:@"set_uut_state"])
        {
            int index = [strIndex intValue];
            int state = [strBuffer intValue];
            [bt[index] setState:state];
            [self btUUT:bt[index]];
        }
        else if ([strCmd isEqualToString:@"set_uut_state_sn"])
        {
            int index = [strIndex intValue];
            int state = [strBuffer intValue];
            [bt[index] setState:state];
            
            NSString * sn = [dic valueForKey:@"sn"];
            if (!sn) {
                sn = @"";
            }
            
            id sender = bt[index];
            long tag = [sender tag];
            NSTextField * uut[]={textUUT1,textUUT2,textUUT3,textUUT4,textUUT5,textUUT6};
            NSString * dicKey[]={kEngineUUT0Enable,kEngineUUT1Enable,kEngineUUT2Enable,kEngineUUT3Enable,kEngineUUT4Enable,kEngineUUT5Enable};
            [uut[tag] setEnabled:[sender state]];
            [uut[tag] setBackgroundColor:[sender state]?crIDLE:crNA];
            
            //[self btUUT:bt[index]];
            [StateMachine SetUutState_WithSN:[sender state] atSlot:(int)tag withSN:sn];
            [m_dicConfiguration setValue:[NSNumber numberWithInt:[sender state]] forKey:dicKey[tag]];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"%@",exception);
    }
    @finally {
    }
}


@end
