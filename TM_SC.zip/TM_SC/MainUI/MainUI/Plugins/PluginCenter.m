//
//  PluginCenter.m
//  MainUI
//
//  Created by Ryan on 12/3/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "PluginCenter.h"

@implementation PluginCenter
-(id)init
{
    self = [super init];
    if (self) {
        arrPlugins = [[NSMutableArray alloc] init];
    }
    return self;
}
-(void)dealloc
{
    [super dealloc];
    //[arrPlugins release];
}
-(int)LoadPlugin:(NSString *)path
{
    NSLog(@"*********************Start to load:%@!********************************\r\n\r\n\r\n",path);
    NSBundle * bundle = [NSBundle bundleWithPath:path];;
    
    if (![bundle load])
    {
        return -1;
    }
    
    id bdl = [[[bundle principalClass] alloc]init];
    if (![bdl respondsToSelector:@selector(uixLoad:)]) {
        return -2;
    }
    
    [bdl uixLoad:m_dicConfig];
    [arrPlugins addObject:bdl];
    NSLog(@"*********************load:%@ complete!********************************\r\n\r\n\r\n",path);
    return 0;
    
}

-(int)LoadPlugins:(NSArray *)paths initDic:(NSMutableDictionary *)dic
{
    m_dicConfig = dic;
    for (NSString * bundle_path in paths) {
        if (![bundle_path isAbsolutePath]) {
            bundle_path = [NSString stringWithFormat:@"%@/%@",[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent],bundle_path];
            [self LoadPlugin:bundle_path];
        }
    }

    return 0;
}

-(int)LoadTools
{
    return 0;
}

@end
