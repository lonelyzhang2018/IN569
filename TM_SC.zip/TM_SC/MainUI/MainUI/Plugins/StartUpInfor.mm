//
//  StartUpInfor.m
//  GUI
//
//  Created by Ryan on 8/27/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#import "StartUpInfor.h"
#include <Foundation/Foundation.h>
//#include "TMLibrary/TMLibrary.h"
//#include "TMLibrary/PathManager.h"
//#include <TMLibrary/RegexKitLite.h>
#include "RegexKitLite.h"
#include <lua.hpp>

#define key_name        "name"
#define key_module      "module"
#define key_slot        "slot"
#define key_plugins     "plugins"
#define key_sn_plugin    "sn_plugin"
#define key_executor    "executor"
#define key_process    "process"
#define key_stopfail    "stopfail"
#define key_sleep       "sleep"

@implementation StartUpInfor
@synthesize Name;
@synthesize Module_Number;
@synthesize Slot_Number;
@synthesize SN_Plugin;
@synthesize arrPlugins;
@synthesize Executor;
@synthesize Processes;
@synthesize stopfail;
@synthesize gh_version;
@synthesize pdcaEnable;
@synthesize sleep_time;

-(id)init
{
    self = [super init];
    if (self) {
        self.arrPlugins = [NSMutableArray array];
    }
    return self;
}
-(BOOL)LoadWithFile:(NSString *)file
{
    if (!file) {
        file = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"uiStartUp.lua"];
    }
    
    const char * pstartup = [file UTF8String];
    
    
    try {
        NSLog(@"*********************************************\r\n");
        NSLog(@"Loading Start up configuration file.\r\n");
        lua_State * state = luaL_newstate();
        int err;
        luaL_openlibs(state);
        err = luaL_dofile(state, pstartup);
        if (err) {
            throw lua_tostring(state, -1);
        }
        
        if (lua_type(state, -1)!=LUA_TTABLE) {
            char buffer[128];
            sprintf(buffer, "Invalid startup file, return value is %s,should be a table!",lua_typename(state, -1));
            throw buffer;
        }
        
        //List table
        lua_getfield(state, -1, key_name);
        const char * name = lua_tostring(state, -1);
        if (!name) {
            name = "Untitle";
        }
        self.Name = [NSString stringWithFormat:@"%s",name];
        lua_pop(state, 1);
        
        
        lua_getfield(state, -1, key_executor);
        const char * executor = lua_tostring(state, -1);
        if (!executor) {
            executor = "";
        }
        self.Executor = [NSString stringWithFormat:@"%s",executor];
        lua_pop(state, 1);
        
        
        
        lua_getfield(state, -1, key_module);
        self.Module_Number = (int)lua_tointeger(state, -1);
        lua_pop(state, 1);
        
        lua_getfield(state, -1, key_slot);
        self.Slot_Number = (int)lua_tointeger(state, -1);
        lua_pop(state, 1);
        
        lua_getfield(state, -1, key_sn_plugin);
        const char * snplugin = lua_tostring(state, -1);
        if (!snplugin) {
            snplugin = "";
        }
        self.SN_Plugin = [NSString stringWithFormat:@"%s",snplugin];
        lua_pop(state, 1);
        
        lua_getfield(state, -1, key_plugins);
        lua_pushnil(state);
        while(lua_next(state,-2)){
            const char * pvalue = lua_tostring(state, -1);
            [self.arrPlugins addObject:[NSString stringWithFormat:@"%s",pvalue]];
            lua_pop(state,1);
        }
        lua_pop(state, 1);
        
        lua_getfield(state, -1, key_process);
        const char * process = lua_tostring(state, -1);
        if (!process) {
            process="";
        }
        self.Processes = [NSString stringWithFormat:@"%s",process];
        lua_pop(state, 1);
        //list lua table
        
        lua_getglobal(state, "get_gh_info");
        lua_pcall(state,0,1,0);
        const char * ver = lua_tostring(state, -1);
        self.gh_version = [NSString stringWithUTF8String:ver];

        lua_getfield(state, -1, key_sleep);
        self.sleep_time = (int)lua_tointeger(state, -1);
        lua_pop(state, 1);
        
        lua_close(state);
        
    } catch (const char * msg) {
        NSLog(@"%s\r\n",msg);
        return false;
    }
    
    
    [self InitialStartup];
    return true;
}

-(void)Execute:(NSString * )cmd
{
    system([cmd UTF8String]);
}
-(int)InitialStartup
{
    if (![self.SN_Plugin isAbsolutePath]) {
        self.SN_Plugin = [NSString stringWithFormat:@"%@/%@",[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent],self.SN_Plugin];
    }
    
    if ([self.Executor length]) {
        if (![self.Executor isAbsolutePath]) {
            self.Executor = [NSString stringWithFormat:@"%@/%@",[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent],self.Executor];
        }
        //[self Execute_withTask:[self.Executor UTF8String] output:nullptr WaitFinined:0 TimeOut:0];
        int pid = fork();
        if (pid ==0) {
            execl([self.Executor UTF8String], nil);
        }
        else
        {
            
        }
    }
    return 0;
}

-(int)Execute_withTask:(const char *)szcmd output:(const char *)poutput WaitFinined:(int) waituntilreturn TimeOut:(int)itimeout
{
    //   return system(szcmd);
    if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    //NSLog(@"arguments : %@",[argus description]);
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    
    //NSTask * task = [NSTask launchedTaskWithLaunchPath:[arg objectAtIndex:0] arguments:arguments];
    
    NSTask * task = [[NSTask alloc] init];
    if (poutput)
    {
        NSString * str = [NSString stringWithUTF8String:poutput];
        str = [str stringByResolvingSymlinksInPath];
        [[NSFileManager defaultManager] createFileAtPath:str contents:nil attributes:nil];
        id handle =[NSFileHandle fileHandleForWritingAtPath:str];
        //[task setStandardOutput:[NSFileHandle fileHandleForWritingAtPath:str]];
        [task setStandardOutput:handle];
        [task setStandardError:handle];
    }
    
    [task setLaunchPath:[arg objectAtIndex:0]];
    
    [task setArguments:arguments];
    
    [task launch];
    
    NSLog(@"*******************Launch finished");
    
    if (waituntilreturn)
    {
        NSLog(@"Executing... %s",szcmd);
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1) {
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            //if ((now-start)>itimeout/1000)
            if ((now-start)>50)
            {
                [task terminate];
                [task release];
                NSString * str = [NSString stringWithFormat:@"%s\r\nTask time out in %d millionseconds.",szcmd,itimeout];
                NSLog(@"%@", str);
                [task release];
                return -1;
                @throw [NSException exceptionWithName:@"NSTask" reason:str userInfo:nil];
            }
            
            if ([[NSThread currentThread] isCancelled])
            {
                NSLog(@"Thread cancelled!");
                [task release];
                return -2;  //cancel
            }
            
            if (![task isRunning]) break;
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            //[NSThread sleepForTimeInterval:0.001];
        }
        int ret = [task terminationStatus];
        [task release];
        NSLog(@"process normal finish! @ %s",szcmd);
        return ret;
    }
    //return [task processIdentifier];
    NSLog(@"process normal finish11! %s",szcmd);
    return 0;
}

@end