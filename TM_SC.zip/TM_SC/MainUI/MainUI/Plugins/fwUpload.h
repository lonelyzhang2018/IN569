//
//  hashCodeCheck.h
//  MainUI
//
//  Created by IvanGan on 16/3/7.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface fwUpload : NSObject

+(NSString *)fwUpload:(NSString*)file;

@end
