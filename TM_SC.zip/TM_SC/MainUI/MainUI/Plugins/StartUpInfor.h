//
//  StartUpInfor.h
//  GUI
//
//  Created by Ryan on 8/27/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma once
@interface StartUpInfor : NSObject{
}


-(BOOL)LoadWithFile:(NSString * )file;

@property(readwrite, copy) NSString *Name;
@property(assign) int Module_Number;
@property(assign) int Slot_Number;
@property(readwrite, copy) NSString *SN_Plugin;
@property(readwrite, retain) NSMutableArray * arrPlugins;
@property(readwrite, copy) NSString *Executor;
@property(readwrite,copy) NSString * Processes;
@property(assign) bool stopfail;
@property(assign) bool pdcaEnable;
@property(readwrite, copy) NSString * gh_version;
@property(assign) int sleep_time;
@end


