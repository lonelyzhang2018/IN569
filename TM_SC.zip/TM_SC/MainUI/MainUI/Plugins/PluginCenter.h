//
//  PluginCenter.h
//  MainUI
//
//  Created by Ryan on 12/3/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "UIPluginProtocol.h"
#include "StartUpInfor.h"

@interface PluginCenter : NSObject{
    NSMutableArray * arrPlugins;
    NSMutableDictionary * m_dicConfig;
}
-(int)LoadPlugins:(NSArray *)paths initDic:(NSMutableDictionary *)dic;
-(int)LoadTools;
-(int)eventCtrl:(int)code with:(id)sender;
@end
