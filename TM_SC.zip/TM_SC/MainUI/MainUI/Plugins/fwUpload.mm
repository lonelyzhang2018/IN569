//
//  hashCodeCheck.m
//  MainUI
//
//  Created by IvanGan on 16/3/7.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "fwUpload.h"
#import "lua.hpp"
#import "UICommon.h"

@implementation fwUpload

-(id)init
{
    self = [super init];
    return self;
}

-(void)dealloc
{
    [super dealloc];
}

+ (NSString *)fwUpload:(NSString *)file
{
    NSLog(@"< FW Upload >");
    NSString * path  = [[[[NSBundle mainBundle] bundlePath]stringByDeletingLastPathComponent]stringByAppendingPathComponent:@"LuaDriver/upload"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:path])
        return nullptr;
    
    NSString * strStatus;
    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"FW Upload...",kStartupMsg,[NSNumber numberWithInt:MSG_LEVEL_NORMAL],kStartupLevel, nil]];
    if(!file)
        file = [path stringByAppendingPathComponent:@"upload.lua"];
    @try {
        [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        lua_State * L = luaL_newstate();
        luaL_openlibs(L);
        int err;
        err = luaL_dofile(L, [file UTF8String]);
        if(err)
        {
            NSString * msg = [NSString stringWithUTF8String:lua_tostring(L, -1)];
            @throw msg;
        }
        lua_getglobal(L, "main");
        lua_pushstring(L, [path UTF8String]);
        lua_pcall(L,1,1,0);
        const char * status = lua_tostring(L, -1);
        strStatus = [NSString stringWithUTF8String:status];
        lua_close(L);
    }
    @catch (NSString * msg) {
        NSLog(@"%@\r\n",msg);
        return msg;
    }
    NSLog(@"< FW Upload > : result : %@", strStatus);
    NSNumber * level;
    if (![strStatus isEqualToString:@"success"])
    {
        level = [NSNumber numberWithInt:MSG_LEVEL_ERROR];
    }
    else
    {
        level = [NSNumber numberWithInt:MSG_LEVEL_NORMAL];
    }

    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:strStatus,kStartupMsg,level,kStartupLevel, nil]];
    
    return strStatus;
}

@end
