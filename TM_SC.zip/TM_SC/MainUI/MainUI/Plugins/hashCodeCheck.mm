//
//  hashCodeCheck.m
//  MainUI
//
//  Created by IvanGan on 16/3/7.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "hashCodeCheck.h"
#import "lua.hpp"
#import "UICommon.h"

@implementation hashCodeCheck
@synthesize bHashCorrect;
@synthesize strStatus;

-(id)init
{
    self = [super init];
    return self;
}

-(void)dealloc
{
    [super dealloc];
}

-(int)hashCodeCheck:(NSString*)file
{
    NSLog(@"< hash code check >");
    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Hash code check...",kStartupMsg,[NSNumber numberWithInt:MSG_LEVEL_NORMAL],kStartupLevel, nil]];
    int ret = 0;
    NSString * path  = [[[[[NSBundle mainBundle] resourcePath]stringByDeletingLastPathComponent]stringByDeletingLastPathComponent]stringByDeletingLastPathComponent];
    if(!file)
        file = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"codeCheck.lua"];
    @try {
        [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
        lua_State * L = luaL_newstate();
        luaL_openlibs(L);
        int err;
        err = luaL_dofile(L, [file UTF8String]);
        if(err)
            @throw [NSString stringWithUTF8String:lua_tostring(L, -1)];
        lua_getglobal(L, "checkResult");
        lua_pushstring(L, [path UTF8String]);
        lua_pcall(L,1,1,0);
        const char * status = lua_tostring(L, -1);
        self.strStatus = [NSString stringWithUTF8String:status];
        
        if ([[[NSString stringWithUTF8String:status]uppercaseString] containsString:@"SUCCESS"]) {
            self.bHashCorrect = true;
            ret = 0;
        }
        else
        {
            self.bHashCorrect = false;
            ret = -1;
        }
        
        lua_close(L);
    }
    @catch (NSString * msg) {
        NSLog(@"%@\r\n",msg);
        return -999;
    }
    NSLog(@"< hash code check > : result : %@", self.strStatus);
    NSNumber * level;
    NSString * msg;
    if (ret<0)
    {
        level = [NSNumber numberWithInt:MSG_LEVEL_ERROR];
        msg = @"File has been chenged! Please check log";
    }
    else
    {
        level = [NSNumber numberWithInt:MSG_LEVEL_NORMAL];
        msg = @"Successfule :-)";
    }

    [[NSNotificationCenter defaultCenter]postNotificationName:kNotificationStartupLog object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:msg,kStartupMsg,level,kStartupLevel, nil]];
    
    return ret;
}

@end
