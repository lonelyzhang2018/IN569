//
//  UICommon.h
//  MainUI
//
//  Created by Ryan on 12/3/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#ifndef UICommon_h
#define UICommon_h

#define crPASS  [NSColor greenColor]
#define crFAIL  [NSColor redColor]
#define crRUN   [NSColor blueColor]
#define crNA    [NSColor grayColor]
#define crERROR [NSColor yellowColor]
#define crIDLE  [NSColor selectedTextBackgroundColor]



//Message post from test engine //Post
#define     EM_ON_MODULE_START          "EM_ON_MODULE_START"            //Engine start, before all the slot startup
#define     EM_ON_MODULE_FINISHED       "EM_ON_MODULE_FINISHED"         //Engine finished,when all the slot stop

#define     EM_ON_TEST_START            "EM_ON_TEST_START"              //Message when a slot is start testing
#define     EM_ON_TEST_FINISHED         "EM_ON_TEST_FINISHED"           //Message when a slot is test finished
#define     EM_ON_TEST_ABORT            "EM_ON_TEST_ABORT"              //Message when a slot is test abort
#define     EM_ON_TEST_ERROR            "EM_ON_TEST_ERROR"              //Message when a slot is test error

#define     EM_ON_ITEM_START            "EM_ON_ITEM_START"
#define     EM_ON_ITEM_FINISHED         "EM_ON_ITEM_FINISHED"

#define     EM_ON_SELF_CHECK            "EM_ON_SELF_CHECK"

#define     EM_ON_LOAD_SEQUENCE         "EM_ON_LOAD_SEQUENCE"
#define EM_ON_UPDATE_STATION_INFO "EM_ON_UPDATE_STATION_INFO"

#define     EM_DO_ENABLE_SLOT           "EM_DO_ENABLE_SLOT"//ARGS:1-MODULE ID[0-N] 2-SLOT ID[0-N] 3-STATE["YES", "NO"]

#define     EM_DO_SET_DEBUG           "EM_DO_SET_DEBUG"//ARGS:1-MODULE ID[0-N] 2-SLOT ID[0-N] 3-STATE["YES", "NO"]


//UI post notification
#define kNotificationOnEngineStart      @"On_EngineStart"
#define kNotificationOnEngineFinish     @"On_EngineFinish"
#define kNotificationOnTestStart        @"On_TestStart"
#define kNotificationOnTestStop         @"On_TestStop"
#define kNotificationOnTestFinish       @"On_TestFinish"
#define kNotificationOnTestPause        @"On_TestPause"
#define kNotificationOnTestResume       @"On_TestResume"
#define kNotificationOnTestItemStart    @"On_TestItemStart"
#define kNotificationOnTestItemFinish   @"On_TestItemFinish"
#define kNotificationOnTestError        @"On_TestError"
#define kNotificationOnAttribute        @"On_Attribute"

#define kNotificationLoadProfile        @"On_ReloadProfile"
#define kNotificationUiCtrl             @"On_UiCtrl"

//UI Notification
#define kNotificationDoTestStart        @"DO_TestStart"
#define kNotificationDoTestStop         @"DO_TestStop"
#define kNotificationDoTestFinish       @"DO_TestFinish"
#define kNotificationDoTestPause        @"DO_TestPause"
#define kNotificationDoTestResume       @"DO_TestResume"
#define kNotificationDoTestItemStart    @"DO_TestItemStart"
#define kNotificationDoTestItemFinish   @"DO_TestItemFinish"
#define kNotificationDoTestError        @"DO_TestError"
#define kNotificationDoScanBarcode      @"DO_ScanBarcode"

//Configuration Keys
#define kConfigScanBarcode              @"scan_barcode?"
#define kConfigScanCFG                  @"Scan_Cfg?"
#define kConfigPuddingPDCA              @"Pudding_PDCA?"
#define kConfigPuddingBlob              @"Pudding_Blob"
#define kConfigPuddingBlobUart          @"Pudding_Blob_Uart"
#define kConfigPuddingBlobTestFlow      @"Pudding_Blob_TestFlow"
#define kConfigRemoveLocalBlob          @"Remove_Local_Blob"
#define kConfigTriggerType              @"Trigger_Type"
#define kConfigTriggerString            @"Trigger_String"
#define kConfigProfilePath              @"profile_path"
#define kConfigFailStop                 @"fail_Stop"  //-1:continue test,0:stop if fail,N:stop if fail count==N
#define kConfigFailCount                @"approve_fail_count"  //-1:continue test,0:stop if fail,N:stop if fail count==N
#define kConfigLogDir                   @"log_directory"
#define kConfigQueryResult              @"Query_Station_Result"
#define kConfigQeryStationName          @"Query_Station_Name"
#define kConfigCheckEECode              @"Check_EECode"
#define kConfigSN1Format                @"SN1_FORMAT"
#define kConfigSN2Format                @"SN2_FORMAT"
#define kConfigSN3Format                @"SN3_FORMAT"
#define kConfigSN4Format                @"SN4_FORMAT"
#define kConfigSN5Format                @"SN5_FORMAT"
#define kConfigSN6Format                @"SN6_FORMAT"
#define kConfigPuddingBlob              @"Pudding_Blob"
#define kConfigPuddingBlobUart          @"Pudding_Blob_Uart"
#define kConfigPuddingBlobTestFlow      @"Pudding_Blob_TestFlow"
#define kConfigRemoveLocalBlob          @"Remove_Local_Blob"

#define kConfigAutomationMode           @"Automation_Mode"

#define kConfigFixtureID                @"FixtureID"
#define kConfigFixtureVER               @"FixtureVER"

#define kNotificationStartupLog         @"Startup_log"      //this log will send to the start up
#define kStartupMsg                     @"msg"
#define kStartupLevel                   @"level"
//Login
#define kLoginUserName                  @"Login_UserName"
#define kLoginUserPassword              @"Login_Password"
#define kLoginUserAuthority             @"Login_Authority"

#define kNotificationDoChangeUser       @"Do_ChangeUser"
#define kConfigRebuildCSV               @"RebuildCSV"


typedef enum {
    MSG_LEVEL_NORMAL,
    MSG_LEVEL_WARNNING,
    MSG_LEVEL_ERROR,
}MSG_LEVEL;

typedef enum __USER_AUTHORITY {
    AUTHORITY_ADMIN = 0,
    AUTHORITY_ENGINEER = 1,
    AUTHORITY_OPERATOR = 2,
} USER_AUTHORITY;

typedef struct __USER_INFOR {
    char szName[32];
    char szPassword[32];
    USER_AUTHORITY Authority;
}USER_INFOR;


#define kNotificationProfileEditor      @"ProfileEditor"
#define kPFMainWindow                   @"MainWindow"
#define kPFProfileName                  @"ProfileName"


#define kEngineUUT0Enable   @"UUT0_Enable"
#define kEngineUUT1Enable   @"UUT1_Enable"
#define kEngineUUT2Enable   @"UUT2_Enable"
#define kEngineUUT3Enable   @"UUT3_Enable"
#define kEngineUUT4Enable   @"UUT4_Enable"
#define kEngineUUT5Enable   @"UUT5_Enable"
#define kEngineUUT6Enable   @"UUT6_Enable"
#define kEngineUUT7Enable   @"UUT7_Enable"
#define kEngineUUT8Enable   @"UUT8_Enable"

#define kProfilePath        @"profile"

#endif /* UICommon_h */
