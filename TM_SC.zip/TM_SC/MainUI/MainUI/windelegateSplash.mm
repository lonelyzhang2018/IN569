//
//  windelegateSplash.m
//  TestManager
//
//  Created by Ryan on 12-9-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "windelegateSplash.h"
#import "UICommon.h"

@implementation windelegateSplash
-(void)awakeFromNib
{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OnNotification:) name:kNotificationStartupLog object:nil];
}

-(void)dealloc
{
    [super dealloc];
}

-(BOOL)windowShouldClose:(id)sender
{

    return YES;
}

-(void)windowDidUpdate:(NSNotification *)notification
{
}

- (void)OnNotification:(NSNotification *)nf
{
    NSString * name = [nf name];
    if([name isEqualToString:kNotificationStartupLog])
    {
        NSLog(@" got kNotificationStartupLog");
        [self performSelectorOnMainThread:@selector(UpdateLog:) withObject:[nf userInfo] waitUntilDone:YES];
        [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
    }
}

- (void)UpdateLog:(id)sender
{
#if 0
    NSString * str = [sender objectForKey:kStartupMsg];
    NSLog(@"%@", str);
    if(!str) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        NSDateFormatter * fmt = [[NSDateFormatter alloc]init];
        [fmt setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
        NSString * date = [NSString stringWithFormat:@"%@\t %@\n",[fmt stringFromDate:[NSDate date]],str];
        
        NSMutableString * pstr = [[txtStartUp textStorage] mutableString];
        [pstr appendFormat:@"%@\r\n",date];
        NSRange range = NSMakeRange([pstr length]-1,0);
        [txtStartUp scrollRangeToVisible:range];
    });
#else
    NSString * str = [sender objectForKey:kStartupMsg];
    NSNumber * level = [sender objectForKey:kStartupLevel];
    if(!str) return;
    NSColor * color;
    if(level)
    {
        switch ([level integerValue]) {
            case MSG_LEVEL_NORMAL:
                color = [NSColor blueColor];
                break;
            case MSG_LEVEL_ERROR:
                color = [NSColor redColor];
                break;
            case MSG_LEVEL_WARNNING:
                color = [NSColor orangeColor];
                break;
            default:
                break;
        }
    }
    else
        color = [NSColor blackColor];
    
    NSDateFormatter * fmt = [[NSDateFormatter alloc]init];
    [fmt setDateFormat:@"yyyy/MM/dd HH:mm:ss.SSS : "];
    NSString * date = [NSString stringWithFormat:@"%@\t %@\r\n",[fmt stringFromDate:[NSDate date]],str];
    
    NSAttributedString * attStr = [[NSAttributedString alloc]initWithString:date attributes:[NSDictionary dictionaryWithObjectsAndKeys:color,NSForegroundColorAttributeName , nil]];
    [[txtStartUp textStorage] appendAttributedString:attStr];
    NSRange range = NSMakeRange([[txtStartUp textStorage] length],0);
    [txtStartUp scrollRangeToVisible:range];
    [fmt release];
    [attStr release];
#endif
}

@end
