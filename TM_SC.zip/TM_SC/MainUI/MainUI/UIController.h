//
//  UIController.h
//  MainUI
//
//  Created by Ryan on 12/3/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#pragma once

@interface UIController : NSViewController
-(void)RegisterUINotification;
-(int) OnTestStart:(id)sender;
-(int) OnTestStop:(id)sender;
-(int) OnTestPasue:(id)sender;
-(int) OnTestResume:(id)sender;
-(int) OnTestItemStart:(id)sender;
-(int) OnTestItemFinish:(id)sender;
-(int) OnTestFinish:(id)sender;
-(int) OnTestError:(id)sender;
@end
