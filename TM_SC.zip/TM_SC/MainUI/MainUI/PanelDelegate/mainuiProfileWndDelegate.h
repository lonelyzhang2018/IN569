//
//  mainuiProfileWndDelegate.h
//  UI
//
//  Created by Ryan on 12-11-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface mainuiProfileWndDelegate : NSObject{
@private
    IBOutlet NSTextField * txtProfilePath;
    IBOutlet NSTableView * tableviewProfiles;
    
    IBOutlet NSWindow * winProfle;
    IBOutlet NSWindow * winMain;
    
@private
    NSMutableArray * arrProfiles;
    NSMutableDictionary * m_dicConfiguration;
}

-(IBAction)btBrowse:(id)sender;
-(IBAction)btOk:(id)sender;
-(IBAction)btCancel:(id)sender;

-(void)OnDblClickOnTableView:(id)sender;

-(int)InitialCtrls:(NSMutableDictionary *)dicConfiguration;
@end
