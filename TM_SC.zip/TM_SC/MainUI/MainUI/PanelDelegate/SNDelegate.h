//
//  SNDelegate.h
//  SN
//
//  Created by Liang on 15-8-10.
//  Copyright (c) 2015年 Liang. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "SNManagerController.h"

@interface SNDelegate : NSObject
{
    IBOutlet NSWindow* win;
    IBOutlet NSWindow* winMain;
    
    IBOutlet NSTextField * textSN11;
    IBOutlet NSTextField * textSN12;
    IBOutlet NSTextField * textSN21;
    IBOutlet NSTextField * textSN22;
    IBOutlet NSTextField * textSN31;
    IBOutlet NSTextField * textSN32;
    IBOutlet NSTextField * textSN41;
    IBOutlet NSTextField * textSN42;
    
    id m_delegate;
    NSWindow* m_winHost;
    NSMutableDictionary* m_dicConfig;
    
}

-(int)InitialCtrls:(NSMutableDictionary*)dicSNControlsConfiguration;

@end
