//
//  uiConfigWndDelegate.m
//  UI
//
//  Created by Ryan on 12-11-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "uiConfigWndDelegate.h"
#include "UICommon.h"


@implementation uiConfigWndDelegate
#pragma mark Configuration Window Delegate & action
-(void)awakeFromNib
{
    [pathLogDIR setDoubleAction:@selector(btBrowse:)];

	/*
	 * given the weird dependencies in IA's test manager, we need to do this here
	 */
	self.pdcaEnabled = [NSNumber numberWithBool:[self->checkPuddingPDCA state]];
}

-(IBAction)btConfigOK:(id)sender
{
    //[self SaveConfig];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkScanBarcode state]] forKey:kConfigScanBarcode];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkScanCfg state]] forKey:kConfigScanCFG];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkPuddingPDCA state]] forKey:kConfigPuddingPDCA];

    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[radioTrigger selectedRow]] forKey:kConfigTriggerType];
    
    [m_dicConfiguration setValue:[textTriggerString stringValue] forKey:kConfigTriggerString];
    
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[textFailCount intValue]] forKey:kConfigFailCount];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkStopFail intValue]] forKey:kConfigFailStop];
    
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkQueryICT state]] forKey:kConfigQueryResult];
    
    [m_dicConfiguration setValue:[textCheckStationName stringValue] forKey:kConfigQeryStationName];

    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkEECode state]] forKey:kConfigCheckEECode];
    
    
    
    //[m_dicConfiguration setValue:[[pathLogDIR URL] path] forKey:kConfigLogDir];
    [m_dicConfiguration setValue:[textLogDIR stringValue] forKey:kConfigLogDir];
    
    
    //SN format
    [m_dicConfiguration setValue:[textSN1Format stringValue] forKey:kConfigSN1Format];
    [m_dicConfiguration setValue:[textSN2Format stringValue] forKey:kConfigSN2Format];
    [m_dicConfiguration setValue:[textSN3Format stringValue] forKey:kConfigSN3Format];
    [m_dicConfiguration setValue:[textSN4Format stringValue] forKey:kConfigSN4Format];
    [m_dicConfiguration setValue:[textSN5Format stringValue] forKey:kConfigSN5Format];
    [m_dicConfiguration setValue:[textSN6Format stringValue] forKey:kConfigSN6Format];
    
    //fixture ID
    [m_dicConfiguration setValue:[textFixtureID stringValue] forKey:kConfigFixtureID];
 
    //Blob
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[comboxPuddingBlob indexOfSelectedItem]] forKey:kConfigPuddingBlob];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkPuddingBlobUart state]] forKey:kConfigPuddingBlobUart];
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkPuddingBlobTestFlow state]] forKey:kConfigPuddingBlobTestFlow];
    
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkRemoveLocalBlob state]] forKey:kConfigRemoveLocalBlob];
    
    //Automation Mode
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkAutomationMode state]] forKey:kConfigAutomationMode];
    
    [m_dicConfiguration setValue:[NSNumber numberWithInteger:[checkRebuildCSV state]] forKey:kConfigRebuildCSV];
    
    [winMain endSheet:winConfig returnCode:YES];
}

-(IBAction)btConfigCancel:(id)sender
{
    [winMain endSheet:winConfig returnCode:NO];
    [winConfig orderOut:nil];
}

-(IBAction)btBrowse:(id)sender
{
    NSOpenPanel * panel = [NSOpenPanel openPanel];
    
    [panel setCanChooseFiles:NO];
    [panel setCanCreateDirectories:YES];
    [panel setCanChooseDirectories:YES];
    
    [panel setDirectoryURL:[NSURL URLWithString:[textLogDIR stringValue]]];
    // This method displays the panel and returns immediately.
    // The completion handler is called when the user selects an
    // item or cancels the panel.
    [panel beginSheetModalForWindow:winConfig completionHandler:^(NSInteger result)
     //    [panel beginWithCompletionHandler:^(NSInteger result)
     {
         if (result == NSFileHandlingPanelOKButton) {
             @try {
                 NSURL*  theDoc = [[panel URLs] objectAtIndex:0];
                 [textLogDIR setStringValue:[theDoc path]];
                 [pathLogDIR setURL:theDoc];
             }
             @catch (NSException *exception) {
                 NSRunAlertPanel(@"Load file", @"Load file failed,please check the data file formate", @"OK", nil, nil);
             }
             @finally {
             }
         }
     }];
}

-(int)InitialCtrls:(NSMutableDictionary *)dicConfiguration
{
#if 1
    m_dicConfiguration = dicConfiguration;
    
    BOOL bScanBarcode = [[m_dicConfiguration valueForKey:kConfigScanBarcode] boolValue];
    [checkScanBarcode setState:bScanBarcode];
    
    int value = [[m_dicConfiguration valueForKey:kConfigScanCFG] boolValue];
    [checkScanCfg setState:value];
    value = [[m_dicConfiguration valueForKey:kConfigPuddingPDCA] boolValue];
    [checkPuddingPDCA setState:value];
    self.pdcaEnabled = [NSNumber numberWithBool:value]; 	/* given the weird dependencies in IA's test manager, we need to do this here */


    value = [[m_dicConfiguration valueForKey:kConfigQueryResult] boolValue];
    [checkQueryICT setState:value];
    [textCheckStationName setEnabled:value];
    value = [[m_dicConfiguration valueForKey:kConfigTriggerType] intValue];
    [radioTrigger selectCellAtRow:value column:0];
    
    [textTriggerString setStringValue:[m_dicConfiguration valueForKey:kConfigTriggerString]];
    
    value = [[m_dicConfiguration valueForKey:kConfigFailCount] intValue];
    [textFailCount setIntValue:value];
    value = [[m_dicConfiguration valueForKey:kConfigFailStop] intValue];
    [checkStopFail setIntValue:value];
    [pathLogDIR setURL:[NSURL URLWithString:[m_dicConfiguration valueForKey:kConfigLogDir]]];
    [textLogDIR setStringValue:[m_dicConfiguration valueForKey:kConfigLogDir]];
    
    [textCheckStationName setStringValue:[m_dicConfiguration valueForKey:kConfigQeryStationName]];
    
    value = [[m_dicConfiguration valueForKey:kConfigCheckEECode] boolValue];
    [checkEECode setState:value];
    
    
    //SN format
    [textSN1Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN1Format]];
    [textSN2Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN2Format]];
    [textSN3Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN3Format]];
    [textSN4Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN4Format]];
    [textSN5Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN5Format]];
    [textSN6Format setStringValue:[m_dicConfiguration valueForKey:kConfigSN6Format]];
    
    //fixture ID
    [textFixtureID setStringValue:[m_dicConfiguration valueForKey:kConfigFixtureID]];
    
    //Blob
    [comboxPuddingBlob selectItemAtIndex:[[m_dicConfiguration valueForKey:kConfigPuddingBlob] intValue]];
    [checkPuddingBlobUart setState:[[m_dicConfiguration valueForKey:kConfigPuddingBlobUart] intValue]];
    [checkPuddingBlobTestFlow setState:[[m_dicConfiguration valueForKey:kConfigPuddingBlobTestFlow] intValue]];
    
    [checkRemoveLocalBlob  setState:[[m_dicConfiguration valueForKey:kConfigRemoveLocalBlob] intValue]];
    
    //Automation Mode
    [checkAutomationMode setState:[[m_dicConfiguration valueForKey:kConfigAutomationMode] intValue]];
    
    [checkRebuildCSV setState:[[m_dicConfiguration valueForKey:kConfigRebuildCSV] boolValue]];
#endif
    return 0;
}

-(void)tic_tac:(NSTimer *)tmr
{
	static int xx = 0;

	if (xx ==0 ) {
		[[self->_pdcaFlasher animator]  setAlphaValue:0.0];
	}
	if (xx == 1) {
		[[self->_pdcaFlasher animator] setAlphaValue:1.0];
	}

	if ([self.pdcaEnabled boolValue]) {
		self->_flashing = @NO;
		[tmr invalidate];
	}

	xx = (1 + xx) %4;
}

-(IBAction)btCheck:(id)sender
{
    int check = [sender state];
    switch ([sender tag]) {
        case 0:     //mlb sn
            if (!check)
            {
                [checkPuddingPDCA setState:check];
                [checkQueryICT setState:check];
                [checkEECode setState:check];
            }
            break;
        case 1:     //cfg sn
            if (check)
            {
                [checkScanBarcode setState:check];
            }
            break;
        case 2:     //pdca
            if (check)
            {
                [checkScanBarcode setState:check];
            }
            break;
        case 3:     //check query previous stations' rersult
            if (check)
            {
                [checkScanBarcode setState:check];
            }
            [textCheckStationName setEnabled:check];
            break;
        case 4:     //check EEEECode
            if (check)
            {
                [checkScanBarcode setState:check];
            }
            break;
        case 5: //Automation Mode
            if (check)
            {
                [checkScanBarcode setState:check];
                [checkPuddingPDCA setState:check];
                [checkQueryICT setState:check];
                [checkEECode setState:check];
            }
            break;
        default:
            break;
    }
}

-(IBAction)btOpenInFinder:(id)sender
{
    [[NSWorkspace sharedWorkspace] openFile:[textLogDIR stringValue]];
}


- (NSNumber *) pdcaEnabled
{
	return [NSNumber numberWithBool:[self->checkPuddingPDCA state]];
}

- (void)setPdcaEnabled:(NSNumber *)enabled
{
	BOOL state = [self.pdcaEnabled boolValue];

	if (!state && ![self->_flashing boolValue]) {
		self->_flashing = @YES;
		[NSTimer scheduledTimerWithTimeInterval:.3 target:self selector:@selector(tic_tac:) userInfo:nil repeats:YES];
	}
}

-(void)enablePDCA:(NSInteger)state
{
    [checkPuddingPDCA setState:state];
    [self btCheck:checkPuddingPDCA];
}

@end
