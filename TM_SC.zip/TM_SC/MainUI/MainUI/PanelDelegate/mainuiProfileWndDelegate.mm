//
//  mainuiProfileWndDelegate.m
//  UI
//
//  Created by Ryan on 12-11-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "mainuiProfileWndDelegate.h"
#import "UICommon.h"

@implementation mainuiProfileWndDelegate
-(void)awakeFromNib
{
    arrProfiles = [NSMutableArray new];
    [self ListProfile];
    [tableviewProfiles setTarget:self];
    [tableviewProfiles setDoubleAction:@selector(OnDblClickOnTableView:)];
}

-(void)dealloc
{
    [arrProfiles release];
    [super dealloc];
}
-(IBAction)btBrowse:(id)sender
{
    NSOpenPanel * panel = [NSOpenPanel openPanel];
    [panel setAllowedFileTypes:[NSArray arrayWithObjects:@"lua", @"prf", @"seq", @"iaseq",@"csv", nil]];
    [panel runModal];

    NSString * str = [[panel URL] path];
    if (str)
    {
        [txtProfilePath setStringValue:str];
    }
}


-(void)OnDblClickOnTableView:(id)sender
{
    long row  = [tableviewProfiles selectedRow];
    if (row>=0)
    {
        [txtProfilePath setStringValue:[arrProfiles objectAtIndex:row]];
    }
    [self btOk:nil];
}

-(int)InitialCtrls:(NSMutableDictionary *)dicConfiguration
{
    NSLog(@"count : %ld", [dicConfiguration count]);
    [txtProfilePath setStringValue:[dicConfiguration valueForKey:kProfilePath]];
    m_dicConfiguration = dicConfiguration;
    [self ListProfile];
    [tableviewProfiles reloadData];
    return 0;
}

-(IBAction)btOk:(id)sender
{
    [m_dicConfiguration setValue:[txtProfilePath stringValue] forKey:kProfilePath];
    [winMain endSheet:winProfle returnCode:YES];
    [winProfle orderOut:nil];
}

-(IBAction)btCancel:(id)sender
{
    [winMain endSheet:winProfle returnCode:NO];
    [winProfle orderOut:nil];
}

-(int)ListProfile
{
    [arrProfiles removeAllObjects];
    NSString * pathprofile = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"../profile"];
    NSFileManager * fm = [NSFileManager defaultManager];
    for (NSString * f in [fm contentsOfDirectoryAtPath:pathprofile error:nil])
    {
        if ([[[f pathExtension] uppercaseString] isEqualToString:@"LUA"] || 
            [[[f pathExtension] uppercaseString] isEqualToString:@"PRF"] ||
            [[[f pathExtension] uppercaseString] isEqualToString:@"SEQ"] ||
            [[[f pathExtension] uppercaseString] isEqualToString:@"IASEQ"]||
            [[[f pathExtension] uppercaseString] isEqualToString:@"CSV"]
            )
        {
            [arrProfiles addObject:f];
        }
    }
    
    [tableviewProfiles reloadData];
    
    return 0;
}

#pragma mark TableView Datasource & delegate
-(NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [arrProfiles count];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
    id object = nil;
    if ([[aTableColumn identifier] isEqualToString:@"index"])
    {
        object = [NSNumber numberWithInteger:rowIndex];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"filename"]) {
        object = [arrProfiles objectAtIndex:rowIndex];
    }
    return object;
}

- (void)tableViewSelectionDidChange:(NSNotification *)aNotification
{
    [txtProfilePath setStringValue:[arrProfiles objectAtIndex:[tableviewProfiles selectedRow]]];
}

-(void)LoadProfile:(NSString *)path
{
}

@end
