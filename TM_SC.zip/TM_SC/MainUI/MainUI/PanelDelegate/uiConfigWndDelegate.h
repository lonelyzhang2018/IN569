//
//  uiConfigWndDelegate.h
//  UI
//
//  Created by Ryan on 12-11-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface uiConfigWndDelegate : NSObject{
@private
    IBOutlet NSWindow * winConfig;
    IBOutlet NSWindow * winMain;
    IBOutlet NSButton * checkScanBarcode;
    IBOutlet NSButton * checkScanCfg;
    IBOutlet NSButton * checkPuddingPDCA;
    IBOutlet NSMatrix * radioTrigger;
    IBOutlet NSTextField * textFailCount;
    IBOutlet NSPathControl * pathLogDIR;
    IBOutlet NSTextField * textLogDIR;
    IBOutlet NSButton * checkQueryICT;
    IBOutlet NSTextField * textCheckStationName;
    IBOutlet NSButton * checkEECode;
    
    IBOutlet NSTextField * textSN1Format;
    IBOutlet NSTextField * textSN2Format;
    IBOutlet NSTextField * textSN3Format;
    IBOutlet NSTextField * textSN4Format;
    IBOutlet NSTextField * textSN5Format;
    IBOutlet NSTextField * textSN6Format;
    
    IBOutlet NSTextField * textFixtureID;
    
    IBOutlet NSTextField * textTriggerString;
    
    IBOutlet NSButton * checkAutomationMode;
    
    
    IBOutlet NSComboBox * comboxPuddingBlob;
    IBOutlet NSButton * checkPuddingBlobUart;
    IBOutlet NSButton * checkPuddingBlobTestFlow;
    
    IBOutlet NSButton * checkRemoveLocalBlob;
    
    IBOutlet NSTextField * checkStopFail;
    IBOutlet NSButton *checkRebuildCSV;
    
@private
    NSMutableDictionary * m_dicConfiguration;

    NSNumber    *_flashing;
    IBOutlet NSTextField *_pdcaFlasher;
}


-(int)InitialCtrls:(NSMutableDictionary *)dicConfiguration;
-(IBAction)btCheck:(id)sender;
-(void)enablePDCA:(NSInteger)state;

@property (copy) NSNumber *pdcaEnabled;

@end
