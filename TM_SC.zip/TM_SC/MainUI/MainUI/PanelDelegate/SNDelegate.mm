//
//  SNDelegate.m
//  SN
//
//  Created by Liang on 15-8-10.
//  Copyright (c) 2015年 Liang. All rights reserved.
//

#import "SNDelegate.h"
#include "UICommon.h"
#include "StartUpInfor.h"

#define SN_ROW  4
#define SN_COL  2
#define crDisable   [NSColor grayColor]
#define crNormal    [NSColor whiteColor]

SNDelegate* g_SNDelegate;
NSTextField* g_txtfSNAll[SN_ROW*SN_COL];

extern StartUpInfor * pStartUpInfor;
@implementation SNDelegate

- (id)init
{
    self = [super init];
    if (self) {
        m_delegate = nil;
        g_SNDelegate = self;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

-(void)awakeFromNib
{
    NSTextField* arr[] = {textSN11,textSN12,textSN21,textSN22,textSN31,textSN32,textSN41,textSN42};
    for(int i=0; i<SN_ROW*SN_COL; i++)
    {
        g_txtfSNAll[i] = arr[i];
    }
}

static NSTextField * txtFirst=nil;
-(int)InitialCtrls:(NSMutableDictionary*)dicSNControlsConfiguration
{
    int count = 0;
    m_dicConfig = dicSNControlsConfiguration;
    for(int i=0; i<SN_ROW*SN_COL; i++)
    {
        [g_txtfSNAll[i] setStringValue:@""];
    }
    
    int en_cfg = [[dicSNControlsConfiguration valueForKey:kConfigScanCFG] intValue];
    
    for (int i=0; i<SN_ROW; i++)
    {
        NSTextField* tf_1 = g_txtfSNAll[2*i];
        NSTextField* tf_2 = g_txtfSNAll[2*i+1];
        NSString* strKeyEnableUUT = [NSString stringWithFormat:@"UUT%d_Enable", i];
        int enable = [[dicSNControlsConfiguration valueForKey:strKeyEnableUUT] intValue];
        if (enable && (txtFirst==nil)) {
            txtFirst = tf_1;
        }
        if(enable>0)
            count++;
        [tf_1 setEnabled:enable];
        [tf_2 setEnabled:en_cfg&&enable];
        [tf_1 setBackgroundColor:enable?crNormal:crDisable];
        [tf_2 setBackgroundColor:en_cfg&&enable?crNormal:crDisable];

/*        NSString* strFirstBarcode = [dicSNControlsConfiguration valueForKey:@kSNFirstBarcode];
        if (enable==1 && [strFirstBarcode length]>0) {
            [tf_1 setStringValue:strFirstBarcode];
            [dicSNControlsConfiguration setValue:nil forKey:@kSNFirstBarcode];
        }*/
    }
    
    id sn = [dicSNControlsConfiguration valueForKey:@"sn_initial"];
    [txtFirst setStringValue:sn?sn:@""];
    [self setFirstInputControl];
    if(count==1)
    {
        [self saveAllSN];
        return 1;
    }
    return 0;
}

-(void)setFirstInputControl
{
    NSTextField** txtfSNAll = g_txtfSNAll;
    for(int i=0; i<SN_ROW*SN_COL; i++)
    {
        if ([txtfSNAll[i] isEnabled] && ([[txtfSNAll[i] stringValue] length]==0)) {
            if ([[[txtFirst stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]!=0) {
                if (txtfSNAll[i] == txtFirst) {
                    continue;
                }
            }
            [txtfSNAll[i] becomeFirstResponder];
            return;
        }
    }
}

- (int)getLastInputIndex
{
    for(int i=SN_ROW*SN_COL; i>0; i--)
    {
        if ([g_txtfSNAll[i-1] isEnabled] && [[g_txtfSNAll[i-1] stringValue] length]==0) {
            return i-1;
        }
    }
    return -1;//ready for all
}

- (BOOL)checkDuplicate:(int)index
{
    NSString* sn = [g_txtfSNAll[index] stringValue];
    for (int i=0; i<SN_ROW*SN_COL; i++)
    {
        if (i==index) continue;
        if([[g_txtfSNAll[i] stringValue] isEqualTo:sn])
        {
            NSRunAlertPanel(@"Scan BarCode", @"This serial number has been used in UUT%d,please scan another!", @"OK", nil, nil, i/2);
            [g_txtfSNAll[index] setStringValue:@""];
            return YES;
        }
    }
    return NO;
}

-(int)checkSN:(NSString*)sn Type:(int)type
{
    int r = 1;
    
    return r;
}

- (BOOL)control: (NSControl *)control textView:(NSTextView *)textView doCommandBySelector: (SEL)commandSelector
{
    if (([NSStringFromSelector(commandSelector) isEqualToString:@"insertNewline:"])
        ||([NSStringFromSelector(commandSelector) isEqualToString:@"insertTab:"]))
    {
        if ([[[control stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length]==0) {
            return YES;
        }
        
        int index_control = 0;
        for(int i=0; i<SN_ROW*SN_COL; i++)
        {
            if ([g_txtfSNAll[i] isEqualTo:control]) {
                index_control = i;
                break;
            }
        }
        
        //check if duplicate error
        if([self checkDuplicate:index_control]){
            return YES;
        }
        
        //check if format error    use regular expression?
        int result = [self checkSN:[control stringValue] Type:index_control];
        if (result)
        {
            while (1)
            {
                if ([self getLastInputIndex]==-1) //completed
                {
                    [self saveAllSN];
                    break;
                }
                else    //not completed
                {
                    index_control++;
                    if ([g_txtfSNAll[index_control] isEnabled])//next location
                    {
                        [g_txtfSNAll[index_control] becomeFirstResponder];
                        break;
                    }
                }
            }
        }
        else    //invalid sn format
        {
            [control becomeFirstResponder];
            return YES;
        }
        return YES;//unable to remove input char
    }
	return NO;//able to remove input char
}


-(void)saveAllSN
{
    //Save Serial Number into Test Context
    NSView * view = [win contentView];
    NSTextField * textSN=nil;
    
    @try {
        for (int i=1; i<=8; i++) {
            textSN = [view viewWithTag:i];
            if  (![textSN isEnabled])
            {
                continue;
            }
            
            
            //[pContext->m_dicContext setValue:[textSN stringValue] forKey:i%2?kContextMLBSN:kContextCFG];
            if (i%2) {
                
                //Notification
                NSDictionary * dic = [NSMutableDictionary dictionary];
                [dic setValue:@"set_sn" forKey:@"cmd"];
                [dic setValue:[textSN stringValue] forKey:@"buf"];
                [dic setValue:[NSNumber numberWithInt:i/2] forKey:@"id"];
                [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationUiCtrl object:nil userInfo:dic];
            }
            else    //cfg
            {
                //Notification
                NSDictionary * dic = [NSMutableDictionary dictionary];
                [dic setValue:@"set_cfg" forKey:@"cmd"];
                [dic setValue:[textSN stringValue] forKey:@"buf"];
                [dic setValue:[NSNumber numberWithInt:i/2-1] forKey:@"id"];
                [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationUiCtrl object:nil userInfo:dic];
            }
        }
    }
    @catch (NSException *exception) {
        NSAlert * alert = [[NSAlert alloc] init];
        alert.messageText = [exception name];
        alert.informativeText = [exception reason];
        [alert runModal];
        [alert release];
    }
    @finally {
    }
//    [NSThread sleepForTimeInterval:0.5];
//    [[NSRunLoop currentRunLoop]runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
    [winMain endSheet:win returnCode:YES];
}


-(IBAction)btCancel:(id)sender
{
    [winMain endSheet:win returnCode:NO];
}

@end

