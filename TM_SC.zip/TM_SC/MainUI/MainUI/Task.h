//
//  Task.h
//  MainUI
//
//  Created by xuqian on 16/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StartUpInfor.h"

#define TASK_CMD        @"cmd"
#define TASK_DIR        @"dir"
#define TASK_ENV        @"env"

@interface Task : NSObject{
    NSMutableArray * arrTask;
    NSString * pathMain;
    bool bStopFail;
}
-(void)End_Task;
-(void)Lanuch_Task:(StartUpInfor*)pIdentifier;
-(void)Lanuch_Task_WithIdentifier:(StartUpInfor *)pIdentifier;
-(void)setStopFail:(bool)flag;
-(int)Lanuch_PDCA:(BOOL)pdca;
@end
