//
//  main.m
//  Debugger
//
//  Created by xuqian on 21/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
