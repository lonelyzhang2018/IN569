//
//  AppDelegate.h
//  Debugger
//
//  Created by xuqian on 21/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

