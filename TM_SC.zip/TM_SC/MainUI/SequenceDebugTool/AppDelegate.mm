//
//  AppDelegate.m
//  SequenceDebugTool
//
//  Created by IvanGan on 16/1/6.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "AppDelegate.h"
#import "unitTool.h"
#import "RegexKitLite.h"

#define kPath  @"path"
#define kKey @"key"
#define kSlots @"slots"

#import <MMTabBarView/UnitFakeModel.h>

@interface AppDelegate ()

@property IBOutlet NSWindow *window;
@end

@implementation AppDelegate

-(void)awakeFromNib
{
    port = -1;
    NSString * path = [NSString stringWithFormat:@"%@/config.plist",[[NSBundle mainBundle]resourcePath] ];
    if([[NSFileManager defaultManager]fileExistsAtPath:path])
        dicConfig = [[NSMutableDictionary alloc]initWithContentsOfFile:path];
    else
    {
        dicConfig = [[NSMutableDictionary alloc]init];
        [dicConfig setObject:@"~/testerconfig/zmqports.json" forKey:kPath];
        [dicConfig setObject:@"SEQUENCER_PORT" forKey:kKey];
        [dicConfig setObject:[NSNumber numberWithInt:4] forKey:kSlots];
        [dicConfig writeToFile:path atomically:YES];
    }
    
    if([[NSFileManager defaultManager]fileExistsAtPath:[[dicConfig objectForKey:kPath]  stringByResolvingSymlinksInPath]])
    {
        NSString * str = [NSString stringWithContentsOfFile:[[dicConfig objectForKey:kPath]  stringByResolvingSymlinksInPath] encoding:NSUTF8StringEncoding error:nil];
        NSString * fmt = [NSString stringWithFormat:@"%@\":\\s*(\\d+)",[dicConfig objectForKey:kKey]];
        NSString * p = [str stringByMatching:fmt capture:1];
        if(p)
            port = [p intValue];
    }
        
    m_Slots = [[dicConfig objectForKey:kSlots]intValue];

    arrUnit = [NSMutableArray new];
    [tabBar setStyleNamed:@"Safari"];
    [tabBar setOnlyShowCloseOnHover:YES];
    [tabBar setCanCloseOnlyTab:YES];
    [tabBar setDisableTabClose:YES];
    [tabBar setAllowsBackgroundTabClosing:YES];
    [tabBar setHideForSingleTab:YES];
    [tabBar setShowAddTabButton:YES];
    [tabBar setSizeButtonsToFit:NO];

    [tabBar setTearOffStyle:MMTabBarTearOffAlphaWindow];
    [tabBar setUseOverflowMenu:YES];
    [tabBar setAutomaticallyAnimates:YES];
    [tabBar setAllowsScrubbing:YES];
    [tabBar setButtonOptimumWidth:200];

    [self CreateUnit:m_Slots];
    
//    unitTool * c = [[unitTool alloc] initWithIndex:index :_window];
//    [c setSlots:m_Slots :port];
//    [[view superview] replaceSubview:view with:c.view];
//    
    NSString * str = [NSString stringWithFormat:@"Version: %@ \t\t %@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"],[[[NSBundle mainBundle] infoDictionary] objectForKey:@"NSHumanReadableCopyright"]];
    [txtVersion setStringValue:str];
}

-(void)CreateUnit:(int)count
{
    for (int i=0; i<count; i++) {
        [self addNewTabWithTitle:[NSString stringWithFormat:@"UUT%d",i+1] withIndex:i];
    }
    [tabView selectFirstTabViewItem:nil];
}

- (void)addNewTabWithTitle:(NSString *)aTitle withIndex:(int)index
{
    unitTool * c = [[unitTool alloc] initWithIndex:index :_window];
    [self SetUpUnit:index withUnit:c];
    
    [arrUnit addObject:c];
    
    UnitFakeModel *newModel = [[UnitFakeModel alloc] init];
    [newModel setTitle:aTitle];
    NSTabViewItem *newItem = [[NSTabViewItem alloc] initWithIdentifier:newModel];
    [newItem setLabel:aTitle];
    [tabView addTabViewItem:newItem];
    [tabView selectTabViewItem:newItem];
    [newItem setView:c.view];
    //    [c.view setFrame:[view frame]];
    [newModel release];
    [newItem release];
    //[c release];
}

-(void)SetUpUnit:(int)index withUnit:(unitTool *)controller
{
    int p = port + index;
    [controller InitialPort:p];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    
    
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    for (NSViewController * v in arrUnit)
    {
        [v release];
    }
    [arrUnit release];
}

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender
{
    return YES;
}

@end
