//
//  main.m
//  SequenceDebugTool
//
//  Created by IvanGan on 16/1/6.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
