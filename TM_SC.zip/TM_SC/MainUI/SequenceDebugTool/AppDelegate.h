//
//  AppDelegate.h
//  SequenceDebugTool
//
//  Created by IvanGan on 16/1/6.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <MMTabBarView/MMTabBarView.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    IBOutlet MMTabBarView           *tabBar;

    NSMutableArray * arrUnit;
    IBOutlet NSWindow * win;
    IBOutlet NSTabView * tabView;
    IBOutlet NSTextField * txtVersion;
    int m_Slots;
    NSMutableDictionary * dicConfig;
    int port;
    IBOutlet NSView * view;
}

@end

