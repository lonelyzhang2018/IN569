local f = io.open("ps");
local buf = f:read();
f:close();

function KillProcess(name)

end