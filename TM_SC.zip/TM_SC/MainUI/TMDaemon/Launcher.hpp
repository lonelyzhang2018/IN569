//
//  Launcher.hpp
//  MainUI
//
//  Created by xuqian on 16/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#ifndef Launcher_hpp
#define Launcher_hpp

#include <stdio.h>


int Fork_Process(const char * arg);

int Fork_Sequencer(int index,int * process_id=nullptr);
int Fork_Engine(int index,int * process_id=nullptr);
int Fork_StateMachine(int index,int * process_id=nullptr);
int Fork_SN_Manager(int index,int * process_id=nullptr);
int Fork_PDCA(int index,int * process_id=nullptr);
int Fork_DataLog(int index,int * process_id=nullptr);
int Launcher(int channel);

int ClearProcess();

#endif /* Launcher_hpp */
