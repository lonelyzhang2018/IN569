//
//  Launcher.cpp
//  MainUI
//
//  Created by xuqian on 16/12/15.
//  Copyright © 2015年 ___Intelligent Automation___. All rights reserved.
//

#include "Launcher.hpp"
#include <stdlib.h>
#include <Foundation/Foundation.h>

#define TM_DAEMON_VERSION   "1.0"

static NSMutableArray * arrTask = [[NSMutableArray alloc]init];

int p[2];

int ClearProcess()
{
    for (NSNumber * pid in arrTask)
    {
        system([[NSString stringWithFormat:@"kill %d",[pid intValue]] UTF8String]);
    }
    return 0;
}

static int Add_Process(int pid)
{
    [arrTask addObject:[NSNumber numberWithInt:pid]];
    return 0;
}

char * main_path = nullptr;
int Launcher(int channel)
{
    // insert code here...
    pipe(p);
    main_path = (char *)[[[[NSBundle mainBundle] bundlePath] stringByDeletingLastPathComponent]UTF8String];
    NSLog(@"Current Directory : %s",main_path);
    
    Fork_PDCA(0);
    for (int i=0;i<channel;i++)
    {
        int pid;
        Fork_DataLog(i,&pid);
        Fork_SN_Manager(i);
        Fork_Engine(i);
    }
    
    sleep(3);
    for (int i=0; i<channel; i++) {
        int pid;
        Fork_Sequencer(i,&pid);
    }
    Fork_StateMachine(0);
    
    return 0;
}

int Fork_Sequencer(int index,int * process_id)
{
    setenv("PYTHONPATH", [[NSString stringWithFormat:@"%s/python_sequencer",main_path]UTF8String], 0);
    system("echo ~~~~~~~~ $PYTHONPATH");
    NSString * str = [NSString stringWithFormat:@"%s/python_sequencer/x527/sequencer/sequencer.py",main_path];
    //Fork_Process([str UTF8String]);
    
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            *process_id = pid;
        }
        
        //int ret = execlp("/usr/local/bin/lua","/Users/mac/Downloads/test.lua",0);
        //int ret = execlp("/usr/local/bin/python","/usr/local/bin/python","/Users/mac/Downloads/test.lua",NULL);
        int ret = execlp("/usr/bin/python","/usr/bin/python",[str UTF8String],"-s",[[NSString stringWithFormat:@"%d",index]UTF8String],NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}

int Fork_PDCA(int index,int * process_id)
{
    setenv("PYTHONPATH", [[NSString stringWithFormat:@"%s/python_sequencer",main_path]UTF8String], 0);
    system("echo ~~~~~~~~ $PYTHONPATH");
    NSString * str = [NSString stringWithFormat:@"%s/python_sequencer/x527/Loggers/Logger.py",main_path];
    //Fork_Process([str UTF8String]);
    
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            *process_id = pid;
        }
        
        //int ret = execlp("/usr/local/bin/lua","/Users/mac/Downloads/test.lua",0);
        //int ret = execlp("/usr/local/bin/python","/usr/local/bin/python","/Users/mac/Downloads/test.lua",NULL);
        int ret = execlp("/usr/bin/python","/usr/bin/python",[str UTF8String],"d",NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}

int Fork_Engine(int index,int * process_id)
{
    
    const char * pstr = [[NSString stringWithFormat:@"%s/LuaDriver/Driver",main_path]UTF8String];
    NSLog(@"%s",pstr);
    chdir(pstr);
    //Fork_Process([str UTF8String]);
    
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            *process_id = pid;
        }
        
        int ret = execlp("/usr/local/bin/lua","/usr/local/bin/lua","test_engine_C_Zmq.lua","-u",[[NSString stringWithFormat:@"%d",index]UTF8String],NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}


int Fork_StateMachine(int index,int * process_id)
{
    
    const char * pstr = [[NSString stringWithFormat:@"%s/LuaDriver/StateMachine",main_path]UTF8String];
    NSLog(@"~~~~%s",pstr);
    chdir(pstr);
    //Fork_Process([str UTF8String]);
    
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            *process_id = pid;
        }
        
        int ret = execlp("/usr/local/bin/lua","/usr/local/bin/lua","StateMachine.lua",NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}


int Fork_SN_Manager(int index,int * process_id)
{
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            *process_id = pid;
        }
        
        const char * pstr = [[NSString stringWithFormat:@"%s/LuaDriver/SNManager",main_path]UTF8String];
        NSLog(@"%s",pstr);
        chdir(pstr);
        //Fork_Process([str UTF8String]);
        int ret = execlp("/usr/local/bin/lua","/usr/local/bin/lua","SNManager.lua","-u",[[NSString stringWithFormat:@"%d",index]UTF8String],NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}

int Fork_DataLog(int index,int * process_id)
{
    int pid = fork();
    if (pid < 0) {
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        if (process_id)
        {
            NSLog(@"~~!!!get id:%d",getpid());
            *process_id = pid;
        }
        
        const char * pstr = [[NSString stringWithFormat:@"%s/LuaDriver/DataLog",main_path]UTF8String];
        NSLog(@"%s",pstr);
        chdir(pstr);
        //Fork_Process([str UTF8String]);
        int ret = execlp("/usr/local/bin/lua","/usr/local/bin/lua","datalog.lua","-i",[[NSString stringWithFormat:@"%d",index]UTF8String],NULL);
        NSLog(@"execl~~~~~~ return : %d err: %d",ret,errno);
        return pid;
    }
    return pid;
}



int Fork_Process(const char * arg)
{
    NSLog(@"Start to fork:\r\n%s",arg);
    int pid = fork();
    if (pid < 0) { //parent
        NSLog(@"Fork process error, with path : %s",arg);
    }
    else if (pid == 0)
    {
        pid = getpid();
        Add_Process(pid);
        int ret = execl(arg, nullptr);
        NSLog(@"execl return : %d",ret);
        return pid;
    }
    return pid;
}