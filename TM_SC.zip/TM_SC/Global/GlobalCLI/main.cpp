//
//  main.cpp
//  GlobalCLI
//
//  Created by Ryan on 4/19/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#include <iostream>
#include "lua.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    char Buffer[256]={};
    
    lua_State * state = luaL_newstate();
    luaL_openlibs(state);
    int err = luaL_dostring(state, "package.cpath = package.cpath..\";\"..\"./lib?.dylib\"");
    err = luaL_dostring(state, "require \"Global\"");
    
    printf("Please enter your command : \r\n");
    while (1) {
        gets(Buffer);
        if ((strcmp(Buffer, "q")==0)||(strcmp(Buffer, "quit")==0)) {
            break;
        }
        else
        {
            err = luaL_dostring(state, Buffer);
            if (err) {
                printf("%s",lua_tostring(state, -1));
            }
        }
    }

    return 0;
}
