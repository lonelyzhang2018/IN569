//
//  Global.cpp
//  Global
//
//  Created by Ryan on 4/17/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#include "Global.h"

#include "tolua++.h"


TOLUA_API int  tolua_Global_Function_open (lua_State* tolua_S);

int luaopen_libGlobal(lua_State * state)
{
    printf("Load Global dylib ...");
    
    tolua_Global_Function_open(state);
    
    printf("Load Global dylib success ...");
    return 0;
}