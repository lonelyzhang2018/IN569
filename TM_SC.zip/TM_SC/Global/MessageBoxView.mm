//
//  MessageBoxView.m
//  Global
//
//  Created by mac on 16/9/15.
//  Copyright © 2016年 ___Intelligent Automation___. All rights reserved.
//

#import "MessageBoxView.h"


@implementation MessageBoxView
{
    
}


-(int)Show
{
 
    return 0;
}

-(int)ShowMessageBox:(NSString *)msg
{
    
    NSLog(@"ShowMessageBox55---------------");
    CFOptionFlags  result;
    NSString *strMsg = [NSString stringWithFormat:@"%i", 234];
    CFStringRef* msg_ref;
    
    CFUserNotificationDisplayAlert(0,
                                   kCFUserNotificationNoDefaultButtonFlag,
                                   NULL, NULL, NULL,
                                   CFSTR("Title"),
                                    (__bridge CFStringRef)(msg),
                                   NULL, NULL, NULL, &result);
    
    
    return 0;
  /*
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    NSAlert *alert = [[NSAlert alloc] init];
    
    
    if (msg)
    {
        [alert setInformativeText:@"msgggg8"];
    }
    
    [alert setAlertStyle:NSWarningAlertStyle];
    

    int ret = (int)[alert runModal];
    
    [alert.window close];
    [alert.window orderOut:nil];
    [alert.window performClose:nil];
    
    NSLog(@"@@@@@@@@@@@@@ShowMessageBox11");
    NSPanel;
    [pool drain];
    return ret;
   */
    
}

@end
