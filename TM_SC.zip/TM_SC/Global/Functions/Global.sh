#!/bin/sh

#  Global.sh
#  Global
#
#  Created by Ryan on 12-11-8.
#  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.

INPUT=Global_Function.pkg
OUTPUT=Global_Function-lua.mm

#tolua=tolua++
#tolua=/Users/ryan/Project/LUA/tolua++-1.0.93/bin/tolua++

tolua=/usr/local/lib/tolua++
#tolua=tolua++

#global variant for all unit with the same value
$tolua -o  $OUTPUT $INPUT

#$tolua -o tc_variant-lua.mm tc_variant.pkg
#Global variant for each unit

