//
//  USB.h
//  Global
//
//  Created by Ryan on 13-2-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#ifndef Global_USB_h
#define Global_USB_h

unsigned int GetUsbLocation(long vid,long pid);
int CheckUsb(unsigned long usb_address);    //1: usb connecting, 0: usb disconnect.
int WaitUsb(unsigned long usb_address,int timeout=3000);    //waiting for a usb device conntected

#endif
