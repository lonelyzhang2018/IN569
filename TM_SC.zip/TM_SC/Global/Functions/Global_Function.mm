//
//  Global_Function.cpp
//  Global
//
//  Created by Ryan on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#include <iostream>
#include "Global_Function.h"
#include "USB.h"
#include <stdio.h>


//#include <TMLibrary/MessageInterface.h>

NSLock * g_global = [[NSLock alloc]init];
MessageBoxView * box = [[MessageBoxView alloc]init];

//Time
double Now()
{
    return [[NSDate date] timeIntervalSince1970];
}

//Delay
#pragma mark Delay
void Delay(int ms)
{
    [NSThread sleepForTimeInterval:(double)ms/1000.0];
}

#pragma mark bit operation
int BitSelect(int data,int bit)
{
    int x = 0x01<<bit;
    int value = data &x;
    return value?1:0;
}

void set_bit(unsigned long * pdata,unsigned char index)
{
    setbit(pdata, index);
}
void clr_bit(unsigned long * pdata,unsigned char index)
{
    clrbit(pdata, index);
}

unsigned char get_bit(unsigned long data,unsigned char index)
{
    unsigned v = unsigned(data);
    return !isclr(&v, index);
}

unsigned long bit_and(unsigned long x,unsigned long y)     //and
{
    return x&y;
}
unsigned long bit_or(unsigned long x,unsigned long y)      //or
{
    return x|y;
}
unsigned long bit_not(unsigned long x)                     //not
{
    return ~x;
}
unsigned long bit_xor(unsigned long x,unsigned long y)     //xor
{
    return x^y;
}
unsigned long bit_nor(unsigned long x,unsigned long y)     //nor
{
    return ~(x^y);
}

#pragma mark system

//Execute
//Run a application in background
//int Execute(const char * szcmd,int waituntilreturn,int itimeout)
static int Execute_withTask(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
    //   return system(szcmd);
    if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    //NSLog(@"arguments : %@",[argus description]);
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    
    NSTask * task = [[NSTask alloc] init];
    if (poutput)
    {
        NSString * str = [NSString stringWithUTF8String:poutput];
        str = [str stringByResolvingSymlinksInPath];
        [[NSFileManager defaultManager] createFileAtPath:str contents:nil attributes:nil];
        id handle =[NSFileHandle fileHandleForWritingAtPath:str];
        [task setStandardOutput:handle];
        [task setStandardError:handle];
    }
    
    [task setLaunchPath:[arg objectAtIndex:0]];
    
    [task setArguments:arguments];
    
    [task launch];
    
    if (waituntilreturn)
    {
        NSLog(@"Executing... %s",szcmd);
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1) {
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            //if ((now-start)>itimeout/1000)
            if ((now-start)>50)
            {
                [task terminate];
                [task release];
                NSString * str = [NSString stringWithFormat:@"%s\r\nTask time out in %d millionseconds.",szcmd,itimeout];
                NSLog(@"%@", str);
                [task release];
                return -1;
                @throw [NSException exceptionWithName:@"NSTask" reason:str userInfo:nil];
            }
            
            if ([[NSThread currentThread] isCancelled])
            {
                NSLog(@"Thread cancelled!");
                [task release];
                return -2;  //cancel
            }
            
            if (![task isRunning]) break;
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            //[NSThread sleepForTimeInterval:0.001];
        }
        int ret = [task terminationStatus];
        [task release];
        NSLog(@"process normal finish! @ %s",szcmd);
        return ret;
    }
    //return [task processIdentifier];
    NSLog(@"process normal finish11! %s",szcmd);
    return 0;
}

int Execute(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
    return Execute_withTask(szcmd,poutput, waituntilreturn, itimeout);
}


#pragma mark data convert
//NSLog(@"codec: %s", getAlertCal(1, 0.93768596858663));// 0x00000001 0x3F700C30
const char *  floatConversion(float value)
{
    Float32 val = value;
    Byte * p = (Byte *)&val;
    NSMutableString * str = [NSMutableString stringWithString:@"0x"];
    for(int i=3;i>=0;i--)
        [str appendFormat:@"%02X",p[i]];
    return [str UTF8String];
}

float floatToNumber(char * dataStr)
{
    NSString * str= [NSString stringWithFormat:@"%s",dataStr];
    unsigned int fix_data;
    NSScanner * nsscan = [[NSScanner alloc]initWithString: str];
    [nsscan scanHexInt:&fix_data];
    Float32 val;
    memcpy(&val, &fix_data, 4);
    return val;
}

const char* floatToFixed(double num)
{
    if (num>32767.9999847412109375) num=32767.9999847412109375;
    else if(num< -32768) num=-32768;
    //   unsigned int fix_data = (int)(num * (Float32)((int)1 << 16));
    unsigned int fix_data = FloatToFixed(num);
    return [[NSString stringWithFormat:@"0x%08X", fix_data]UTF8String];
}

double fixedToNumber(char * dataStr)
{
    NSString * str= [NSString stringWithFormat:@"%s",dataStr];
    unsigned int fix_data;
    NSScanner * nsscan = [[NSScanner alloc]initWithString: str];
    [nsscan scanHexInt:&fix_data];
    [nsscan release];
    if (fix_data > pow(2, 31)-1) {
        fix_data = fix_data - pow(2,32);
    }
    int temp = [[NSString stringWithFormat:@"%d",fix_data]intValue];
    return FixedToFloat(temp);
}


#pragma mark USB Location
#define VID     0x9011
#define PID     0x2514

NSString * InitialUsb(int uut)//uut start from 0
{
    NSLog(@"Get usb location from default VID(0x9011)/PID(0x2514)");
    unsigned int locationID = GetUsbLocation(VID, PID);
//        if (!locationID) return -1; //could not find the specail usb hub.

    int offset = 0x0000000F;
    int i=0;
    for (i=0; i<8; i++) {
        if ((locationID&(offset<<(4*i)))==0) continue;
        else {
            break;
        }
    }
    
    offset = pow(0x10, i-1);
    NSLog(@"Hub Address : 0x%08x",locationID);

    NSString * usbId = [NSString stringWithFormat:@"0x%08x",locationID+offset*(uut+1) ];
    
    NSLog(@"%@%d = %@",@"usb",uut,usbId);
    return usbId;
}

#define kHub    @"UsbHub"
#define kVID    @"VID"
#define kPID    @"PID"
#define kMAP    @"MAP"
#define kCH    @"ch"

int InitialUsbwithDictionary(int uut, NSMutableString * usbId, const char * file)
{
    NSString * str = @"/vault/Config/UsbLocation.plist";
    if(file)
        str = [NSString stringWithUTF8String:file];
    NSLog(@"get usb location form file : %@", str);
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:str];
    if(dic)
    {
        NSArray * arr = [dic valueForKey:kHub];
        if (!arr) return -1;
        for (NSDictionary * dic in arr)
        {
            int vid = (int)strtol([[dic valueForKey:kVID] UTF8String], NULL, 16);
            int pid = (int)strtol([[dic valueForKey:kPID] UTF8String], NULL, 16);
        
            NSDictionary * map = [dic valueForKey:kMAP];
        
            if ((!map)||[[map allKeys] count]==0) continue; //all channel of this hub no use
        
            UInt32 locationID = GetUsbLocation(vid,pid);
        
            int offset = 0x0000000F;
            int i=0;
            for (i=0; i<8; i++) {
                if ((locationID&(offset<<(4*i)))==0) continue;
                else {
                    break;
                }
            }
        
            offset = pow(0x10, i-1);
            NSLog(@"Hub Address : 0x%08x",locationID);
        
            for (int i=0; i<=7; i++) {
                NSString * chn = [NSString stringWithFormat:@"%@%d",kCH,i];
                if ([map valueForKey:chn])
                {
//                    NSString * chn = [NSString stringWithFormat:@"%@%d",kCH,uut];
                        int slot = [[map valueForKey:chn] intValue];
                        if(slot == uut)
                        {
                            [usbId setString:[NSString stringWithFormat:@"0x%08x",locationID+offset*(i+1)]];    //set usblocation value
                            NSLog(@"Chn%d Usb Location : %@",slot,usbId);
                            return 0;
                        }
                }
            }
        
        }
    }
    return -1;
}

const char * getUsbLocation(int uut, const char * file)
{
    NSMutableString * usbId = [[NSMutableString alloc] init];
    if (InitialUsbwithDictionary(uut, usbId, file)<0)
        [usbId setString:InitialUsb(uut)];//no special usb chip id, use default
    NSString * str = [NSString stringWithString:usbId];
    [usbId release];
    return [str UTF8String];
}

#pragma mark Instrument Synchronization

#define kLockState @"lockState"
#define kLockHandle @"lockHandle"
NSMutableDictionary * InstrumentKeyChain = [[[NSMutableDictionary alloc]init]retain];
int LockInstrument(const char * szLockName)
{
    NSLog(@"LockInstrument : %s", szLockName);
    NSString * lockName = [NSString stringWithUTF8String:szLockName];
    if([lockName length]<=0)
    {
        NSLog(@"LockInstrument : %s Invalide Lock Name", szLockName);
        return -999;
    }
    FILE * fp;
    NSString * path = [NSString stringWithFormat:@"/vault/.%@.lock", lockName];
    if(![[NSFileManager defaultManager]fileExistsAtPath:path])
        [[NSFileManager defaultManager]createFileAtPath:path contents:nil attributes:nil];
    if((fp=fopen([path UTF8String], "r+w")) == NULL)
    {
        NSLog(@"File Open error");
        return -1;
    }
    if(flock(fp->_file, LOCK_EX) != 0)
    {
        NSLog(@"File Locked error");
        return -2;
    }
    
    NSMutableDictionary * dic = [NSMutableDictionary dictionary];
    [dic setObject:[NSNumber numberWithBool:YES] forKey:kLockState];
    [dic setObject:(__bridge id _Nullable)fp forKey:kLockHandle];
//    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES],kLockState,(__bridge id _Nullable)fp,kLockHandle, nil];
    [InstrumentKeyChain setObject:dic forKey:lockName];
    NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
    NSLog(@"LockInstrument : %s Success", szLockName);
    return 0;
}

int UnlockInstrument(const char * szLockName)
{
    NSLog(@"unLockInstrument : %s", szLockName);
    NSString * lockName = [NSString stringWithUTF8String:szLockName];
    if([lockName length]<=0) return -999;
    NSLog(@"All key in chain : %@",[[InstrumentKeyChain allKeys]componentsJoinedByString:@","]);
    NSDictionary * dic = [InstrumentKeyChain objectForKey:lockName];
    if(dic)
    {
        FILE * fp = (__bridge FILE *)[dic objectForKey:kLockHandle];
        BOOL lockState = [[dic objectForKey:kLockState]boolValue];
        if(fp && lockState)
        {
            fclose(fp);
            flock(fp->_file, LOCK_UN);
            fp = NULL;
            [InstrumentKeyChain removeObjectForKey:lockName];
        }
        NSLog(@"unLockInstrument : %s Success", szLockName);
        return 0;
    }
    else
        NSLog(@"unLockInstrument : %s has no this lock", szLockName);
        return 0;
    return 0;
}

int UnlockAllInstrument()
{
    NSArray * keyArr = [InstrumentKeyChain allKeys];
    for(NSString * key in keyArr)
    {
        NSDictionary * dic = [InstrumentKeyChain objectForKey:key];
        if(dic)
        {
            FILE * fp = (__bridge FILE *)[dic objectForKey:kLockHandle];
            BOOL lockState = [[dic objectForKey:kLockState]boolValue];
            if( fp && lockState)
            {
                fclose(fp);
                flock(fp->_file, LOCK_UN);
                fp = NULL;
            }
        }
    }
    [InstrumentKeyChain removeAllObjects];
    return 0;
}

void postDistributedNotification(const char * name, const char * msg)
{
    LockInstrument("postNotification");
    //[NSThread sleepForTimeInterval:0.2];
    if(msg)
    {
        NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithUTF8String: msg],@"mesg", nil];
        [[NSDistributedNotificationCenter defaultCenter] postNotificationName:[NSString stringWithUTF8String:name] object:nil userInfo:dic];
    }
    else
        [[NSDistributedNotificationCenter defaultCenter]postNotificationName:[NSString stringWithUTF8String:name] object:nil];
    UnlockInstrument("postNotification");
    return;
}

const char* putSFC(char* szHttp)
{
    NSString* strHttp = [NSString stringWithUTF8String:szHttp];
    NSURL *SFC=[NSURL URLWithString:strHttp];
    NSString *ret = [NSString stringWithContentsOfURL:SFC encoding: NSASCIIStringEncoding error:NULL ];
    if (ret==nil)
        return NULL;
    else
        return [ret UTF8String];
}


int msgbox(const char * title,const char * msg,const char * button1,const char * button2,const char * button3)
{
   // NSAlert *alert = [[[NSAlert alloc] init] autorelease];
    NSAlert *alert = [[NSAlert alloc] init];

    if (title)
    {
        [alert setMessageText:[NSString stringWithUTF8String:title]];
    }
    if (msg)
    {
        [alert setInformativeText:[NSString stringWithUTF8String:msg]];
    }
    if (button1)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button1]];
    }
    if (button2)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button2]];
    }
    if (button3)
    {
        [alert addButtonWithTitle:[NSString stringWithUTF8String:button3]];
    }
    [alert setAlertStyle:NSWarningAlertStyle];
    
    int ret = (int)[alert runModal];
    
    
//   [alert dealloc];
    [alert release];
    NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!!!!!!!!====11");
//    [alert close];
   
    
//    [alert release];
    
    return ret;
    //return int([alert runModal]);
}

int MessageBox(const char*msg)
{
    //        [NSString stringWithFormat:@"%s",msg]
    // int ret =(int) NSRunAlertPanel(@"Prompt", @"%@", @"OK", nil, nil, [NSString stringWithCString:msg encoding:NSUTF8StringEncoding]) ;
     NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@!!!!!!!!====5");
   // int ret = msgbox("Info",msg,nil,nil,nil);
    
    int ret = [box ShowMessageBox:[NSString stringWithUTF8String:msg]];    
    return ret;
   // return 0 ;
}

int MsgButton(const char *msg, const char *DefaultReturn , const char *AlternateReturn , const char *OtherReturn)
{
       NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@MsgButton des");
    
    NSAlert *alert = [NSAlert alertWithMessageText:[NSString stringWithUTF8String:msg]
                                     defaultButton:[NSString stringWithUTF8String:DefaultReturn]
                                   alternateButton:[NSString stringWithUTF8String:AlternateReturn]
                                       otherButton:[NSString stringWithUTF8String:OtherReturn]
                         informativeTextWithFormat:@"informativeText"];
    
    NSUInteger action = [alert runModal];
    //响应window的按钮事件
    if(action == NSAlertDefaultReturn)
    {
        NSLog(@"defaultButton clicked!");
    }
    else if(action == NSAlertAlternateReturn )
    {
        NSLog(@"alternateButton clicked!");
    }
    else if(action == NSAlertOtherReturn)
    {
        NSLog(@"otherButton clicked!");
    }
    
//     [alert release];
//   [alert dealloc];
   
    

     NSLog(@"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@MsgButton des2");
    
    
    
    return int(action);
}


