//
//  Global_Function.h
//  Global
//
//  Created by Ryan on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#pragma once

#include "MessageBoxView.h"
//Global Function
void Delay(int ms);     //Delay with milliseconds
double Now();           //Returns the interval between the receiver and the first instant of 1 January 1970, GMT

// This set of Locks allows for locking arbitrary critical section by name.
// Note that while each named lock is unique, they have global scope, making UnlockAllInstrument() an ungraceful reset.
int LockInstrument(const char * szLockName);
int UnlockInstrument(const char * szLockName);
int UnlockAllInstrument();

//bit opeartion
int BitSelect(int data,int bit);
void set_bit(unsigned long * pdata,unsigned char index);
void clr_bit(unsigned long * pdata,unsigned char index);
unsigned char get_bit(unsigned long data,unsigned char index);
unsigned long bit_and(unsigned long x,unsigned long y);     //and
unsigned long bit_or(unsigned long x,unsigned long y);      //or
unsigned long bit_not(unsigned long x);                     //not
unsigned long bit_xor(unsigned long x,unsigned long y);     //xor
unsigned long bit_nor(unsigned long x,unsigned long y);     //nor

//system
int Execute(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout);

//number conversion
const char *  floatConversion(float value);
float floatToNumber(char * dataStr);
const char* floatToFixed(double num);
double fixedToNumber(char * dataStr);

const char * getUsbLocation(int uut, const char * file);

void postDistributedNotification(const char * name, const char * msg);
const char* putSFC(char* szHttp);
int msgbox(const char * title,const char * msg,const char * button1,const char * button2,const char * button3);
int MessageBox(const char*msg);
int MsgButton(const char *msg, const char *DefaultReturn , const char *AlternateReturn , const char *OtherReturn);

