//
//  DeviceMessage.cpp
//  Global
//
//  Created by Ryan on 8/30/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#include "DeviceMessage.h"

#include <lua.hpp>


#define CLI_CR_RED          "\033[31m"
#define CLI_CR_YELLOW       "\033[33m"
#define CLI_CR_CLOSE        "\033[0m"

CDeviceHost::CDeviceHost()
{
    m_pHost = new CMessageHost();
}

CDeviceHost::~CDeviceHost()
{
    delete m_pHost;
}

int CDeviceHost::CreateHost(const char *name, int port)
{
    int ret = m_pHost->CreateHost(name,port);
    m_pHost->SetCallBack(CDeviceHost::OnMessage,this);
    printf("Current State : %p\r\n",m_pCurrState);
    m_port = port;
    return ret;
}

int CDeviceHost::SendMsg(const char *msg,const char * cmd)
{
    if (!msg) {
        return -1;
    }
    std::map<std::string, std::string> map;
    map["msg"] = msg;
    m_pHost->SendMessage(cmd,&map);
    return 0;
}

void * CDeviceHost::OnMessage(std::string cmd, std::map<std::string, std::string> arg, void *context)
{
    CDeviceHost * pThis = (CDeviceHost *)context;
    lua_getglobal(pThis->m_pCurrState, (const char *)pThis->m_CallBackName);
    lua_pushstring(pThis->m_pCurrState, cmd.c_str());
    int ret = lua_pcall(pThis->m_pCurrState, 1, 1, 0);
    if (ret) {
        printf("%sHost get ERROR : %s\r\n%s",CLI_CR_RED,lua_tostring(pThis->m_pCurrState, -1),CLI_CR_CLOSE);
    }
    return nullptr;
}

int CDeviceHost::SetCallBack(const char *funName)
{
    strcpy(m_CallBackName, funName);
    return 0;
}