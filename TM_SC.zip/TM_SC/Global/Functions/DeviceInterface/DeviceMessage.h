//
//  DeviceMessage.h
//  Global
//
//  Created by Ryan on 8/30/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#ifndef __Global__DeviceMessage__
#define __Global__DeviceMessage__

#include <stdio.h>
#include <lua.hpp>

#include <TMLibrary/MessageInterface.h>
#include <string>

class CDeviceHost {
public:
    CDeviceHost();
    ~CDeviceHost();
    
public:
    int CreateHost(const char * name,int port);
    int SetCallBack(const char * funName);
    
    int SendMsg(const char * msg,const char * cmd="msg");
    
    static void*OnMessage(std::string cmd,std::map<std::string, std::string> arg,void * context);
    
    lua_State * m_pCurrState;
    char m_CallBackName[128];
protected:
    CMessageHost * m_pHost;
    int m_port;
    
    
    
};

#endif /* defined(__Global__DeviceMessage__) */
