/*
** Lua binding: TCPIP_object
** Generated automatically by tolua++-1.0.92 on Wed May 20 21:29:45 2015.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"
#include "ThdnInter.h"

/* Exported function */
TOLUA_API int  tolua_ThdnInterface_object_open (lua_State* tolua_S);

typedef struct obj_state
{
    int id;
    CInterface* obj;
    lua_State* s;
    struct obj_state *pNext;
}OBJ_STATE,*pOBJ_STATE;

pOBJ_STATE pOrigin = NULL;
pOBJ_STATE pEnd = NULL;


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"CInterface");
}

/* get function: TCPIP_Obj */
#ifndef TOLUA_DISABLE_tolua_get_TCPIP_Obj_ptr
static int tolua_get_ThdnInterface_Obj_ptr(lua_State* tolua_S)
{
    pOBJ_STATE p = pOrigin->pNext;
    while(NULL != p)
    {
        if (p->s == tolua_S) {
            break;
        }
        p = p->pNext;
    }
//    NSLog(@"get lua Index: %d\r\n",index);
   tolua_pushusertype(tolua_S,(void*)p->obj,"CInterface");
 return 1;
}
#endif //#ifndef TOLUA_DISABLE

/* set function: TCPIP_Obj */
#ifndef TOLUA_DISABLE_tolua_set_TCPIP_Obj_ptr
static int tolua_set_ThdnInterface_Obj_ptr(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
  tolua_Error tolua_err;
  if (!tolua_isusertype(tolua_S,2,"CInterface",0,&tolua_err))
   tolua_error(tolua_S,"#vinvalid type in variable assignment.",&tolua_err);
#endif
    pOBJ_STATE p = pOrigin->pNext;
    while(NULL != p)
    {
        if (p->s == tolua_S) {
            break;
        }
        p = p->pNext;
    }
//    NSLog(@"set lua Index: %d\r\n",index);
  p->obj = ((CInterface*)  tolua_tousertype(tolua_S,2,0))
;
 return 0;
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_ThdnInterface_object_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,1);
 tolua_beginmodule(tolua_S,NULL);
  tolua_variable(tolua_S,"THDN_Obj",tolua_get_ThdnInterface_Obj_ptr,tolua_set_ThdnInterface_Obj_ptr);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_ThdnInterface_object (lua_State* tolua_S) {
 return tolua_ThdnInterface_object_open(tolua_S);
};

TOLUA_API int tolua_THDN_open (lua_State* tolua_S);

int ThdnInterface_Obj_Init(lua_State* pLuaState, int mid)
{
    if (pOrigin == NULL) {
        pOrigin = new OBJ_STATE;
        pEnd = pOrigin;
        pEnd->pNext = NULL;
    }
    
    pOBJ_STATE pNew = new OBJ_STATE;
    pNew->id = mid;

    pNew->obj = new CInterface();

    pNew->s = pLuaState;
    pEnd->pNext = pNew;
    pNew->pNext = NULL;
    pEnd = pNew;
    tolua_THDN_open(pLuaState);
    tolua_ThdnInterface_object_open(pLuaState);
    
    return 0;
}
#endif

