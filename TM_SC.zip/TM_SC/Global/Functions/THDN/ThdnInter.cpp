//
//  ThdnInter.cpp
//  Global
//
//  Created by IvanGan on 15/9/6.
//  Copyright (c) 2015年 ___Intelligent Automation___. All rights reserved.
//

#include "ThdnInter.h"

CInterface::CInterface()
{
    mThdn = new CTHDN();
}

CInterface::~CInterface()
{
    delete mThdn;
}

double CInterface::THDN_Matlab(char * right, char * left)
{
    double thdn;
    mThdn->THDN_Matlab(right, left, &thdn);
    return thdn;
}

double CInterface::THDN_OneLine(char *data)
{
    double thdn;
    double thd;
    mThdn->THDN_OneLine(data, &thd, &thdn);
    return thdn;
}

double CInterface::THDN_TwoLine(char * right, char * left)
{
    double thdn;
    double thd;
    mThdn->THDN_TwoLine(right, left, &thd, &thdn);
    return thdn;
}

