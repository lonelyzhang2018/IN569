#pragma once

//#define  PI 3.1415926

class CTHDN
{
    
    int m_limitUp;
    int m_limitDown;
public:
	CTHDN(void);
	~CTHDN(void);

//Parament
public:
	double m_b[4];// fft window coef ,default: m_b[0] = 0.338946;m_b[1] = 0.481973;m_b[2] = 0.161054;m_b[3] = 0.018027;

	int m_Fs;// sample rate,default: m_Fs = 192000;

	int m_windowSize;// fft window size,should be pow 2,default: m_windowSize = 8192;

	double m_aphaCoef[3];//interpolation coef,default:m_aphaCoef[0] = 2.95494514;m_aphaCoef[1] = 0.17671943;m_aphaCoef[2] = 0.09230694;

	double m_ACoef[3];// A coef ,m_ACoef[0] = 3.20976143;m_ACoef[1] = 0.9187393;m_ACoef[2] = 0.14734229;

	double m_THDCoef;// THD coef,default: m_THDCoef = 20;

	int m_THD_ORD;//m_THD_ORD = 7;
//Function
public:

	bool THDN_Matlab( char* right,char* left,double *thdn );
	bool THDN_OneLine( char* data,double* thd,double* thdn );
	bool THDN_TwoLine( char* right,char* left,double* thd,double* thdn );
	
	bool THDN( double* data,int len,double* thd,double* thdn );


	void signalWithNutgallWindow( double* data,int len,double* result );
	double  NuttallWindow( int n );
	double  calculateA( double* data,int N,double  fb,int n,int *k );
	double  calculateTHD( double  A1,double  A2,double  A3,double  A4,double  A5 );
	void  generateResult( double* data,int len,double* thd,double* thdn );
	double  calculateTHDN( double* data,double  A1,double  A2,double  A3,double  A4,double  A5,int k1,int k2,int k21,int k31,int k41,int k51,int fb,int N );
	void  signalWithFFT( double* data,double* result,int len );
	void signalWithHanningWindow( double* data,int len,double* result );
	double HanningWindow( int n );
	void harrisWindow( double* data,int len,double* result );

	void linspace( double start,double end ,int N,double* result );

	
};

