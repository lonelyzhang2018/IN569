//
//  Global.h
//  Global
//
//  Created by Ryan on 4/17/15.
//  Copyright (c) 2015 ___Intelligent Automation___. All rights reserved.
//

#ifndef __Global__Global__
#define __Global__Global__
#include "lua.hpp"

#define DL_EXPORT __attribute__((visibility("default")))

#include <stdio.h>

extern "C" int luaopen_libGlobal(lua_State * state);

#endif /* defined(__Global__Global__) */
