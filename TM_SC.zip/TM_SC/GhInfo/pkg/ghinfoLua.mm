//
//  ArmDl.m
//  TCPIP
//
//  Created by IvanGan on 15/5/25.
//  Copyright (c) 2015年 IA. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "ghInfoLua.h"


int tolua_ghInfo_open (lua_State* tolua_S);

extern "C" int luaopen_libGhInfo(lua_State * state)
{
    NSLog(@"Load GhInfo Dylib\r\n");
    tolua_ghInfo_open(state);
    return 0;
}