//
//  ArmDl.h
//  TCPIP
//
//  Created by IvanGan on 15/5/25.
//  Copyright (c) 2015年 IA. All rights reserved.
//

#ifndef GH_INFO_h
#define GH_INFO_h
#include "lua.hpp"

#define DL_EXPORT __attribute__((visibility("default")))

#include <stdio.h>

extern "C" int luaopen_libGhInfo(lua_State * state);

#endif
