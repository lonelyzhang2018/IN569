#
#  GPIO.sh
#  TCPIP
#
#  Created by IvanGan on 15/5/14.
#  Copyright (c) 2015年 IA. All rights reserved.
#

tolua=/usr/local/lib/tolua++

$tolua -o ghInfo.mm ghInfo.pkg
#$tolua -o TCPIP_Object_Lua.mm TCPIP_object.pkg
