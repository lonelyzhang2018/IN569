//
//  GT_Global.h
//  Global
//
//  Created by Ryan on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GH_Info : NSObject
{
@private
    NSMutableDictionary * dic;
}
-(void)IntialStation;
-(NSString *) GetDicContent:(NSString *) key;
@end
