//
//  GhInfoInterface.h
//  GhInfo
//
//  Created by IvanGan on 15/9/3.
//  Copyright (c) 2015年 IA. All rights reserved.
//

#ifndef __GhInfo__GhInfoInterface__
#define __GhInfo__GhInfoInterface__

#include <stdio.h>
extern "C"
{
    int Initial();
    const char * GetInfo(char * key);
    int Dealloc();
}

#endif /* defined(__GhInfo__GhInfoInterface__) */
