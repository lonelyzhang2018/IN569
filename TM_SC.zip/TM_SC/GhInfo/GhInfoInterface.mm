//
//  GhInfoInterface.cpp
//  GhInfo
//
//  Created by IvanGan on 15/9/3.
//  Copyright (c) 2015年 IA. All rights reserved.
//

#include "GhInfoInterface.h"
#import "GH_Info.h"


GH_Info * pGI = NULL;
int Initial()
{
    pGI = [[GH_Info alloc]init];
    [pGI IntialStation];
    return 0;
}

const char * GetInfo(char * key)
{
    if(pGI==NULL)
    {
        Initial();
    }
    
    NSString * p = [pGI GetDicContent:[NSString stringWithUTF8String:key]];
    if(p)
        return [p UTF8String];
    else
        return NULL;
}

int Dealloc()
{
    [pGI release];
    return 0;
}
