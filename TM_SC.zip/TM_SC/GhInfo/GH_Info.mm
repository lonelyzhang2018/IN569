//
//  GT_Global.m
//  Global
//
//  Created by Ryan on 12-11-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GH_Info.h"

#import "InstantPudding_API.h"

#import "CBAuth.h"
#import "ContextKey.h"

@implementation GH_Info

-(id)init
{
    self = [super init];
    if (self)
    {
        dic = [[NSMutableDictionary alloc]init];
    }
    return self;
}

-(void)dealloc
{
    if (dic) {
        [dic removeAllObjects];
        [dic release];
    }
    [super dealloc];
}


#define Restore_Path        @"/Users/Ryan/Restore Info.txt"
//#define Restore_Path        @"/Users/gdlocal/Desktop/Restore Info.txt"
#define JASON_Path          @"/vault/data_collection/test_station_config/gh_station_info.json"

-(NSString * )IP_GetInfo:(IP_UUTHandle)ipHandle item:(IP_ENUM_GHSTATIONINFO)ipItem
{
    size_t sLength=0;
    IP_API_Reply reply = IP_getGHStationInfo(ipHandle, ipItem, NULL, &sLength);
    if(!IP_success(reply))
    {
        NSLog(@"Error from First call IP_getGHStationInfo(): ");
    }
    IP_reply_destroy(reply);
    
    char *cpValue = new char[sLength+1];
    
    reply = IP_getGHStationInfo(ipHandle, ipItem, &cpValue, &sLength);
    if(!IP_success(reply))
        NSLog(@"Error from second call IP_getGHStationInfo(): ");
    IP_reply_destroy(reply);
    NSString * ipInfo = [NSString stringWithUTF8String:cpValue];
    delete cpValue;
    return ipInfo;
}

-(void)getCBAuthConfig
{
    NSMutableString* strCBAuthStationNameToCheck = [[NSMutableString alloc] initWithString:@""];
    NSMutableString* strCBAuthNumberToCheck = [[NSMutableString alloc] initWithString:@""];
    NSString* strCBAuthMaxFailForStation = nil;
    NSMutableString* strCBAuthToClearOnPass = [[NSMutableString alloc] initWithString:@""];
    NSMutableString* strCBAuthToClearOnFail = [[NSMutableString alloc] initWithString:@""];
    NSString* strCBAuthStationSetControlBit = nil;
    
    CBAuth* cbAuth = [[CBAuth alloc] init];
    
    NSDictionary* dicNameAndNumberToCheck = [cbAuth getControlBitsToCheck];
    NSArray* arrCBAuthStationName = [dicNameAndNumberToCheck allKeys];
    for (int i=0; i<[arrCBAuthStationName count]; i++)
    {
        [strCBAuthStationNameToCheck appendFormat:@"%@;", [arrCBAuthStationName objectAtIndex:i]];
        NSNumber* num = [dicNameAndNumberToCheck objectForKey:[arrCBAuthStationName objectAtIndex:i]];
        [strCBAuthNumberToCheck appendFormat:@"0x%02x;", [num intValue]];
    }
    strCBAuthMaxFailForStation = [NSString stringWithFormat:@"%d",[cbAuth getControlBitsMaxFailForStation]];
    
    NSArray* arr1 = [cbAuth getControlBitsToClearOnPass];
    for (int i=0; i<[arr1 count]; i++)
    {
        [strCBAuthToClearOnPass appendFormat:@"0x%02x;", [[arr1 objectAtIndex:i] intValue]];
    }
    
    NSArray* arr2 = [cbAuth getControlBitsToClearOnFail];
    for (int i=0; i<[arr2 count]; i++)
    {
        [strCBAuthToClearOnFail appendFormat:@"0x%02x;", [[arr2 objectAtIndex:i] intValue]];
    }
    
    if ([cbAuth getStationSetControlBit]) {
        strCBAuthStationSetControlBit = @"YES";
    }else
    {
        strCBAuthStationSetControlBit = @"NO";
    }

    [dic setValue:strCBAuthStationNameToCheck forKey:@kContextCBAuthStationNameToCheck];
    [dic setValue:strCBAuthNumberToCheck forKey:@kContextCBAuthNumberToCheck];
    [dic setValue:strCBAuthMaxFailForStation forKey:@kContextCBAuthMaxFailForStation];
    [dic setValue:strCBAuthToClearOnPass forKey:@kContextCBAuthToClearOnPass];
    [dic setValue:strCBAuthToClearOnFail forKey:@kContextCBAuthToClearOnFail];
    [dic setValue:strCBAuthStationSetControlBit forKey:@kContextCBAuthStationSetControlBit];
    
    [cbAuth release];
    [strCBAuthStationNameToCheck release];
    [strCBAuthNumberToCheck release];
    [strCBAuthToClearOnPass release];
    [strCBAuthToClearOnFail release];
}

-(void)IntialStation
{
    //station information
    IP_UUTHandle ipHandle;
    IP_reply_destroy(IP_UUTStart(&ipHandle));
    NSString * ipInfo;
    NSString * ipInfo2 ;
    
    ipInfo = [self IP_GetInfo:ipHandle item:IP_PRODUCT];
    ipInfo2 = [self IP_GetInfo:ipHandle item:IP_STATION_TYPE];
    [dic setValue:[NSString stringWithFormat:@"%@ %@",ipInfo, ipInfo2] forKey:@kContextStationName];
//    NSLog(@"StationName: %@",[NSString stringWithFormat:@"%@ %@",ipInfo, ipInfo2]);
    
    ipInfo = [self IP_GetInfo:ipHandle item:IP_STATION_ID];
    [dic setValue:ipInfo forKey:@kContextStationID];
    
    ipInfo = [self IP_GetInfo:ipHandle item:IP_LINE_NUMBER];
    [dic setValue:ipInfo forKey:@kContextLineNumber];
    ipInfo2 = [self IP_GetInfo:ipHandle item:IP_STATION_NUMBER];
    [dic setValue:ipInfo2 forKey:@kContextStationNumber];
    [dic setValue:[NSString stringWithFormat:@"%@_%@",ipInfo, ipInfo2] forKey:@kContextLineName];

    ipInfo = [self IP_GetInfo:ipHandle item:IP_STATION_TYPE];
    [dic setValue:ipInfo forKey:@kContextStationType];
//    NSLog(@"Station Type: %@", ipInfo);

    ipInfo = [self IP_GetInfo:ipHandle item:IP_PDCA_IP];
    [dic setValue:ipInfo forKey:@kContextPdcaServer];

    
    ipInfo = [self IP_GetInfo:ipHandle item:IP_SFC_IP];
    [dic setValue:ipInfo forKey:@kContextSfcServer];
    
    ipInfo = [self IP_GetInfo:ipHandle item:IP_SFC_URL];
    [dic setValue:ipInfo forKey:@kContextSfcURL];
    
    IP_reply_destroy(IP_UUTCancel(ipHandle));

    [self getCBAuthConfig];
}

-(NSString *)GetDicContent:(NSString *) key
{
    if([dic objectForKey:key])
        return [dic objectForKey:key];
    else
        return NULL;
}

@end
