//
//  CEload.cpp
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//

#include "CEload.h"

#include "zmq.h"

#include <iostream>
#include <sstream>

#include <unistd.h>

NSLock * g_LockCB = [[NSLock alloc]init];

CEload::CEload()
{
    pthread_mutex_init(&m_mutex,nil);
    pthread_mutex_init(&m_lockOperate, nil);
    m_strBuffer = [[NSMutableString alloc]init];
    m_DataBuffer = [[NSMutableData alloc]init];
    m_strDetect = [[NSMutableString alloc]init];
    m_Return = [[NSMutableString alloc]init];
    
    bNeedZmq = false;
    bNeedReply = false;
    bNeedPub = false;
    iTimeout = 3000;
}

CEload::~CEload()
{
    pthread_mutex_destroy(&m_mutex);
    pthread_mutex_destroy(&m_lockOperate);
    [m_strDetect release];
    [m_strBuffer release];
    [m_DataBuffer release];
    [m_Return release];
}

int CEload::CreateIPC(const char * reply, const char * publish)
{
    CPubliser::bind(publish);
    CReplier::bind(reply);
    bNeedZmq = true;
    return 0;
}

void * CEload::didReceiveData(void * data, long len)
{
    if(len < 0)
        return nullptr;
    pthread_mutex_lock(&m_mutex);
    if(bNeedZmq)
        Pulish(data, len);
    [m_DataBuffer appendBytes:(Byte*)data length:len];
    char * p = (char *)data;
    for(int i=0; i<len; i++)
    {
        if(p[i] == '\0')
            p[i] = '.';
    }
    NSString * str = [[NSString alloc]initWithBytes:data length:len encoding:NSUTF8StringEncoding];
    if(str)
       [m_strBuffer appendString:str];
    [str release];
    pthread_mutex_unlock(&m_mutex);
    return nullptr;
}

int CEload::SetRepOpt(int needReply, int timeout)
{
    bNeedReply = (needReply>0) ? YES : NO;
    iTimeout = timeout;
    return 0;
}

int CEload::SetPubOpt(int needPub)
{
    bNeedPub = (needPub>0) ? YES : NO;
    return 0;
}

void * CEload::OnRequest(void * pData, long len)
{
    pthread_mutex_lock(&m_lockOperate);
    if(bNeedPub)
        Pulish(pData,len);
    NSString * str = [NSString stringWithFormat:@"%s", pData];
    int err = WriteStringBytes([str UTF8String]);
    if(bNeedReply == NO)
        CReplier::SendStrig((err>=0)?"OK":"Fail");
    pthread_mutex_unlock(&m_lockOperate);
    return nullptr;
}

int CEload::Open(const char * dev, const char * opt)//opt:"9600,8,n,1"
{
    //int set_opt(int nSpeed, int nBits, char nEvent, int nStop);
    NSString * str = [NSString stringWithUTF8String:opt];
    NSLog(@"%@",str);
    NSArray * arr = [str componentsSeparatedByString:@","];
    int nSpeed = 9600;
    int nBits = 8;
    char nEvent = 'n';
    int nStop = 1;
    if([arr count]==4)
    {
        nSpeed = [[arr objectAtIndex:0]intValue];
        nBits = [[arr objectAtIndex:1]intValue];
        const char * tmp = [[arr objectAtIndex:2]UTF8String];
        nEvent = tmp[0];
        nStop = [[arr objectAtIndex:3]intValue];
    }
    int ret = CSerialPort::connect(dev);
    if (ret<0)
    {
        return ret;
    }
    ret = CSerialPort::set_opt(nSpeed, nBits, nEvent, nStop);
    return ret;
}

int CEload::WriteStringBytes(const char * szData)//"0xFF,0xFE,..."
{
    if(szData == NULL) return -1;
    if(strlen(szData)<=0) return -2;
    NSArray * arr = [[NSString stringWithUTF8String:szData] componentsSeparatedByString:@","];
    if([arr count]< 1) return -3;
    NSInteger size = [arr count];
    unsigned char * ucData = new unsigned char [size];
    for(NSInteger i=0; i<size; i++)
    {
        NSScanner * scanner = [NSScanner scannerWithString:[arr objectAtIndex:i]];
        unsigned int tmp;
        [scanner scanHexInt:&tmp];
        ucData[i] = tmp;
    }
    if(bNeedZmq && bNeedPub)
        Pulish((void*)ucData, size);
    CSerialPort::write((void*)ucData, size);
    delete [] ucData;
    return 0;
}

void CEload::ClearBuffer()
{
    pthread_mutex_lock(&m_lockOperate);
    [m_DataBuffer setLength:0];
    [m_strBuffer setString:@""];
    pthread_mutex_unlock(&m_lockOperate);
}

int CEload::Close()
{
    CPubliser::close();
    CReplier::close();
    CSerialPort::close();
    return 0;
}

int CEload::WriteBytes(unsigned char * ucData, int len)
{
    if(bNeedZmq && bNeedPub)
        Pulish((void*)ucData, len);
    return CSerialPort::write((void*)ucData, len);
}

int CEload::SetCCMode(float parNum,int timeout)
{
    //first switch to remote mode ...
    long current = parNum *10 ;
    Byte sendData[26] ;
    memset(sendData, 0x00, sizeof(sendData)) ;
    sendData[0] = 0xAA ; //always is 0xaa
    sendData[1] = 0x00 ; //address ,set to 0 .
    sendData[2] = 0x2A ; //0x2A Set CC mode curren
    sendData[3] |=current  ;
    sendData[4] |=(current>>8) ;
    sendData[5] |=(current>>16) ;
    sendData[6] |=(current>>24) ;
    //checksum
    Byte checkSUm = 0 ;
    for (int i=0; i<25; i++)
        checkSUm +=sendData[i] ;
    checkSUm %=256 ;
    sendData[25] = checkSUm ;
    //  send data

//    [m_PSerialPort writeBytes:sendData length:26 error:nil];

    ClearBuffer();
    WriteBytes(sendData, 26);

    NSMutableData *receData = [NSMutableData data] ;
    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970] ;
    double tm = (double)timeout/1000.0 ;
    while (1)
    {
//        NSData *dataTmp = [m_PSerialPort GetInBuffer] ;
        if (m_DataBuffer.length>=26)
            break ;

        NSTimeInterval now = [[NSDate date] timeIntervalSince1970] ;
        if ((now-startTime)>=tm)
            return -2 ;

        usleep(1000*50) ;
    }

    if (receData.length!=26)
        return FALSE ;

    const Byte *pdata = (const Byte*)m_DataBuffer.bytes ;
    if (pdata[2]!=0x12)
        return -3 ;
    if (pdata[3]!=0x80) //set fail
    {
        return -4 ;
    }

    return 0 ;
}

int CEload::SendCommand(int command,int iTimeout)
{
    //first switch to remote mode ...
    Byte sendData[26] ;
    memset(sendData, 0x00, sizeof(sendData)) ;
    sendData[0] = 0xAA ; //always is 0xaa
    sendData[1] = 0x00 ; //address ,set to 0 .
    switch (command) {
        case CMD_localModel:
        {
            sendData[2] = 0x20 ; //Set the DC Load to remote operation
            sendData[3] = 0x00 ;
        }
            break;
        case CMD_remoteModel:
        {
            sendData[2] = 0x20 ; //Set the DC Load to remote operation
            sendData[3] = 0x01 ;
        }
            break;
        case CMD_SetCCModel :
        {
            sendData[2] = 0x28 ; //Set Set CC, CV, CW, or CR mode
            sendData[3] = 0x00 ; //cc
        }
            break;
        case CMD_TurnLoad_OFF:
        {
            sendData[2] = 0x21 ; //Turn the load ON or OFF
            sendData[3] = 0x00 ; //off
        }
            break;
        case CMD_TurnLoad_ON:
        {
            sendData[2] = 0x21 ; //Turn the load ON or OFF
            sendData[3] = 0x01 ; //on
        }
            break;

        default:
            break;
    }

    //checksum
    Byte checkSUm = 0 ;
    for (int i=0; i<25; i++)
        checkSUm +=sendData[i] ;
    checkSUm %=256 ;
    sendData[25] = checkSUm ;

    //  send data
//    [m_PSerialPort writeBytes:sendData length:26 error:nil];

    ClearBuffer();

    WriteBytes(sendData, 26);

    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970] ;
    double tm = iTimeout/1000.0 ;
    while (1)
    {
        if (m_DataBuffer.length>=26)
            break ;

        NSTimeInterval now = [[NSDate date] timeIntervalSince1970] ;
        if ((now-startTime)>tm)
            return -1;

        usleep(1000*50) ;
    }

    if (m_DataBuffer.length!=26)
        return -2;

    const Byte *pdata = (const Byte*)m_DataBuffer.bytes ;
    if (pdata[2]!=0x12)
        return -3;

    if (pdata[3]!=0x80) //set fail
        return -4;

    return 0 ;
}

float CEload::ReadVoltage(int iTimeOut)
{
    //Prepare stream....
    Byte sendData[26] ;
    memset(sendData, 0x00, sizeof(sendData)) ;
    sendData[0] = 0xAA ; //always is 0xaa
    sendData[1] = 0x00 ; //address ,set to 0 .
    sendData[2] = 0x5F ; //0x5F Read input voltage, current, power and relative state
    //checksum
    Byte checkSUm = 0 ;
    for (int i=0; i<25; i++)
        checkSUm +=sendData[i] ;
    checkSUm %=256 ;
    sendData[25] = checkSUm ;

    //  send data
//    [m_PSerialPort writeBytes:sendData length:26 error:nil];
    ClearBuffer();

    WriteBytes(sendData, 26);

    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970] ;
    NSTimeInterval tm = iTimeOut/1000.0 ;
    while (1) {

        if (m_DataBuffer.length>=26)
            break ;

        NSTimeInterval now = [[NSDate date] timeIntervalSince1970] ;
        if ((now-startTime)>tm)
            return -1;

        usleep(1000*50) ;
    }

    if (m_DataBuffer.length!=26)
        return -2 ;

    const Byte *pdata = (const Byte*)m_DataBuffer.bytes ;
    if (pdata[2]!=0x5F)
        return -3 ;

    //get the voltage .
    float voltage = (pdata[6]<<24)|(pdata[5]<<16)|(pdata[4]<<8)|pdata[3];
    //float current = (pdata[10]<<24)|(pdata[9]<<16)|(pdata[8]<<8)|pdata[7];

    return voltage ;
    /*
     rtn.bFlag = 1 ;
     rtn.voltage = voltage      ;
     rtn.current = current/10.0 ;
     return rtn ;
     */
}

float CEload::ReadCurrent(int iTimeOut)
{
    //Prepare stream....
    Byte sendData[26] ;
    memset(sendData, 0x00, sizeof(sendData)) ;
    sendData[0] = 0xAA ; //always is 0xaa
    sendData[1] = 0x00 ; //address ,set to 0 .
    sendData[2] = 0x5F ; //0x5F Read input voltage, current, power and relative state
    //checksum
    Byte checkSUm = 0 ;
    for (int i=0; i<25; i++)
        checkSUm +=sendData[i] ;
    checkSUm %=256 ;
    sendData[25] = checkSUm ;

    //  send data
//    [m_PSerialPort writeBytes:sendData length:26 error:nil];

    ClearBuffer();

    WriteBytes(sendData, 26);

    NSTimeInterval startTime = [[NSDate date] timeIntervalSince1970] ;
    NSTimeInterval tm = iTimeOut/1000.0 ;
    while (1) {

        if (m_DataBuffer.length>=26)
            break ;

        NSTimeInterval now = [[NSDate date] timeIntervalSince1970] ;
        if ((now-startTime)>tm)
            return -1;

        usleep(1000*50) ;
    }

    if (m_DataBuffer.length!=26)
        return -2 ;

    const Byte *pdata = (const Byte*)m_DataBuffer.bytes ;
    if (pdata[2]!=0x5F)
        return -3 ;

    //get the voltage .
    //float voltage = (pdata[6]<<24)|(pdata[5]<<16)|(pdata[4]<<8)|pdata[3];
    float current = (pdata[10]<<24)|(pdata[9]<<16)|(pdata[8]<<8)|pdata[7];

    return current/10.0 ;

}

bool CEload::WriteHexString(char *szCMD) // 12,23ab,ed
{
    /*here will parse szCMD*/
    NSString *strTmp = [NSString stringWithFormat:@"%s",szCMD] ;
    NSArray *arrList = [strTmp componentsMatchedByRegex:@"[0-9a-fA-F]{2}"] ;
    if (arrList.count<=0)
        return TRUE ;

    Byte bList[arrList.count] ;
    for (int i=0; i<arrList.count; i++)
    {
        NSString *strTmp = [arrList objectAtIndex:i] ;
        unsigned int byte =0 ;
        sscanf([strTmp cStringUsingEncoding:NSUTF8StringEncoding], "%x",&byte) ;
        bList[i] = byte ;
    }

    bool rtn = WriteBytes(bList, arrList.count);

    if (rtn)
        NSLog(@"Send Hex String:%s",szCMD) ;

    return rtn ;
}

int CEload::SetEloadMode(int sendModeFlag, float value)//unit mA,mV
{
//sendModeFlag:1 read volt, 2 local, 3 remote, 4 CC, 5 CV, 6 CW, 7 CR, 8 OFF, 9 ON, 10 CC Current
    //.........................

    Byte sendData[26] ;
    memset(sendData, 0x00, sizeof(sendData)) ;
    sendData[0] = 0xAA ; //always is 0xaa
    sendData[1] = 0x00 ; //address ,set to 0 .
    long ccValue = value * 10 ;

    //NSLog(@"....SELECT :%d",cbItem.indexOfSelectedItem) ;
    switch (sendModeFlag)
    {
        case 1: //read voltage
            sendData[2] = 0x5F ; //0x5F Read input voltage, current, power and relative
            break;
        case 2: //local Model
            sendData[2] = 0x20 ; //Set the DC Load to remote operation
            sendData[3] = 0x00 ;
            break ;
        case 3: //remote model
            sendData[2] = 0x20 ; //Set the DC Load to remote operation
            sendData[3] = 0x01 ;
            break ;
        case 4: //CC model
            sendData[2] = 0x28 ; //Set Set CC, CV, CW, or CR mode
            sendData[3] = 0x00 ; //cc
            break ;
        case 5: //CV model
            sendData[2] = 0x28 ; //Set Set CC, CV, CW, or CR mode
            sendData[3] = 0x01 ; //cV
            break ;
        case 6: //CW model
            sendData[2] = 0x28 ; //Set Set CC, CV, CW, or CR mode
            sendData[3] = 0x02 ; //cW
            break ;
        case 7: //CR model
            sendData[2] = 0x28 ; //Set Set CC, CV, CW, or CR mode
            sendData[3] = 0x03 ; //cR
            break ;
        case 8: //Load off
            sendData[2] = 0x21 ; //Turn the load ON or OFF
            sendData[3] = 0x00 ; //off
            break ;
        case 9: //Load on
            sendData[2] = 0x21 ; //Turn the load ON or OFF
            sendData[3] = 0x01 ; //on
            break ;
        case 10: //CC MODE Current
            sendData[2] = 0x2A ; //Turn the load ON or OFF
            sendData[3] |= ccValue ;
            sendData[4] |= (ccValue>>8);
            sendData[5] |= (ccValue>>16);
            sendData[6] |= (ccValue>>24);
            break ;
        default:
            break;
    }
    //checksum
    Byte checkSUm = 0 ;
    for (int i=0; i<25; i++)
        checkSUm +=sendData[i] ;
        checkSUm %=256 ;
        sendData[25] = checkSUm ;

        NSMutableString *mutStr = [NSMutableString stringWithString:@""] ;
        for (int i=0; i<26; i++)
            [mutStr appendFormat:@"%02X ",sendData[i]] ;

    NSString *cmd = [NSString stringWithFormat:@"%@\n",mutStr] ;
    if(WriteHexString((char *)[cmd cStringUsingEncoding:NSUTF8StringEncoding]))
        return 0;
    return -1;

    //    sleep(3) ;
    //    ELoad->ReadHexString() ;
//    return ;
}


