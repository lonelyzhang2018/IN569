//
//  Interface.hpp
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//

#ifndef Interface_hpp
#define Interface_hpp

#include "lua.hpp"


#define DL_EXPORT __attribute__((visibility("default")))

#include <stdio.h>

extern "C" int luaopen_libRS232(lua_State * state);


#endif /* Interface_hpp */
