//
//  Interface.mm
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//
#import <Foundation/Foundation.h>
#include "Interface.h"
#include "tolua++.h"

TOLUA_API int  tolua_Eload_open (lua_State* tolua_S);

extern "C" int luaopen_libEload(lua_State * state)
{
    NSLog(@"Load Eload(SerialPort) Dylib\r\n");
    tolua_Eload_open(state);
    
    return 0;
}