//
//  CEload.h
//  RS232
//
//  Created by IvanGan on 16/4/9.
//  Copyright © 2016年 IvanGan. All rights reserved.
//

#ifndef CEload_h
#define CEload_h

#import <Foundation/Foundation.h>
#include <stdio.h>
#include "SerialPort.h"
#include <string>

#import <pthread.h>

#include "Publisher.hpp"
#include "Replier.hpp"

typedef enum
{
    CMD_localModel      = 0 ,
    CMD_remoteModel     = 1 ,
    CMD_SetCCModel      = 2 ,
    CMD_TurnLoad_ON     = 3 ,
    CMD_TurnLoad_OFF    = 4 ,
}ELOAD_CMD;


class CEload : CPubliser, CReplier, CSerialPort
{
public:
    CEload();
    ~CEload();
public:
    int CreateIPC(const char * reply, const char * publish);
    int Open(const char * dev, const char * opt);//opt:"9600,8,n,1"
    int Close();

    int WriteStringBytes(const char * szData);//"0xFF,0xFE,..."

    
    int SetRepOpt(int needReply, int timeout=3000);//set bNeedReplay
    int SetPubOpt(int needPub);//it will publish command which is from function writeXXX

    int WriteBytes(unsigned char * ucData, int len);
    void ClearBuffer();

    int SendCommand(int command,int iTimeout);
    int SetCCMode(float parNum,int timeout);
    float ReadVoltage(int iTimeOut);
    float ReadCurrent(int iTimeOut);


    int SetEloadMode(int sendModeFlag, float value=0.0);
    bool WriteHexString(char *szCMD);

protected:
    virtual void * OnRequest(void * pdata, long len);
    virtual void * didReceiveData(void * data, long len);

private:
    pthread_mutex_t m_mutex;
    pthread_mutex_t m_lockOperate;
    
    NSMutableString * m_strBuffer;
    NSMutableData * m_DataBuffer;
    NSMutableString * m_strDetect;
    NSMutableString * m_Return;
    
    bool bNeedZmq;  //YES: will pub data from COM
                    //this will initial in "CreatIPC".
    
    bool bNeedReply; // YES: will reply data from data, or it will return "OK" or "Fail"
    int iTimeout;//msec
    bool bNeedPub;
    
};

#endif /* CEload_hpp */
