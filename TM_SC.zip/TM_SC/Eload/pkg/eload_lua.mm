/*
** Lua binding: Eload
** Generated automatically by tolua++-1.0.92 on Fri Jul 29 11:45:51 2016.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_Eload_open (lua_State* tolua_S);

#include "CEload.h"

/* function to release collected object via destructor */
#ifdef __cplusplus

static int tolua_collect_CEload (lua_State* tolua_S)
{
 CEload* self = (CEload*) tolua_tousertype(tolua_S,1,0);
	Mtolua_delete(self);
	return 0;
}
#endif


/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
 tolua_usertype(tolua_S,"CEload");
}

/* method: new of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_new00
static int tolua_Eload_CEload_new00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CEload* tolua_ret = (CEload*)  Mtolua_new((CEload)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CEload");
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: new_local of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_new00_local
static int tolua_Eload_CEload_new00_local(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertable(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   CEload* tolua_ret = (CEload*)  Mtolua_new((CEload)());
    tolua_pushusertype(tolua_S,(void*)tolua_ret,"CEload");
    tolua_register_gc(tolua_S,lua_gettop(tolua_S));
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'new'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: delete of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_delete00
static int tolua_Eload_CEload_delete00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'delete'", NULL);
#endif
  Mtolua_delete(self);
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'delete'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: CreateIPC of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_CreateIPC00
static int tolua_Eload_CEload_CreateIPC00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  const char* reply = ((const char*)  tolua_tostring(tolua_S,2,0));
  const char* publish = ((const char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'CreateIPC'", NULL);
#endif
  {
   int tolua_ret = (int)  self->CreateIPC(reply,publish);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'CreateIPC'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Open of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_Open00
static int tolua_Eload_CEload_Open00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isstring(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  const char* dev = ((const char*)  tolua_tostring(tolua_S,2,0));
  const char* opt = ((const char*)  tolua_tostring(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Open'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Open(dev,opt);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Open'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: Close of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_Close00
static int tolua_Eload_CEload_Close00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'Close'", NULL);
#endif
  {
   int tolua_ret = (int)  self->Close();
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'Close'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteStringBytes of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_WriteStringBytes00
static int tolua_Eload_CEload_WriteStringBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  const char* szData = ((const char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteStringBytes'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteStringBytes(szData);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteStringBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetRepOpt of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_SetRepOpt00
static int tolua_Eload_CEload_SetRepOpt00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,1,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int needReply = ((int)  tolua_tonumber(tolua_S,2,0));
  int timeout = ((int)  tolua_tonumber(tolua_S,3,3000));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetRepOpt'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetRepOpt(needReply,timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetRepOpt'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetPubOpt of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_SetPubOpt00
static int tolua_Eload_CEload_SetPubOpt00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int needPub = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetPubOpt'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetPubOpt(needPub);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetPubOpt'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteBytes of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_WriteBytes00
static int tolua_Eload_CEload_WriteBytes00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  unsigned char* ucData = ((unsigned char*)  tolua_tostring(tolua_S,2,0));
  int len = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteBytes'", NULL);
#endif
  {
   int tolua_ret = (int)  self->WriteBytes(ucData,len);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteBytes'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ClearBuffer of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_ClearBuffer00
static int tolua_Eload_CEload_ClearBuffer00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,2,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ClearBuffer'", NULL);
#endif
  {
   self->ClearBuffer();
  }
 }
 return 0;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ClearBuffer'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SendCommand of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_SendCommand00
static int tolua_Eload_CEload_SendCommand00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int command = ((int)  tolua_tonumber(tolua_S,2,0));
  int iTimeout = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SendCommand'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SendCommand(command,iTimeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SendCommand'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetCCMode of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_SetCCMode00
static int tolua_Eload_CEload_SetCCMode00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  float parNum = ((float)  tolua_tonumber(tolua_S,2,0));
  int timeout = ((int)  tolua_tonumber(tolua_S,3,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetCCMode'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetCCMode(parNum,timeout);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetCCMode'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadVoltage of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_ReadVoltage00
static int tolua_Eload_CEload_ReadVoltage00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int iTimeOut = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadVoltage'", NULL);
#endif
  {
   float tolua_ret = (float)  self->ReadVoltage(iTimeOut);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadVoltage'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: ReadCurrent of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_ReadCurrent00
static int tolua_Eload_CEload_ReadCurrent00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int iTimeOut = ((int)  tolua_tonumber(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'ReadCurrent'", NULL);
#endif
  {
   float tolua_ret = (float)  self->ReadCurrent(iTimeOut);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'ReadCurrent'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: SetEloadMode of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_SetEloadMode00
static int tolua_Eload_CEload_SetEloadMode00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,1,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  int sendModeFlag = ((int)  tolua_tonumber(tolua_S,2,0));
  float value = ((float)  tolua_tonumber(tolua_S,3,0.0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'SetEloadMode'", NULL);
#endif
  {
   int tolua_ret = (int)  self->SetEloadMode(sendModeFlag,value);
   tolua_pushnumber(tolua_S,(lua_Number)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'SetEloadMode'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* method: WriteHexString of class  CEload */
#ifndef TOLUA_DISABLE_tolua_Eload_CEload_WriteHexString00
static int tolua_Eload_CEload_WriteHexString00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isusertype(tolua_S,1,"CEload",0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  CEload* self = (CEload*)  tolua_tousertype(tolua_S,1,0);
  char* szCMD = ((char*)  tolua_tostring(tolua_S,2,0));
#ifndef TOLUA_RELEASE
  if (!self) tolua_error(tolua_S,"invalid 'self' in function 'WriteHexString'", NULL);
#endif
  {
   bool tolua_ret = (bool)  self->WriteHexString(szCMD);
   tolua_pushboolean(tolua_S,(bool)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'WriteHexString'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_Eload_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  tolua_constant(tolua_S,"CMD_localModel",CMD_localModel);
  tolua_constant(tolua_S,"CMD_remoteModel",CMD_remoteModel);
  tolua_constant(tolua_S,"CMD_SetCCModel",CMD_SetCCModel);
  tolua_constant(tolua_S,"CMD_TurnLoad_ON",CMD_TurnLoad_ON);
  tolua_constant(tolua_S,"CMD_TurnLoad_OFF",CMD_TurnLoad_OFF);
  #ifdef __cplusplus
  tolua_cclass(tolua_S,"CEload","CEload","",tolua_collect_CEload);
  #else
  tolua_cclass(tolua_S,"CEload","CEload","",NULL);
  #endif
  tolua_beginmodule(tolua_S,"CEload");
   tolua_function(tolua_S,"new",tolua_Eload_CEload_new00);
   tolua_function(tolua_S,"new_local",tolua_Eload_CEload_new00_local);
   tolua_function(tolua_S,".call",tolua_Eload_CEload_new00_local);
   tolua_function(tolua_S,"delete",tolua_Eload_CEload_delete00);
   tolua_function(tolua_S,"CreateIPC",tolua_Eload_CEload_CreateIPC00);
   tolua_function(tolua_S,"Open",tolua_Eload_CEload_Open00);
   tolua_function(tolua_S,"Close",tolua_Eload_CEload_Close00);
   tolua_function(tolua_S,"WriteStringBytes",tolua_Eload_CEload_WriteStringBytes00);
   tolua_function(tolua_S,"SetRepOpt",tolua_Eload_CEload_SetRepOpt00);
   tolua_function(tolua_S,"SetPubOpt",tolua_Eload_CEload_SetPubOpt00);
   tolua_function(tolua_S,"WriteBytes",tolua_Eload_CEload_WriteBytes00);
   tolua_function(tolua_S,"ClearBuffer",tolua_Eload_CEload_ClearBuffer00);
   tolua_function(tolua_S,"SendCommand",tolua_Eload_CEload_SendCommand00);
   tolua_function(tolua_S,"SetCCMode",tolua_Eload_CEload_SetCCMode00);
   tolua_function(tolua_S,"ReadVoltage",tolua_Eload_CEload_ReadVoltage00);
   tolua_function(tolua_S,"ReadCurrent",tolua_Eload_CEload_ReadCurrent00);
   tolua_function(tolua_S,"SetEloadMode",tolua_Eload_CEload_SetEloadMode00);
   tolua_function(tolua_S,"WriteHexString",tolua_Eload_CEload_WriteHexString00);
  tolua_endmodule(tolua_S);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_Eload (lua_State* tolua_S) {
 return tolua_Eload_open(tolua_S);
};
#endif

