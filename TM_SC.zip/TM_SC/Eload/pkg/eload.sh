

tolua=/usr/local/lib/tolua++

$tolua -o eload_lua.mm Eload.pkg