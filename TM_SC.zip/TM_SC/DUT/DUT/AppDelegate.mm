//
//  AppDelegate.m
//  DUT
//
//  Created by Ryan on 11/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import "AppDelegate.h"
//#import "UnitViewController.h"
#import <MMTabBarView/UnitFakeModel.h>
#include "ConfigurationWndDelegate.h"
#include <stdlib.h>


//int funcsPort[] = {7970,6990,7000,6800,7300,7500};
int funcsPort[] = {7970,6990,7000,6800,7300,7500,0,0,0,0};

@interface AppDelegate ()

//@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    for (NSViewController * v in arrUnit)
    {
        [v release];
    }
    [arrUnit release];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender
{
    return YES;
}

#pragma mark ---- tab bar config ----
-(int)LoadDefine
{
    NSBundle * bundle = [NSBundle bundleForClass:[self class]];
    NSString * path = [bundle pathForResource:@"define" ofType:@"plist"];
    m_dicDefine = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    if (!m_dicDefine) {
        [m_dicDefine setValue:@"utils" forKey:kProjectName];
        [m_dicDefine setValue:@"4" forKey:kSoltsNumber];
        [m_dicDefine setValue:@"3" forKey:kFuncsNumber];
    }
    return 0;
}

-(void)awakeFromNib
{
    NSLog(@"ulimit -n 1024");
    system("/usr/bin/ulimit -n 1024");

    [[NSTask launchedTaskWithLaunchPath:@"/usr/bin/ulimit"
                              arguments:[NSArray arrayWithObjects:@"-n",@"1024", nil]]
     waitUntilExit];
    
    [self LoadDefine];
    [self LoadConfiguration];
    arrUnit = [NSMutableArray new];
    [tabBar setStyleNamed:@"Safari"];
    [tabBar setOnlyShowCloseOnHover:YES];
    [tabBar setCanCloseOnlyTab:YES];
    [tabBar setDisableTabClose:YES];
    [tabBar setAllowsBackgroundTabClosing:YES];
    [tabBar setHideForSingleTab:YES];
    [tabBar setShowAddTabButton:YES];
    [tabBar setSizeButtonsToFit:NO];
    
    [tabBar setTearOffStyle:MMTabBarTearOffAlphaWindow];
    [tabBar setUseOverflowMenu:YES];
    [tabBar setAutomaticallyAnimates:YES];
    [tabBar setAllowsScrubbing:YES];
    [tabBar setButtonOptimumWidth:200];

    [self CreateUnit:[[m_dicDefine valueForKey:kSoltsNumber] intValue]];
}

-(void)CreateUnit:(int)count
{
    for (int i=0; i<count; i++) {
        [self addNewTabWithTitle:[NSString stringWithFormat:@"UUT%d",i+1] withIndex:i];
    }
    
    m_Funcs = [((FunViewController *)[arrFuncView objectAtIndex:0]) FuncNum];
    
    [tabView selectFirstTabViewItem:nil];
}


- (void)addNewTabWithTitle:(NSString *)aTitle withIndex:(int)index
{
    FunViewController * funC = [[FunViewController alloc]initialwithID:index];
    [funC CreateFuncUnit];
    [funC SetUpUnit:m_dicConfiguration];
    [arrUnit addObject:funC];
    
    UnitFakeModel *newModel = [[UnitFakeModel alloc] init];
    [newModel setTitle:aTitle];
    NSTabViewItem *newItem = [[NSTabViewItem alloc] initWithIdentifier:newModel];
    [newItem setLabel:aTitle];
    [tabView addTabViewItem:newItem];
    [tabView selectTabViewItem:newItem];
  
    
    //Debug
    //[newItem setView:c.view];
    [newItem setView:funC.view];
    
    
//    [c.view setFrame:[view frame]];
    [newModel release];
    [newItem release];
    //[c release];
}

-(IBAction)btConfiguration:(id)sender
{
    [winMain beginSheet:winConfiguration completionHandler:^(NSModalResponse returnCode) {
        switch (returnCode) {
            case NSModalResponseOK:
                [self SaveConfiguration:m_dicConfiguration];
                for (int i=0;i<[arrUnit count];i++)
                {
                    [[arrUnit objectAtIndex:i] SetUpUnit:m_dicConfiguration];
                }
                break;
            case NSModalResponseCancel:
                break;
            default:
                break;
        }
    }];
}

-(IBAction)btRefresh:(id)sender
{
   FunViewController * c = [arrUnit objectAtIndex:[tabView indexOfTabViewItem:[tabView selectedTabViewItem]]];
    [c btRefresh];
}


-(void )LoadConfiguration
{
    //Load configuration in here
    if (m_dicConfiguration)
    {
        [m_dicConfiguration release];
    }
    m_dicConfiguration = [NSMutableDictionary new];
//    NSString * config_path = [NSString stringWithFormat:@"/Vault/%@_config/dut_config.plist",[m_dicDefine valueForKey:kProjectName]];
    NSString * p = [[[[NSBundle mainBundle]bundlePath]stringByDeletingLastPathComponent]stringByAppendingPathComponent:@"TM_config/DebugPanle"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:p])
        [[NSFileManager defaultManager]createDirectoryAtPath:p withIntermediateDirectories:YES attributes:NULL error:NULL];
    NSString * config_path = [NSString stringWithFormat:@"%@/dut_config.plist",p];
    
    if (m_dicConfiguration) {
        [m_dicConfiguration release];
    }
    m_dicConfiguration = [[NSMutableDictionary alloc] initWithContentsOfFile:config_path];
    
    if (!m_dicConfiguration)
    {
        m_dicConfiguration = [NSMutableDictionary new];
        int chn = [[m_dicDefine valueForKey:kSoltsNumber] intValue];
        int funs = [[m_dicDefine valueForKey:kFuncsNumber] intValue];
        for (int i=0;i<chn;i++)
        {
            for (int j=0;j<funs;j++)
            {
//                NSString * rep = [NSString stringWithFormat:@"tcp://0.0.0.0:%d",0];
//                NSString * sub = [NSString stringWithFormat:@"tcp://0.0.0.0:%d",0];
                
                NSString * rep = [NSString stringWithFormat:@"tcp://127.0.0.1:%d",funcsPort[2*j]+i ];
                NSString * sub = [NSString stringWithFormat:@"tcp://127.0.0.1:%d",funcsPort[2*j+1]+i ];
                [m_dicConfiguration setValue:rep forKey:[NSString stringWithFormat:@"%@%d%d",kRequest,j,i]];
                [m_dicConfiguration setValue:sub forKey:[NSString stringWithFormat:@"%@%d%d",kSubscribe,j,i]];
            }
        }
        
        [self SaveConfiguration:m_dicConfiguration];
    }
}

-(void)SaveConfiguration:(NSMutableDictionary *)dic
{

    NSString * p = [[[[NSBundle mainBundle]bundlePath]stringByDeletingLastPathComponent]stringByAppendingPathComponent:@"TM_config/DebugPanle"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:p])
        [[NSFileManager defaultManager]createDirectoryAtPath:p withIntermediateDirectories:YES attributes:NULL error:NULL];
    NSString * config_path = [NSString stringWithFormat:@"%@/dut_config.plist",p];
    
    NSError * err;
    if (![[NSFileManager defaultManager] createDirectoryAtPath:[config_path stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nullptr error:&err])
    {
        NSRunAlertPanel(@"Save Configuration", @"Create config path failed,with file path:%@ with error: %@", @"OK", nil, nil,config_path,[err description]);
    }
    if (![dic writeToFile:config_path atomically:YES])
    {
        NSRunAlertPanel(@"Save Configuration", @"Write configuration file failed,with file path:%@", @"OK", nil, nil,config_path);
    }
    
    NSLog(@"OK.SaveConfiguration");
}

- (void)windowWillBeginSheet:(NSNotification *)notification
{
    [(ConfigurationWndDelegate *)[winConfiguration delegate] InitCtrls:m_dicConfiguration withSolts: [[m_dicDefine valueForKey:kSoltsNumber] intValue] withFuncs:[[m_dicDefine valueForKey:kFuncsNumber] intValue]];
}
@end
