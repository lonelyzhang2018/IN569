//
//  AppDelegate.h
//  DUT
//
//  Created by Ryan on 11/2/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <MMTabBarView/MMTabBarView.h>
#import "FunViewController.h"



#define kProjectName        @"project_name"
#define kSoltsNumber         @"slots_number"
#define kFuncsNumber        @"funcs_number"

#define kRequest           @"Request"
#define kSubscribe        @"Subscribe"

@interface AppDelegate : NSObject <NSApplicationDelegate>{
    IBOutlet MMTabBarView           *tabBar;
    IBOutlet NSTabView              *tabView;
    NSMutableArray * arrUnit;
    
    IBOutlet NSWindow * winConfiguration;
    IBOutlet NSWindow * winMain;
    
    IBOutlet NSWindow *testWin;
    
    int m_Slots;
    int m_Funcs;
    
    NSMutableDictionary * m_dicDefine;
    NSMutableDictionary * m_dicConfiguration;
    NSMutableArray * arrFuncView;
}

-(void)SaveConfiguration:(NSMutableDictionary *)dic;

@end

