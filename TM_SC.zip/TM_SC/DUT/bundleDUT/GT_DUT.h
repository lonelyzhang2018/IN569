//
//  GT_DUT.h
//  DUT
//
//  Created by Ryan on 11/13/15.
//  Copyright © 2015 ___Intelligent Automation___. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "../../Common/UIExProtocol.h"

@interface GT_DUT : NSObject  <UIExProtocol, NSDrawerDelegate>

@end
