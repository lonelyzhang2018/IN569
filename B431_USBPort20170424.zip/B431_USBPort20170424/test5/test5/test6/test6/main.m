//
//  main.m
//  test6
//
//  Created by Mark on 4/15/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
