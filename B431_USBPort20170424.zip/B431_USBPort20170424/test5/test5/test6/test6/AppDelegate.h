//
//  AppDelegate.h
//  test6
//
//  Created by Mark on 4/15/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

