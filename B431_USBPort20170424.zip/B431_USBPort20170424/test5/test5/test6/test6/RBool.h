//
//  RBool.h
//  usbDeviceTree
//
//  Created by RyanGao on 4/15/17.
//
//

#import <AppKit/AppKit.h>

@interface RBool : NSObject
{
    BOOL	_isBool;
}

- (id)initWithBool:(BOOL)yn;
- (void)setBool:(BOOL)yn;
- (BOOL)isBool;

@end
