//
//  AppDelegate.m
//  test6
//
//  Created by Mark on 4/15/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#import "AppDelegate.h"
#import "RExplorer.h"

@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

-(void)awakeFromNib
{
    NSLog(@"-=-=");
      RExplorer *rrr=[[RExplorer alloc]init];
     [rrr initializeRegistryDictionaryWithPlane:kIOServicePlane];
    
    [rrr release];
}

@end
