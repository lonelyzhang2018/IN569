//
//  RBool.m
//  usbDeviceTree
//
//  Created by RyanGao on 4/15/17.
//
//




#import "RBool.h"

@implementation RBool

- (id)initWithBool:(BOOL)yn
{
    _isBool = yn;
    return [super init];
}

- (void)setBool:(BOOL)yn
{
    _isBool = yn;
}

- (BOOL)isBool
{
    return _isBool;
}

- (NSString *)description
{
    return (_isBool?NSLocalizedString(@"Yes", @""):NSLocalizedString(@"No", @""));
}

@end
