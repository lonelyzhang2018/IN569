//
//  main.c
//  test5
//
//  Created by Mark on 4/15/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <paths.h>
#include <termios.h>
#include <sysexits.h>
#include <sys/param.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/serial/IOSerialKeys.h>
#include <IOKit/serial/ioss.h>
#include <IOKit/IOBSD.h>


// Function prototypes
static kern_return_t findModems(io_iterator_t *matchingServices);
static kern_return_t getModemPath(io_iterator_t serialPortIterator, char *bsdPath, CFIndex maxPathSize);

// Returns an iterator across all known modems. Caller is responsible for
// releasing the iterator when iteration is complete.
static kern_return_t findModems(io_iterator_t *matchingServices)
{
    kern_return_t           kernResult;
    CFMutableDictionaryRef  classesToMatch;
    
    // Serial devices are instances of class IOSerialBSDClient.
    // Create a matching dictionary to find those instances.
    classesToMatch = IOServiceMatching(kIOSerialBSDServiceValue);
    if (classesToMatch == NULL) {
        printf("IOServiceMatching returned a NULL dictionary.\n");
    }
    else {
        // Look for devices that claim to be modems.
        CFDictionarySetValue(classesToMatch,
                             CFSTR(kIOSerialBSDTypeKey),
                             CFSTR(kIOSerialBSDAllTypes));
    }
    
    // Get an iterator across all matching devices.
    kernResult = IOServiceGetMatchingServices(kIOMasterPortDefault, classesToMatch, matchingServices);
    if (KERN_SUCCESS != kernResult) {
        printf("IOServiceGetMatchingServices returned %d\n", kernResult);
        goto exit;
    }
    
exit:
    return kernResult;
}

static kern_return_t getModemPath(io_iterator_t serialPortIterator, char *bsdPath, CFIndex maxPathSize)
{
    io_object_t     modemService;
    kern_return_t   kernResult = KERN_FAILURE;
    Boolean         modemFound = false;
    
    // Initialize the returned path
    *bsdPath = '\0';
    
    // Iterate across all modems found. In this example, we bail after finding the first modem.
    
    while ((modemService = IOIteratorNext(serialPortIterator))) {
        CFTypeRef   bsdPathAsCFString;
        
        bsdPathAsCFString = IORegistryEntryCreateCFProperty(modemService,
                                                            CFSTR(kIOCalloutDeviceKey),
                                                            kCFAllocatorDefault,
                                                            0);
        if (bsdPathAsCFString) {
            Boolean result;
            result = CFStringGetCString(bsdPathAsCFString,
                                        bsdPath,
                                        maxPathSize,
                                        kCFStringEncodingUTF8);
            CFRelease(bsdPathAsCFString);
            
            if (result) {
                printf("Modem found with BSD path: %s", bsdPath);
                modemFound = true;
                kernResult = KERN_SUCCESS;
            }
        }
        
        printf("\n");
        
        // Release the io_service_t now that we are done with it.
        (void) IOObjectRelease(modemService);
    }
    
    return kernResult;
}

int main(int argc, const char * argv[])
{
//    kern_return_t   kernResult;
//    io_iterator_t   serialPortIterator;
//    char            bsdPath[MAXPATHLEN];
//    
//    kernResult = findModems(&serialPortIterator);
//    if (KERN_SUCCESS != kernResult) {
//        printf("No modems were found.\n");
//    }
//    
//    kernResult = getModemPath(serialPortIterator, bsdPath, sizeof(bsdPath));
//    if (KERN_SUCCESS != kernResult) {
//        printf("Could not get path for modem.\n");
//    }
//    
//    IOObjectRelease(serialPortIterator);
    
    
    
    
    kern_return_t		kr;
    IONotificationPortRef	notifyPort;
    io_object_t			notification;
    mach_port_t gMasterPort;
    mach_port_t		port;
    io_registry_entry_t rootEntry;
   
    
    // Obtain the I/O Kit communication handle.
    assert( KERN_SUCCESS == (
                             kr = IOMasterPort(bootstrap_port, &gMasterPort)
                             ));
    
    notifyPort = IONotificationPortCreate( gMasterPort );
    port = IONotificationPortGetMachPort( notifyPort );
    assert( KERN_SUCCESS == (
                             kr = IOServiceAddInterestNotification( notifyPort,
                                                                   IORegistryEntryFromPath( gMasterPort, kIOServicePlane ":/"),
                                                                   kIOBusyInterest, 0, 0, &notification )
                             ));
    
     rootEntry = IORegistryGetRootEntry(gMasterPort);
    
    
    
    return EX_OK;
}