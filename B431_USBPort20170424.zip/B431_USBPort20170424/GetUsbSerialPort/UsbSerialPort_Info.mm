//
//  UsbSerialPort_Info.m
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#import "UsbSerialPort_Info.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <paths.h>
#include <termios.h>
#include <sysexits.h>
#include <sys/param.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/serial/IOSerialKeys.h>
#include <IOKit/serial/ioss.h>
#include <IOKit/IOBSD.h>

#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOMessage.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <Foundation/Foundation.h>

#import "RegexKitLite.h"

#define kMyVendorID         0x0403  //no use
#define kMyProductID        0x6001  //no use

static NSMutableString * usbMsg =nil;

typedef struct MyPrivateData {
    io_object_t             notification;
    IOUSBDeviceInterface    **deviceInterface;
    CFStringRef             deviceName;
    UInt32                  locationID;
} MyPrivateData;

static IONotificationPortRef    gNotifyPort;
static io_iterator_t            gAddedIter;
static CFRunLoopRef             gRunLoop;

void stringWriteToFile(NSString *filePath,NSString *s){
   // NSString *path = @"/vault/Intelli_log/log1.txt";
    [s writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    
    //    NSString *str = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    //    NSLog(@"\nstring = %@",str);
    //
    //    NSString *testtxt = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    //    NSLog(@"\ntest.text = %@",testtxt);
}

NSString * stringByReversed(NSString *strSource)
{
    NSMutableString *s = [NSMutableString string];
    for (NSUInteger i=strSource.length; i>0; i--) {
        [s appendString:[strSource substringWithRange:NSMakeRange(i-1, 1)]];
    }
    return s;
}

NSString *subStringFrom(NSString * str,NSString * startString,NSString *endString)
{
    
    NSRange startRange = [str rangeOfString:startString];
    NSRange endRange = [str rangeOfString:endString];
    NSRange range = NSMakeRange(startRange.location + startRange.length, endRange.location - startRange.location - startRange.length);
    return [str substringWithRange:range];
    
}

NSString * returnGetTaskResult(NSString *cmd,NSString * filePath)
{
    NSArray *cmds=[cmd componentsSeparatedByString:@" "];
    NSMutableArray *arrayCmds=[NSMutableArray arrayWithArray:cmds];
    if ([arrayCmds count]<2) {
        return nil;
    }
    NSString *cmd1=arrayCmds[0];
    [arrayCmds removeObjectAtIndex:0];
    NSArray *cmdsArray2=[NSArray arrayWithArray:arrayCmds];
    
    NSTask *task=[[NSTask alloc]init];
    [task setLaunchPath:cmd1];
    [task setArguments:cmdsArray2];
    NSPipe *pipe=[NSPipe pipe];
    [task setStandardOutput:pipe];
    [task launch];
    //[task waitUntilExit];
    [task release];
    
    NSFileHandle *file=[pipe fileHandleForReading];
    NSData *data= [file readDataToEndOfFile];
    NSString *strData=[[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]autorelease];
    if (filePath)
    {
        [strData writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    return strData;
}

/*
 
 void test2(){
 NSString *path = @"/Users/gx/Desktop/test_utf8.txt";
 //NSString *str = [NSString stringWithContentsOfFile:path];
 //UTF-8编码
 NSString *str = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
 NSLog(@"%@",str);
 
 //GBK编码
 NSString *path2 = @"/Users/gx/Desktop/test_gbk.txt";
 NSString *str2 = [NSString stringWithContentsOfFile:path2 encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000) error:nil];
 NSLog(@"%@",str2);
 
 //使用NSURL从文件中读取字符串
 NSURL *url = [NSURL URLWithString:@"file:///Users/gx/Desktop/test_utf8.txt"];
 NSString *str3 = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
 NSLog(@"%@",str3);
 
 //使用NSURL读取远程文本
 NSURL *url2 = [NSURL URLWithString:@"http://www.baidu.com"];
 NSString *str4 = [NSString stringWithContentsOfURL:url2 encoding:NSUTF8StringEncoding error:nil];
 NSLog(@"%@",str4);
 }
 
 */

void DeviceNotification(void *refCon, io_service_t service, natural_t messageType, void *messageArgument)
{
    kern_return_t   kr;
    MyPrivateData   *privateDataRef = (MyPrivateData *) refCon;
    
    if (messageType == kIOMessageServiceIsTerminated) {
        fprintf(stderr, "Device removed.\n");
        
        // Dump our private data to stderr just to see what it looks like.
        fprintf(stderr, "privateDataRef->deviceName: ");
        CFShow(privateDataRef->deviceName);
        fprintf(stderr, "privateDataRef->locationID: 0x%x.\n\n", privateDataRef->locationID);
        
        // Free the data we're no longer using now that the device is going away
        CFRelease(privateDataRef->deviceName);
        
        if (privateDataRef->deviceInterface) {
            kr = (*privateDataRef->deviceInterface)->Release(privateDataRef->deviceInterface);
        }
        
        kr = IOObjectRelease(privateDataRef->notification);
        
        free(privateDataRef);
    }
}

char * MYCFStringCopyUTF8String(CFStringRef aString) {
    if (aString == NULL) {
        return NULL;
    }
    
    CFIndex length = CFStringGetLength(aString);
    CFIndex maxSize =
    CFStringGetMaximumSizeForEncoding(length, kCFStringEncodingUTF8) + 1;
    char *buffer = (char *)malloc(maxSize);
    if (CFStringGetCString(aString, buffer, maxSize,
                           kCFStringEncodingUTF8)) {
        return buffer;
    }
    free(buffer); // If we failed
    return NULL;
}

void DeviceAdded(void *refCon, io_iterator_t iterator)
{
    /////////////
//    CFMutableDictionaryRef  classesToMatch2;
//     kern_return_t           kernResult2;
//    io_iterator_t   serialPortIterator;
//    classesToMatch2 = IOServiceMatching(kIOSerialBSDServiceValue);
//    if (classesToMatch2 == NULL) {
//        printf("IOServiceMatching returned a NULL dictionary.\n");
//    }
//    else {
//        // Look for devices that claim to be modems.
//        CFDictionarySetValue(classesToMatch2,
//                             CFSTR(kIOSerialBSDTypeKey),
//                             CFSTR(kIOSerialBSDAllTypes));
//    }
//    
//    kernResult2 = IOServiceGetMatchingServices(kIOMasterPortDefault, classesToMatch2, &serialPortIterator);
//    
    ////////////
    NSString *patternBsdName =[[NSString alloc]init];
    patternBsdName=@"\"IOCalloutDevice\"\\s*=\\s*\"(.*)\"";
    //NSString *patternBsdName=@"\"IOCalloutDevice\"\\s*=\\s*\"(/dev/cu.usbmodem\\w+)\"";
    kern_return_t       kr;
    io_service_t        usbDevice;
    IOCFPlugInInterface **plugInInterface = NULL;
    SInt32              score;
    HRESULT             res;
    int i_index=0;
    while ((usbDevice = IOIteratorNext(iterator))) {
        i_index++;
        io_name_t       deviceName;
        CFStringRef     deviceNameAsCFString;
//      CFStringRef     bsdName=NULL;
        NSString        *bsdName=NULL;
        MyPrivateData   *privateDataRef = NULL;
        UInt32          locationID;
       // printf("Device added.\n");
        
        // Add some app-specific information about this device.
        // Create a buffer to hold the data.
        privateDataRef = malloc(sizeof(MyPrivateData));
        bzero(privateDataRef, sizeof(MyPrivateData));
        
        // Get the USB device's name.
        kr = IORegistryEntryGetName(usbDevice, deviceName);
        if (KERN_SUCCESS != kr) {
            deviceName[0] = '\0';
        }
        
        deviceNameAsCFString = CFStringCreateWithCString(kCFAllocatorDefault, deviceName,
                                                         kCFStringEncodingASCII);
        
        // Dump our data to stderr just to see what it looks like.
        //fprintf(stderr, "deviceName: ");
       // CFShow(deviceNameAsCFString);
//        strcat(usbMsg, MYCFStringCopyUTF8String(deviceNameAsCFString));

        // Save the device's name to our private data.
        privateDataRef->deviceName = deviceNameAsCFString;
        
        // Now, get the locationID of this device. In order to do this, we need to create an IOUSBDeviceInterface
        // for our device. This will create the necessary connections between our userland application and the
        // kernel object for the USB Device.
        kr = IOCreatePlugInInterfaceForService(usbDevice, kIOUSBDeviceUserClientTypeID, kIOCFPlugInInterfaceID,
                                               &plugInInterface, &score);
        
        if ((kIOReturnSuccess != kr) || !plugInInterface) {
            fprintf(stderr, "IOCreatePlugInInterfaceForService returned 0x%08x.\n", kr);
            continue;
        }
        
        // Use the plugin interface to retrieve the device interface.
        res = (*plugInInterface)->QueryInterface(plugInInterface, CFUUIDGetUUIDBytes(kIOUSBDeviceInterfaceID),
                                                 (LPVOID*) &privateDataRef->deviceInterface);
        
        // Now done with the plugin interface.
        (*plugInInterface)->Release(plugInInterface);
        
        if (res || privateDataRef->deviceInterface == NULL) {
            fprintf(stderr, "QueryInterface returned %d.\n", (int) res);
            continue;
        }
        
        kr = (*privateDataRef->deviceInterface)->GetLocationID(privateDataRef->deviceInterface, &locationID);
        if (KERN_SUCCESS != kr) {
            fprintf(stderr, "GetLocationID returned 0x%08x.\n", kr);
            continue;
        }
        else {
            //fprintf(stderr, "Location ID: 0x%x\n\n", locationID);
        }
        privateDataRef->locationID = locationID;
        [usbMsg appendString:[NSString stringWithFormat:@"0x%x",locationID]];
        [usbMsg appendString:@" "];
        /*bsdName = ( CFStringRef ) IORegistryEntrySearchCFProperty (usbDevice,
                                                                       kIOServicePlane,
                                                                       //                                                            CFSTR(kIOBSDNameKey),
                                                                       CFSTR(kIOCalloutDeviceKey),
                                                                       //                                                                                                                                      CFSTR(kIODialinDeviceKey),
                                                                       kCFAllocatorDefault,
                                                                       kIORegistryIterateRecursively
                                                                       );*/

        //[usbMsg appendString:[NSString stringWithFormat:@"%@",bsdName]];
        NSString *filePath=[NSString stringWithFormat:@"/vault/Intelli_log/system_serialPort_0x%x.txt",locationID];
        //NSString * getMacDeviceInfo=returnGetTaskResult(@"/usr/sbin/ioreg -lxw550");
        const char *system_cmd=[[NSString stringWithFormat:@"/usr/sbin/ioreg -c IOSerialBSDClient > %@",filePath]UTF8String];
        system(system_cmd);
        //NSString *getMacDeviceInfo =returnGetTaskResult(@"/usr/sbin/ioreg -c IOSerialBSDClient",filePath);
        //[NSThread sleepForTimeInterval:0.35];
        //stringWriteToFile(filePath,getMacDeviceInfo);
        NSString * getMacDeviceInfo = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
        if (getMacDeviceInfo==NULL)
        {
             getMacDeviceInfo = [NSString stringWithContentsOfFile:filePath encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000) error:nil];
        }
         NSString *patternLocationID=[NSString stringWithFormat:@"B431 serial interface@%x([\\s\\S]*?)\"IODialinDevice\"",locationID];
        
        //NSString *patternLocationID=[NSString stringWithFormat:@"\"locationID\"\\s*=\\s*0x%x([\\s\\S]*?)\"IODialinDevice\"\\s*=\\s*\"/dev/tty.usbmodem",locationID];
        NSString *strBsdArray = [getMacDeviceInfo stringByMatching:patternLocationID capture:1L];
        //NSLog(@"->:%@",strBsdArray);
        if ([strBsdArray length]<5000)
        {
            bsdName =[strBsdArray stringByMatching:patternBsdName capture:1L];
            if (bsdName)
            {
                [usbMsg appendString:bsdName];
            }
            else
            {
                [usbMsg appendString:@"nil"];
            }
        }
        else
        {
             [usbMsg appendString:@"nil"];
        }
        [usbMsg appendString:@";"];
        //NSLog(@"-->:%@",usbMsg);
        // Register for an interest notification of this device being removed. Use a reference to our
        // private data as the refCon which will be passed to the notification callback.
        kr = IOServiceAddInterestNotification(gNotifyPort,                      // notifyPort
                                              usbDevice,                        // service
                                              kIOGeneralInterest,               // interestType
                                              DeviceNotification,               // callback
                                              privateDataRef,                   // refCon
                                              &(privateDataRef->notification)   // notification
                                              );
        
        if (KERN_SUCCESS != kr) {
            printf("IOServiceAddInterestNotification returned 0x%08x.\n", kr);
        }
        
        // Done with this USB device; release the reference added by IOIteratorNext
        kr = IOObjectRelease(usbDevice);
    }
}

void SignalHandler(int sigraised)
{
    fprintf(stderr, "\nInterrupted.\n");
    
    exit(0);
}



NSString * UsbSerialPortMain(int vid, int pid)
{
    if (usbMsg==nil) {
        usbMsg=[[NSMutableString alloc] init];
    }
    else
    {
        [usbMsg setString:@""];
    }
    CFMutableDictionaryRef  matchingDict;
    CFRunLoopSourceRef      runLoopSource;
    CFNumberRef             numberRef;
    kern_return_t           kr;
    int                     usbVendor = vid;
    int                     usbProduct = pid;
    sig_t                   oldHandler;
    
    // Set up a signal handler so we can clean up when we're interrupted from the command line
    // Otherwise we stay in our run loop forever.
    oldHandler = signal(SIGINT, SignalHandler);
    if (oldHandler == SIG_ERR) {
        fprintf(stderr, "Could not establish new signal handler.");
    }
    
    fprintf(stderr, "Looking for devices matching vendor ID=%d and product ID=%d.\n", usbVendor, usbProduct);
    
    matchingDict = IOServiceMatching(kIOUSBDeviceClassName);    // Interested in instances of class
    // IOUSBDevice and its subclasses
    if (matchingDict == NULL) {
        fprintf(stderr, "IOServiceMatching returned NULL.\n");
        return @"IOServiceMatching returned NULL";
    }
    
    // We are interested in all USB devices (as opposed to USB interfaces).  The Common Class Specification
    // tells us that we need to specify the idVendor, idProduct, and bcdDevice fields, or, if we're not interested
    // in particular bcdDevices, just the idVendor and idProduct.  Note that if we were trying to match an
    // IOUSBInterface, we would need to set more values in the matching dictionary (e.g. idVendor, idProduct,
    // bInterfaceNumber and bConfigurationValue.
    
    // Create a CFNumber for the idVendor and set the value in the dictionary
    numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &usbVendor);
    CFDictionarySetValue(matchingDict,
                         CFSTR(kUSBVendorID),
                         numberRef);
    CFRelease(numberRef);
    
    // Create a CFNumber for the idProduct and set the value in the dictionary
    numberRef = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &usbProduct);
    CFDictionarySetValue(matchingDict,
                         CFSTR(kUSBProductID),
                         numberRef);
    CFRelease(numberRef);
    numberRef = NULL;
    
    // Create a notification port and add its run loop event source to our run loop
    // This is how async notifications get set up.
    
    gNotifyPort = IONotificationPortCreate(kIOMasterPortDefault);
    runLoopSource = IONotificationPortGetRunLoopSource(gNotifyPort);
    
    gRunLoop = CFRunLoopGetCurrent();
    CFRunLoopAddSource(gRunLoop, runLoopSource, kCFRunLoopDefaultMode);
    
    // Now set up a notification to be called when a device is first matched by I/O Kit.
    kr = IOServiceAddMatchingNotification(gNotifyPort,                  // notifyPort
                                          kIOFirstMatchNotification,    // notificationType
                                          matchingDict,                 // matching
                                          DeviceAdded,                  // callback
                                          NULL,                         // refCon
                                          &gAddedIter                   // notification
                                          );
    
    // Iterate once to get already-present devices and arm the notification
    DeviceAdded(NULL, gAddedIter);
    
//    CFShow(MyPrivateData);
    // Start the run loop. Now we'll receive notifications.
    //fprintf(stderr, "Starting run loop.\n\n");
    //    CFRunLoopRun();
    
    // We should never get here
    //fprintf(stderr, "Unexpectedly back from CFRunLoopRun()!\n");
    
    

    return usbMsg;
}

NSString *GetSerialPortFromGlobalparameters()
{
    return usbMsg;
}



//@implementation UsbSerialPort_Info
//
//-(void)IntialUsbSerialPort{
//    
//}
//
//-(NSString *)GetDicContent:(NSString *) key{
//    
//    
//    
//    return @"";
//}
//
//-(id)init
//{
//    self = [super init];
//    if (self)
//    {
//        dic = [[NSMutableDictionary alloc]init];
//    }
//    return self;
//}
//
//-(void)dealloc
//{
//    if (dic) {
//        [dic removeAllObjects];
//        [dic release];
//    }
//    [super dealloc];
//}
//
//@end
