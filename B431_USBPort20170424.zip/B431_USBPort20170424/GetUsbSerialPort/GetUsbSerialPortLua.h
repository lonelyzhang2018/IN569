//
//  usbInfoLua.hpp
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#ifndef usbInfoLua_hpp
#define usbInfoLua_hpp

#include "lua.hpp"

#define DL_EXPORT __attribute__((visibility("default")))

#include <stdio.h>

extern "C" int luaopen_libGetUsbSerialPort(lua_State * state);


#endif /* usbInfoLua_hpp */
