//
//  main.m
//  Test2
//
//  Created by Mark on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        NSString *rst=@"0x14140000 /dev/cu.usbserial-imu_u262;0x14130000 /dev/cu.usbserial-imuXX";
        
        int socket_index=1;
        NSArray *arrayMsg=[rst componentsSeparatedByString:@";"];
        for (int i=0; i<[arrayMsg count]; i++)
        {
            
//            if ([arrayMsg[i] containsString:strLocationId]) {
//                NSArray *usbPort=[arrayMsg[i] componentsSeparatedByString:@" "];
//                return [usbPort[1] UTF8String];
//            }
            NSArray *usbPort=[arrayMsg[i] componentsSeparatedByString:@" "];
            if ([usbPort count]>1)
            {
                
            }
            
        }
        
        NSString *yy=@"0x14140000";
        NSArray *hh=[yy componentsSeparatedByString:@"00"];
        NSLog(@"===%@",hh);
        
       NSLog(@"-=-=-%@", [hh[0] substringFromIndex:[hh[0] length]-1]);
       NSLog(@"====%@",[hh[0] substringWithRange:NSMakeRange([hh[0] length]-2,2)]);
        
        
        
//    int usbLocation=0x4532;
//    NSString *strLocationId=[NSString stringWithFormat:@"0x%x",usbLocation];
//    NSLog(@"===%@",strLocationId);
    }
    return 0;
}
