//
//  Get_UsbSerialPort.cpp
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#include "Get_UsbSerialPort.h"
#include "UsbSerialPort_Info.h"


//=====================================================================================

//UsbSerialPort_Interface *usbInfo=NULL;
const char * getUsbSerialPortVersion()
{
    return "20170424_v0.8";
}

const char * getUsbSerialPortInfo(int pid,int vid,int channelIndex)
{
    NSString *rst=UsbSerialPortMain(pid,vid);
    NSArray *arrayMsg=[rst componentsSeparatedByString:@";"];
    for (int i=0; i<[arrayMsg count]; i++) {
        
        NSArray *usbPort=[arrayMsg[i] componentsSeparatedByString:@" "];
        if ([usbPort count]>1) {
            NSArray *usbPortSub=[usbPort[0] componentsSeparatedByString:@"00"];
            if ([usbPortSub count]>0) {
                NSString *usbPortSubsub=[usbPortSub[0] substringFromIndex:[usbPortSub[0] length]-1];
                if ([usbPortSubsub intValue]==(4-channelIndex))
                {
                    return [usbPort[1] UTF8String];
                }

            }
        }
    }
    return "nil" ;
}


 const char * getUsbSerialPortLocation(int pid,int vid,int channelIndex)
{
    NSString *rst=UsbSerialPortMain(pid,vid);
    NSArray *arrayMsg=[rst componentsSeparatedByString:@";"];
    for (int i=0; i<[arrayMsg count]; i++) {
        
        NSArray *usbPort=[arrayMsg[i] componentsSeparatedByString:@" "];
        if ([usbPort count]>1) {
            NSArray *usbPortSub=[usbPort[0] componentsSeparatedByString:@"00"];
            if ([usbPortSub count]>0) {
                NSString *usbPortSubsub=[usbPortSub[0] substringFromIndex:[usbPortSub[0] length]-1];
                if ([usbPortSubsub intValue]==(4-channelIndex))
                {
                    return [usbPort[0] UTF8String];
                }
                
            }
        }
    }
    return "nil" ;
    
}


const char * getUsbSerialPortInfoAll(int pid,int vid)
{
    NSString *rst=GetSerialPortFromGlobalparameters();
    return [rst UTF8String];
}

const char * execute_B431SuperBinary(const char *cmd,const char * filePath)
{
    NSArray *cmds=[[NSString stringWithUTF8String:cmd] componentsSeparatedByString:@" "];
    NSMutableArray *arrayCmds=[NSMutableArray arrayWithArray:cmds];
    
    if ([arrayCmds count]<2) {
        return nil;
    }
    
    NSString *cmd1=arrayCmds[0];
    [arrayCmds removeObjectAtIndex:0];
    NSArray *cmdsArray2=[NSArray arrayWithArray:arrayCmds];
    
    NSTask *task=[[NSTask alloc]init];
    [task setLaunchPath:cmd1];
    [task setArguments:cmdsArray2];
    NSPipe *pipe=[NSPipe pipe];
    [task setStandardOutput:pipe];
    [task launch];
    [task waitUntilExit];
    [task release];
    
    NSFileHandle *file=[pipe fileHandleForReading];
    NSData *data= [file readDataToEndOfFile];
    NSString *strData=[[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]autorelease];
    
    if (filePath)
    {
        [strData writeToFile:[NSString stringWithUTF8String:filePath] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    
    return [strData UTF8String];
}
