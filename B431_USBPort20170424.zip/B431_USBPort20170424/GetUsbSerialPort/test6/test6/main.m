//
//  main.m
//  test6
//
//  Created by Mark on 4/20/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RegexKitLite.h"

NSString * stringByReversed(NSString *strSource)
{
    NSMutableString *s = [NSMutableString string];
    for (NSUInteger i=strSource.length; i>0; i--) {
        [s appendString:[strSource substringWithRange:NSMakeRange(i-1, 1)]];
    }
    return s;
}


NSString * returnGetTaskResult(NSString *cmd,NSString * filePath)
{
    NSArray *cmds=[cmd componentsSeparatedByString:@" "];
    NSMutableArray *arrayCmds=[NSMutableArray arrayWithArray:cmds];
    if ([arrayCmds count]<2) {
        return nil;
    }
    NSString *cmd1=arrayCmds[0];
    [arrayCmds removeObjectAtIndex:0];
    NSArray *cmdsArray2=[NSArray arrayWithArray:arrayCmds];
    
    NSTask *task=[[NSTask alloc]init];
    [task setLaunchPath:cmd1];
    [task setArguments:cmdsArray2];
    NSPipe *pipe=[NSPipe pipe];
    [task setStandardOutput:pipe];
    [task launch];
    //[task waitUntilExit];
    [task release];
    
    NSFileHandle *file=[pipe fileHandleForReading];
    NSData *data= [file readDataToEndOfFile];
    NSString *strData=[[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]autorelease];
    if (filePath)
    {
        [strData writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    return strData;
}

//Execute
//Run a application in background
//int Execute(const char * szcmd,int waituntilreturn,int itimeout)
static int Execute_withTask(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
    //   return system(szcmd);
    if (!szcmd) return -1;
    NSArray * arg;
    NSArray * arguments;
    NSString * strRex = @"[^\"\\s]*\"([^\"]*)\"[^\\s]*|(>?[^\"\\s]*)";
    
    NSString * str =[NSString stringWithUTF8String:szcmd];
    NSArray * arrArguments=[str arrayOfCaptureComponentsMatchedByRegex:strRex];
    NSMutableArray * argus = [NSMutableArray array];
    for (NSArray * o in arrArguments)
    {
        if (![[o objectAtIndex:1] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:1]];
        }
        if (![[o objectAtIndex:2] isEqualToString:@""])
        {
            [argus addObject:[o objectAtIndex:2]];
        }
    }
    //NSLog(@"arguments : %@",[argus description]);
    arguments=nil;
    if ([argus count]>1)
    {
        arguments = [argus subarrayWithRange:NSMakeRange(1, [argus count]-1)];
    }
    else {
        arguments = [NSArray array];
    }
    arg = argus;
    
    NSLog(@"Excuteable : %@",[[arg objectAtIndex:0] description]);
    NSLog(@"arguments : %@",[arguments description]);
    
    NSTask * task = [[NSTask alloc] init];
    if (poutput)
    {
        NSString * str = [NSString stringWithUTF8String:poutput];
        str = [str stringByResolvingSymlinksInPath];
        [[NSFileManager defaultManager] createFileAtPath:str contents:nil attributes:nil];
        id handle =[NSFileHandle fileHandleForWritingAtPath:str];
        [task setStandardOutput:handle];
        [task setStandardError:handle];
    }
    
    [task setLaunchPath:[arg objectAtIndex:0]];
    
    [task setArguments:arguments];
    
    [task launch];
    
    if (waituntilreturn)
    {
        NSLog(@"Executing... %s",szcmd);
        NSTimeInterval start = [[NSDate date] timeIntervalSince1970];
        while (1) {
            NSTimeInterval now =[[NSDate date]timeIntervalSince1970];
            //if ((now-start)>itimeout/1000)
            if ((now-start)>50)
            {
                [task terminate];
                [task release];
                NSString * str = [NSString stringWithFormat:@"%s\r\nTask time out in %d millionseconds.",szcmd,itimeout];
                NSLog(@"%@", str);
                [task release];
                return -1;
                //                @throw [NSException exceptionWithName:@"NSTask" reason:str userInfo:nil];
            }
            
            if ([[NSThread currentThread] isCancelled])
            {
                NSLog(@"Thread cancelled!");
                [task release];
                return -2;  //cancel
            }
            
            if (![task isRunning]) break;
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate date]];
            [NSThread sleepForTimeInterval:0.001];
        }
        int ret = [task terminationStatus];
        [task release];
        NSLog(@"process normal finish! @ %s",szcmd);
        return ret;
    }
    //return [task processIdentifier];
    NSLog(@"process normal finish11! %s",szcmd);
    return 0;
}

int Execute(const char * szcmd,const char * poutput,int waituntilreturn,int itimeout)
{
    return Execute_withTask(szcmd,poutput, waituntilreturn, itimeout);
}



int main(int argc, const char * argv[]) {

//    //NSString *patternBsdName=@"\"IOCalloutDevice\"\\s*=\\s*\"(.*)\""; ///dev/cu.usbmodem
//    NSString *patternBsdName=@"\"IOCalloutDevice\"\\s*=\\s*\"(/dev/cu.usbmodem\\w+)\"";
//    NSString *filePath=@"/Users/mac/Desktop/logtest/system_serialPort_0x14710000.txt";
//   // NSString *getMacDeviceInfo = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
//    
//   NSString* getMacDeviceInfo = [NSString stringWithContentsOfFile:filePath encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000) error:nil];
//    int locationID=0x14710000;
//    //"IODialinDevice" = "/dev/tty.usbmodem
//    NSString *patternLocationID=[NSString stringWithFormat:@"\"locationID\"\\s*=\\s*0x%x([\\s\\S]*?)\"IODialinDevice\"\\s*=\\s*\"/dev/tty.usbmodem",locationID];     //@"\"locationID\"\\s* =\\s*(\\w*)"; //"LocationID" = 0x14300000
//   // NSString *patternLocationID=[NSString stringWithFormat:@"\"locationID\"\\s*=\\s*0x%x([\\s\\S]*?)\"IODialinDevice\"\\s*=\\s*\"",locationID];
//  
//    NSString *strBsdArray = [getMacDeviceInfo stringByMatching:patternLocationID capture:1L];
//    NSLog(@"==:%@",strBsdArray);
//    NSString *bsdName =[strBsdArray stringByMatching:patternBsdName capture:1L];
//    NSLog(@"--------------------%@",bsdName);
//    NSLog(@"===length:%zd",[strBsdArray length]);
//    if ([strBsdArray length]>12000) {
//        NSLog(@"to loog to fiand");
//    }
    int locationID=0x14710000;
    NSString *filePath1=[[NSString alloc]init];
    filePath1=[NSString stringWithFormat:@"/vault/Intelli_log/system_serialPort_0x%x.txt",locationID];
    const char *filepath="/vault/Intelli_log/system_serialPort.txt";
    //Execute("/usr/sbin/ioreg -c IOSerialBSDClient",filepath,0,2000);
    returnGetTaskResult(@"/usr/sbin/ioreg -c IOSerialBSDClient",filePath1);
    return 0;
}
