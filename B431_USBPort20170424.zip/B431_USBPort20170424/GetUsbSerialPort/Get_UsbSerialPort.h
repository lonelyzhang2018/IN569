//
//  Get_UsbSerialPort.hpp
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#ifndef Get_UsbSerialPort_h
#define Get_UsbSerialPort_h
#include <stdio.h>
extern "C"
{
    const char * getUsbSerialPortVersion();
    const char * getUsbSerialPortInfo(int pid,int vid,int channelIndex);
    const char * getUsbSerialPortInfoAll(int pid,int vid);
    const char * getUsbSerialPortLocation(int pid,int vid,int channelIndex);
    const char * execute_B431SuperBinary(const char *cmd,const char * filePath);
}

#endif /* Get_UsbSerialPort_hpp */
