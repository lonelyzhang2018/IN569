//
//  UsbSerialPort_Info.h
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//

#import <Foundation/Foundation.h>

//@interface UsbSerialPort_Info : NSObject
//{
//@private
//    NSMutableDictionary * dic;
//}
//
//-(void)IntialUsbSerialPort;
//-(NSString *)GetDicContent:(NSString *) key;
//
//@end
#ifdef __cplusplus
extern "C"
{
#endif
NSString *UsbSerialPortMain(int vid, int pid);
NSString *GetSerialPortFromGlobalparameters();
#ifdef __cplusplus
}
#endif
