/*
** Lua binding: GetUsbSerialPort
** Generated automatically by tolua++-1.0.92 on Mon Apr 17 13:51:03 2017.
*/

#ifndef __cplusplus
#include "stdlib.h"
#endif
#include "string.h"

#include "tolua++.h"

/* Exported function */
TOLUA_API int  tolua_GetUsbSerialPort_open (lua_State* tolua_S);

#include "Get_UsbSerialPort.h"

/* function to register type */
static void tolua_reg_types (lua_State* tolua_S)
{
}

/* function: getUsbSerialPortVersion */
#ifndef TOLUA_DISABLE_tolua_GetUsbSerialPort_getUsbSerialPortVersion00
static int tolua_GetUsbSerialPort_getUsbSerialPortVersion00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnoobj(tolua_S,1,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  {
   const char* tolua_ret = (const char*)  getUsbSerialPortVersion();
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'getUsbSerialPortVersion'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: getUsbSerialPortInfo */
#ifndef TOLUA_DISABLE_tolua_GetUsbSerialPort_getUsbSerialPortInfo00
static int tolua_GetUsbSerialPort_getUsbSerialPortInfo00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnumber(tolua_S,1,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  int pid = ((int)  tolua_tonumber(tolua_S,1,0));
  int vid = ((int)  tolua_tonumber(tolua_S,2,0));
  int channelIndex = ((int)  tolua_tonumber(tolua_S,3,0));
  {
   const char* tolua_ret = (const char*)  getUsbSerialPortInfo(pid,vid,channelIndex);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'getUsbSerialPortInfo'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: getUsbSerialPortInfoAll */
#ifndef TOLUA_DISABLE_tolua_GetUsbSerialPort_getUsbSerialPortInfoAll00
static int tolua_GetUsbSerialPort_getUsbSerialPortInfoAll00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnumber(tolua_S,1,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  int pid = ((int)  tolua_tonumber(tolua_S,1,0));
  int vid = ((int)  tolua_tonumber(tolua_S,2,0));
  {
   const char* tolua_ret = (const char*)  getUsbSerialPortInfoAll(pid,vid);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'getUsbSerialPortInfoAll'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: getUsbSerialPortLocation */
#ifndef TOLUA_DISABLE_tolua_GetUsbSerialPort_getUsbSerialPortLocation00
static int tolua_GetUsbSerialPort_getUsbSerialPortLocation00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isnumber(tolua_S,1,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,2,0,&tolua_err) ||
     !tolua_isnumber(tolua_S,3,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,4,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  int pid = ((int)  tolua_tonumber(tolua_S,1,0));
  int vid = ((int)  tolua_tonumber(tolua_S,2,0));
  int channelIndex = ((int)  tolua_tonumber(tolua_S,3,0));
  {
   const char* tolua_ret = (const char*)  getUsbSerialPortLocation(pid,vid,channelIndex);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'getUsbSerialPortLocation'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* function: execute_B431SuperBinary */
#ifndef TOLUA_DISABLE_tolua_GetUsbSerialPort_execute_B431SuperBinary00
static int tolua_GetUsbSerialPort_execute_B431SuperBinary00(lua_State* tolua_S)
{
#ifndef TOLUA_RELEASE
 tolua_Error tolua_err;
 if (
     !tolua_isstring(tolua_S,1,0,&tolua_err) ||
     !tolua_isstring(tolua_S,2,0,&tolua_err) ||
     !tolua_isnoobj(tolua_S,3,&tolua_err)
 )
  goto tolua_lerror;
 else
#endif
 {
  const char* cmd = ((const char*)  tolua_tostring(tolua_S,1,0));
  const char* filePath = ((const char*)  tolua_tostring(tolua_S,2,0));
  {
   const char* tolua_ret = (const char*)  execute_B431SuperBinary(cmd,filePath);
   tolua_pushstring(tolua_S,(const char*)tolua_ret);
  }
 }
 return 1;
#ifndef TOLUA_RELEASE
 tolua_lerror:
 tolua_error(tolua_S,"#ferror in function 'execute_B431SuperBinary'.",&tolua_err);
 return 0;
#endif
}
#endif //#ifndef TOLUA_DISABLE

/* Open function */
TOLUA_API int tolua_GetUsbSerialPort_open (lua_State* tolua_S)
{
 tolua_open(tolua_S);
 tolua_reg_types(tolua_S);
 tolua_module(tolua_S,NULL,0);
 tolua_beginmodule(tolua_S,NULL);
  tolua_function(tolua_S,"getUsbSerialPortVersion",tolua_GetUsbSerialPort_getUsbSerialPortVersion00);
  tolua_function(tolua_S,"getUsbSerialPortInfo",tolua_GetUsbSerialPort_getUsbSerialPortInfo00);
  tolua_function(tolua_S,"getUsbSerialPortInfoAll",tolua_GetUsbSerialPort_getUsbSerialPortInfoAll00);
  tolua_function(tolua_S,"getUsbSerialPortLocation",tolua_GetUsbSerialPort_getUsbSerialPortLocation00);
  tolua_function(tolua_S,"execute_B431SuperBinary",tolua_GetUsbSerialPort_execute_B431SuperBinary00);
 tolua_endmodule(tolua_S);
 return 1;
}


#if defined(LUA_VERSION_NUM) && LUA_VERSION_NUM >= 501
 TOLUA_API int luaopen_GetUsbSerialPort (lua_State* tolua_S) {
 return tolua_GetUsbSerialPort_open(tolua_S);
};
#endif

