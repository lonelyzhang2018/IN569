tolua=/usr/local/lib/tolua++

$tolua -o GetUsbSerialPort.mm GetUsbSerialPort.pkg
#$tolua -o TCPIP_Object_Lua.mm TCPIP_object.pkg
