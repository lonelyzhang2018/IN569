//
//  main.c
//  test5
//
//  Created by Mark on 4/15/17.
//  Copyright © 2017 MAC. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
