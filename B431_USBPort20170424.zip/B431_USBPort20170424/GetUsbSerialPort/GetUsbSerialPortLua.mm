//
//  usbInfoLua.cpp
//  GetUsbSerialPort
//
//  Created by RyanGao on 4/14/17.
//  Copyright © 2017 RyanGao. All rights reserved.
//
#import <Foundation/Foundation.h>
#include "GetUsbSerialPortLua.h"
//int luaopen_libGetUsbSerialPort(lua_State * state);
int tolua_GetUsbSerialPort_open (lua_State* tolua_S);

extern "C" int luaopen_libGetUsbSerialPort(lua_State * state)
{
    NSLog(@"Load libGetUsbSerialPort Dylib\r\n");
    tolua_GetUsbSerialPort_open(state);
    return 0;
}
